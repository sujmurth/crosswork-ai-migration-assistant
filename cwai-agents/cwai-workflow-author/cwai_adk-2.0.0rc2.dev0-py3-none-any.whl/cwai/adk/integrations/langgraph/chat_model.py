"""LangChain chat model backed by ADK's ``ctx.llm`` client.

Lets LangGraph nodes call ``ctx.llm`` through LangChain's standard
chat model interface, enabling tool binding and structured output.

Examples:
    from cwai.adk.integrations.langgraph import ADKChatModel

    model = ADKChatModel(llm=ctx.llm)
    model_with_tools = model.bind_tools([my_tool])
    result = await model.ainvoke([HumanMessage("hello")])
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable, Sequence
from typing import Any

from langchain_core.callbacks import (
    AsyncCallbackManagerForLLMRun,
    CallbackManagerForLLMRun,
)
from langchain_core.language_models import BaseChatModel, LanguageModelInput
from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    ToolCallChunk,
)
from langchain_core.messages.ai import InputTokenDetails, UsageMetadata
from langchain_core.outputs import (
    ChatGeneration,
    ChatGenerationChunk,
    ChatResult,
)
from langchain_core.runnables import Runnable
from langchain_core.tools import BaseTool
from langchain_core.utils.function_calling import convert_to_openai_tool

from cwai.adk.integrations.langgraph.messages import (
    from_openai_message,
    to_openai_message,
)


def _create_usage_metadata(usage: dict[str, Any]) -> UsageMetadata | None:
    """Build LangChain UsageMetadata from OpenAI-format usage dict.

    Handles cache token details that LiteLLM may include
    (cache_read_input_tokens, cache_creation_input_tokens).
    """
    if not usage:
        return None

    input_tokens = usage.get("prompt_tokens", 0)
    output_tokens = usage.get("completion_tokens", 0)

    details: InputTokenDetails = {}
    cache_read = usage.get("cache_read_input_tokens")
    cache_creation = usage.get("cache_creation_input_tokens")

    # Fallback to nested prompt_tokens_details (Anthropic via LiteLLM)
    if cache_read is None or cache_creation is None:
        prompt_details = usage.get("prompt_tokens_details")
        if isinstance(prompt_details, dict):
            if cache_read is None:
                cache_read = prompt_details.get("cached_tokens")
            if cache_creation is None:
                cache_creation = prompt_details.get("cache_creation_tokens")

    if cache_read is not None:
        details["cache_read"] = int(cache_read)
    if cache_creation is not None:
        details["cache_creation"] = int(cache_creation)

    return UsageMetadata(
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=input_tokens + output_tokens,
        **({"input_token_details": details} if details else {}),
    )


# OpenAI-reserved tool_choice type strings (hosted / special tools).
_OPENAI_WELL_KNOWN_TOOL_TYPES = frozenset(
    {
        "file_search",
        "code_interpreter",
        "mcp",
        "tool_search",
    }
)


class ADKChatModel(BaseChatModel):
    """LangChain chat model that delegates to ADK's language model client.

    Implements ``bind_tools()`` by converting tools to OpenAI-style schemas and
    binding them through ``Runnable.bind``. Streaming uses
    ``ctx.llm.complete_stream()`` to yield token-by-token
    ``ChatGenerationChunk`` objects.

    Attributes:
        llm: ADK language model client, typically ``ctx.llm``.
        model_name: Model name or ordered fallback list for the language model proxy.
        temperature: Sampling temperature.
        max_tokens: Maximum tokens in the response.
    """

    llm: Any  # LLMClientProtocol — Any to satisfy pydantic
    model_name: str | list[str] | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    model_config = {"arbitrary_types_allowed": True}

    @property
    def _llm_type(self) -> str:
        return "adk"

    @property
    def _identifying_params(self) -> dict[str, Any]:
        return {
            "model_name": self.model_name,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }

    def bind_tools(
        self,
        tools: Sequence[dict[str, Any] | type | Callable | BaseTool],
        *,
        tool_choice: dict | str | bool | None = None,
        strict: bool | None = None,
        parallel_tool_calls: bool | None = None,
        **kwargs: Any,
    ) -> Runnable[LanguageModelInput, AIMessage]:
        """Binds tools for OpenAI-compatible tool calling through ``ctx.llm``."""
        if parallel_tool_calls is not None:
            kwargs["parallel_tool_calls"] = parallel_tool_calls
        formatted_tools = [
            convert_to_openai_tool(tool, strict=strict) for tool in tools
        ]
        for original, formatted in zip(tools, formatted_tools, strict=False):
            if (
                isinstance(original, BaseTool)
                and hasattr(original, "extras")
                and isinstance(original.extras, dict)
                and "defer_loading" in original.extras
            ):
                formatted["defer_loading"] = original.extras["defer_loading"]
        tool_names: list[str] = []
        for tool in formatted_tools:
            if "function" in tool:
                tool_names.append(tool["function"]["name"])
            elif "name" in tool:
                tool_names.append(str(tool["name"]))
        if tool_choice:
            if isinstance(tool_choice, str):
                if tool_choice in tool_names:
                    tool_choice = {
                        "type": "function",
                        "function": {"name": tool_choice},
                    }
                elif tool_choice in _OPENAI_WELL_KNOWN_TOOL_TYPES:
                    tool_choice = {"type": tool_choice}
                elif tool_choice == "any":
                    tool_choice = "required"
            elif isinstance(tool_choice, bool):
                tool_choice = "required"
            elif not isinstance(tool_choice, dict):
                msg = (
                    "Unrecognized tool_choice type. Expected str, bool or dict. "
                    f"Received: {tool_choice!r}"
                )
                raise ValueError(msg)
            kwargs["tool_choice"] = tool_choice
        return self.bind(tools=formatted_tools, **kwargs)

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: CallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> ChatResult:
        raise NotImplementedError("ADK is async-only. Use ainvoke() or _agenerate().")

    async def _agenerate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: AsyncCallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> ChatResult:
        openai_messages = [to_openai_message(m) for m in messages]

        llm_kwargs: dict[str, Any] = {}
        if self.model_name is not None:
            llm_kwargs["model"] = self.model_name
        if self.temperature is not None:
            llm_kwargs["temperature"] = self.temperature
        if self.max_tokens is not None:
            llm_kwargs["max_tokens"] = self.max_tokens
        if stop:
            llm_kwargs["stop"] = stop
        for key in (
            "tools",
            "tool_choice",
            "parallel_tool_calls",
            "response_format",
        ):
            if key in kwargs:
                llm_kwargs[key] = kwargs[key]

        response = await self.llm.complete(messages=openai_messages, **llm_kwargs)

        msg = response.message

        if msg and (msg.get("tool_calls") or msg.get("content")):
            ai_message = from_openai_message(msg)
        else:
            ai_message = AIMessage(content=response.content or "")

        usage_metadata = _create_usage_metadata(response.usage)
        if usage_metadata is not None:
            ai_message.usage_metadata = usage_metadata
        ai_message.response_metadata = {"model_name": response.model}

        generation_info: dict[str, Any] = {}
        finish_reason = getattr(response, "finish_reason", None)
        if finish_reason is not None:
            generation_info["finish_reason"] = finish_reason

        return ChatResult(
            generations=[
                ChatGeneration(
                    message=ai_message,
                    generation_info=generation_info or None,
                ),
            ],
            llm_output={
                "token_usage": response.usage,
                "model": response.model,
            },
        )

    async def _astream(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: AsyncCallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[ChatGenerationChunk]:
        openai_messages = [to_openai_message(m) for m in messages]

        llm_kwargs: dict[str, Any] = {}
        if self.model_name is not None:
            llm_kwargs["model"] = self.model_name
        if self.temperature is not None:
            llm_kwargs["temperature"] = self.temperature
        if self.max_tokens is not None:
            llm_kwargs["max_tokens"] = self.max_tokens
        if stop:
            llm_kwargs["stop"] = stop
        for key in (
            "tools",
            "tool_choice",
            "parallel_tool_calls",
            "response_format",
        ):
            if key in kwargs:
                llm_kwargs[key] = kwargs[key]

        async for event in self.llm.complete_stream(
            messages=openai_messages, **llm_kwargs
        ):
            if event.type == "token":
                yield ChatGenerationChunk(
                    message=AIMessageChunk(content=event.token or ""),
                )
            elif event.type == "tool_call_delta":
                delta = event.tool_call_delta
                tc_chunk = ToolCallChunk(
                    index=delta.get("index", 0),
                    id=delta.get("id"),
                    name=delta.get("function", {}).get("name"),
                    args=delta.get("function", {}).get("arguments"),
                )
                yield ChatGenerationChunk(
                    message=AIMessageChunk(
                        content="",
                        tool_call_chunks=[tc_chunk],
                    ),
                )
            elif event.type == "done" and event.response:
                # Yield a final empty chunk carrying usage metadata
                # so LangChain's callback system can aggregate it.
                usage_metadata = _create_usage_metadata(event.response.usage)
                if usage_metadata is not None:
                    yield ChatGenerationChunk(
                        message=AIMessageChunk(
                            content="",
                            usage_metadata=usage_metadata,
                        ),
                    )
