"""Converts ADK tools to LangChain tools.

Provides converters that bridge ADK ``Tool`` objects with LangChain
``StructuredTool`` objects for use with LangGraph agents.

Examples:
    from cwai.adk.integrations.langgraph import to_langchain_tools

    langchain_tools = to_langchain_tools(ctx.kg.tools)
    model = ADKChatModel(llm=ctx.llm).bind_tools(langchain_tools)

Examples:
    from cwai.adk.integrations.langgraph import to_langchain_tool

    langchain_tool = to_langchain_tool(ctx.kg.tools[0])
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

from langchain_core.tools import StructuredTool

if TYPE_CHECKING:
    from cwai.adk.tools import Tool


def to_langchain_tool(tool: Tool) -> StructuredTool:
    """Converts an ADK ``Tool`` to a LangChain ``StructuredTool``.

    The returned tool wraps the ADK tool's async execute function so it
    can be used with LangChain's tool-calling infrastructure.

    Args:
        tool: ADK tool to convert.

    Returns:
        LangChain tool that delegates to the ADK tool.

    Examples:
        from cwai.adk.integrations.langgraph import to_langchain_tool

        kg_query_tool = ctx.kg.tools[0]
        langchain_tool = to_langchain_tool(kg_query_tool)
        result = await langchain_tool.ainvoke({"query": "{ queryNode { nodeId } }"})
    """
    # Build the JSON schema for LangChain
    # LangChain expects a JSON schema dict with 'properties', 'required', etc.
    args_schema = tool.parameters

    # Create a wrapper that calls the ADK tool's async execute
    async def _acoroutine(**kwargs: Any) -> str:
        return await tool.execute(**kwargs)

    # Sync fallback that runs the async function
    def _func(**kwargs: Any) -> str:
        return asyncio.get_event_loop().run_until_complete(tool.execute(**kwargs))

    return StructuredTool(
        name=tool.name,
        description=tool.description,
        args_schema=args_schema,
        func=_func,
        coroutine=_acoroutine,
    )


def to_langchain_tools(tools: list[Tool]) -> list[StructuredTool]:
    """Converts ADK ``Tool`` objects to LangChain ``StructuredTool`` objects.

    Args:
        tools: ADK tools to convert.

    Returns:
        LangChain tools that delegate to the ADK tools.

    Examples:
        from cwai.adk.integrations.langgraph import ADKChatModel, to_langchain_tools

        all_tools = ctx.kg.tools + ctx.rag.tools
        langchain_tools = to_langchain_tools(all_tools)
        model = ADKChatModel(llm=ctx.llm).bind_tools(langchain_tools)
    """
    return [to_langchain_tool(t) for t in tools]
