"""Wraps ADK catalog agents as LangGraph graph nodes.

``agent_as_node`` converts a named agent registered with
``@agent.on_run("name")`` into an async function compatible with
LangGraph's ``StateGraph.add_node()``.

Examples:
    from cwai.adk.integrations.langgraph import agent_as_node

    graph = StateGraph(MyState)
    graph.add_node("analyzer", agent_as_node("analyzer", ctx))
    graph.add_node("validator", agent_as_node("validator", ctx))
"""

from __future__ import annotations

from typing import Any

from cwai.adk.context import Context


def agent_as_node(
    agent_name: str,
    ctx: Context,
) -> Any:
    """Wraps a catalog agent as a LangGraph node function.

    The returned async function passes the full graph state dict as
    ``msg.query`` to the sub-agent, calls ``ctx.call_subagent()``, and
    returns ``result.data`` as graph state updates.

    The sub-agent receives the entire graph state and can read whatever
    keys it needs from ``msg.query``. LangGraph merges the sub-agent's
    ``result.data`` into the graph state.

    Args:
        agent_name: Name of the agent registered with ``@agent.on_run("name")``.
        ctx: Parent context. The sub-agent receives a child context through
            ``ctx.call_subagent()``.

    Returns:
        Async function suitable for ``graph.add_node()``.
    """

    async def node_fn(state: dict[str, Any]) -> dict[str, Any]:
        result = await ctx.call_subagent(agent_name, query=state)
        return result.data if result.data else {}

    return node_fn
