"""LangGraph checkpointer backed by ADK Short-Term Memory (STM).

Persists LangGraph graph state to STM so graphs can be interrupted and
resumed across handler invocations, such as human-in-the-loop workflows.

The ``thread_id`` in the LangGraph config is a user-chosen label, such as
``"main"``. Long-running agents should delete completed checkpoint threads
with ``adelete_thread()``.

Examples:
    from cwai.adk.integrations.langgraph import ADKCheckpointer

    async with ADKCheckpointer(ctx) as checkpointer:
        graph = build_graph().compile(checkpointer=checkpointer)
        result = await graph.ainvoke(inputs, config={
            "configurable": {"thread_id": "main"}
        })
"""

from __future__ import annotations

import base64
import builtins
import json
import logging
import random
from collections.abc import AsyncIterator, Sequence
from typing import Any, cast

from langgraph.checkpoint.base import (
    WRITES_IDX_MAP,
    BaseCheckpointSaver,
    ChannelVersions,
    Checkpoint,
    CheckpointMetadata,
    CheckpointTuple,
    get_checkpoint_id,
    get_checkpoint_metadata,
)
from langgraph.checkpoint.serde.base import SerializerProtocol
from opentelemetry import trace

from cwai.adk.errors import STMNotFoundError
from cwai.adk.types.stm import STMStatus


class ADKCheckpointer(BaseCheckpointSaver[str]):
    """Stores LangGraph checkpoint data in Short-Term Memory (STM).

    The checkpointer stores graph state, checkpoint writes, and channel
    values so graph runs can resume after interruptions or restarts.

    Use ``async with`` to scope checkpointer usage around graph execution.
    Exiting the context does not delete checkpoint records. Call
    ``adelete_thread()`` when the application intentionally cleans up a
    completed or cancelled checkpoint thread.

    Args:
        ctx: ADK ``Context`` instance.
        serde: Optional custom serializer. Defaults to LangGraph's
            built-in ``JsonPlusSerializer``.
        ttl: Optional time-to-live, in seconds, for checkpoint STM entries.
            If set, checkpoint state expires after the given duration.
    """

    def __init__(
        self,
        ctx: Any,
        *,
        serde: SerializerProtocol | None = None,
        ttl: float | None = None,
    ) -> None:
        super().__init__(serde=serde)
        self._stm = ctx.stm
        self._ttl = ttl
        self._log: logging.LoggerAdapter = ctx.log
        self._tracer = trace.get_tracer(__name__)

    async def __aenter__(self) -> ADKCheckpointer:
        """Enters a scoped checkpointer lifecycle."""
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        """Exits the scoped lifecycle without deleting checkpoint records."""
        return None

    # --- Key helpers ---

    @staticmethod
    def _cp_key(thread_id: str) -> str:
        return f"lg-cp:{thread_id}"

    @staticmethod
    def _wr_key(thread_id: str) -> str:
        return f"lg-wr:{thread_id}"

    @staticmethod
    def _bl_key(thread_id: str) -> str:
        return f"lg-bl:{thread_id}"

    # --- Public API ---

    async def extend_lifespan(self, thread_id: str, ttl: float) -> None:
        """Extends the time-to-live for all checkpoint state in a thread.

        Call this during idle periods, such as while waiting for human input,
        to prevent checkpoint state from expiring.

        Args:
            thread_id: Checkpoint thread whose state should remain available.
            ttl: New time-to-live, in seconds from now. Must be greater than 0.
        """
        for key in (
            self._cp_key(thread_id),
            self._wr_key(thread_id),
            self._bl_key(thread_id),
        ):
            try:
                await self._stm.extend_lifespan(key, ttl)
            except STMNotFoundError:
                pass  # Key may not exist yet (e.g. no writes stored)

    # --- STM I/O helpers ---

    async def _ensure_stm(self, label: str) -> None:
        """Creates the STM if it does not exist yet."""
        entity = await self._stm.get(label)
        if entity is None:
            await self._stm.create(label, ttl=self._ttl)

    async def _load_entries(self, label: str) -> builtins.list[dict[str, Any]]:
        """Load all entries from an STM as parsed JSON dicts."""
        entity = await self._stm.get(label)
        if entity is None or entity.status == STMStatus.DELETED or not entity.entries:
            return []
        results = []
        for entry in entity.entries:
            results.append(json.loads(entry.payload.decode()))
        return results

    async def _append(self, label: str, data: dict[str, Any]) -> None:
        """Append a JSON entry to the STM, creating it if needed."""
        await self._ensure_stm(label)
        await self._stm.add(label, json.dumps(data).encode(), ttl=self._ttl)

    # --- Blob helpers ---
    # Blobs store serialized channel values separately from checkpoint
    # metadata, keyed by (thread_id, checkpoint_ns, channel, version).

    def _blob_record_key(
        self,
        thread_id: str,
        checkpoint_ns: str,
        channel: str,
        version: str | int | float,
    ) -> str:
        """Deterministic string key for a blob record."""
        return f"{thread_id}:{checkpoint_ns}:{channel}:{version}"

    async def _store_blobs(
        self,
        thread_id: str,
        checkpoint_ns: str,
        channel_values: dict[str, Any],
        new_versions: ChannelVersions,
    ) -> None:
        """Serialize and store channel value blobs."""
        bl_label = self._bl_key(thread_id)
        await self._ensure_stm(bl_label)
        for channel, version in new_versions.items():
            key = self._blob_record_key(
                thread_id,
                checkpoint_ns,
                channel,
                version,
            )
            if channel in channel_values:
                type_tag, blob_bytes = self.serde.dumps_typed(channel_values[channel])
                record = {
                    "key": key,
                    "type": type_tag,
                    "data": base64.b64encode(blob_bytes).decode("ascii"),
                }
            else:
                record = {"key": key, "type": "empty", "data": ""}
            await self._stm.add(bl_label, json.dumps(record).encode(), ttl=self._ttl)

    async def _load_blobs(
        self,
        thread_id: str,
        checkpoint_ns: str,
        versions: ChannelVersions,
    ) -> dict[str, Any]:
        """Load channel values from blob storage."""
        entries = await self._load_entries(self._bl_key(thread_id))
        # Index by key for O(1) lookup
        blob_map: dict[str, dict[str, Any]] = {}
        for entry in entries:
            blob_map[entry["key"]] = entry

        channel_values: dict[str, Any] = {}
        for channel, version in versions.items():
            key = self._blob_record_key(
                thread_id,
                checkpoint_ns,
                channel,
                version,
            )
            blob = blob_map.get(key)
            if blob and blob["type"] != "empty":
                channel_values[channel] = self.serde.loads_typed(
                    (
                        blob["type"],
                        base64.b64decode(blob["data"]),
                    )
                )
        return channel_values

    # --- BaseCheckpointSaver interface ---

    def get_tuple(self, config: Any) -> CheckpointTuple | None:
        """Gets the checkpoint tuple for a graph configuration."""
        raise NotImplementedError("ADKCheckpointer is async-only. Use aget_tuple().")

    def list(self, config: Any, **kwargs: Any) -> Any:
        """Lists checkpoint tuples for a graph configuration."""
        raise NotImplementedError("ADKCheckpointer is async-only. Use alist().")

    def put(self, config: Any, *args: Any, **kwargs: Any) -> Any:
        """Saves a checkpoint and returns the updated graph configuration."""
        raise NotImplementedError("ADKCheckpointer is async-only. Use aput().")

    def put_writes(self, config: Any, *args: Any, **kwargs: Any) -> Any:
        """Saves graph writes associated with a checkpoint task."""
        raise NotImplementedError("ADKCheckpointer is async-only. Use aput_writes().")

    async def aget_tuple(self, config: Any) -> CheckpointTuple | None:
        """Asynchronously get the checkpoint tuple for a graph configuration."""
        thread_id: str = config["configurable"]["thread_id"]
        checkpoint_ns: str = config["configurable"].get("checkpoint_ns", "")
        target_id = get_checkpoint_id(config)

        with self._tracer.start_as_current_span(
            "langgraph.checkpoint.read",
            attributes={"thread_id": thread_id, "checkpoint_ns": checkpoint_ns},
        ):
            entries = await self._load_entries(self._cp_key(thread_id))
            if not entries:
                return None

            # Filter to matching namespace
            ns_entries = [
                e for e in entries if e.get("checkpoint_ns", "") == checkpoint_ns
            ]
            if not ns_entries:
                return None

            if target_id:
                matched = [e for e in ns_entries if e["checkpoint_id"] == target_id]
                if not matched:
                    return None
                saved = matched[0]
            else:
                # Latest checkpoint (highest checkpoint_id)
                saved = max(ns_entries, key=lambda e: e["checkpoint_id"])

            checkpoint_id = saved["checkpoint_id"]
            cp = self.serde.loads_typed(
                (
                    saved["cp_type"],
                    base64.b64decode(saved["cp_data"]),
                )
            )
            metadata = self.serde.loads_typed(
                (
                    saved["md_type"],
                    base64.b64decode(saved["md_data"]),
                )
            )
            parent_id = saved.get("parent_checkpoint_id")

            # Load channel values
            channel_values = await self._load_blobs(
                thread_id,
                checkpoint_ns,
                cp.get("channel_versions", {}),
            )

            # Load pending writes for this checkpoint
            pending_writes = await self._load_writes(
                thread_id,
                checkpoint_ns,
                checkpoint_id,
            )

            return CheckpointTuple(
                config={
                    "configurable": {
                        "thread_id": thread_id,
                        "checkpoint_ns": checkpoint_ns,
                        "checkpoint_id": checkpoint_id,
                    }
                },
                checkpoint=cast(Checkpoint, {**cp, "channel_values": channel_values}),
                metadata=metadata,
                parent_config=(
                    {
                        "configurable": {
                            "thread_id": thread_id,
                            "checkpoint_ns": checkpoint_ns,
                            "checkpoint_id": parent_id,
                        }
                    }
                    if parent_id
                    else None
                ),
                pending_writes=pending_writes,
            )

    async def alist(
        self,
        config: Any,
        *,
        filter: dict[str, Any] | None = None,
        before: Any | None = None,
        limit: int | None = None,
    ) -> AsyncIterator[CheckpointTuple]:
        """Asynchronously list checkpoint tuples for a graph configuration."""
        thread_id: str = config["configurable"]["thread_id"]
        checkpoint_ns: str = config["configurable"].get("checkpoint_ns", "")
        before_id = get_checkpoint_id(before) if before else None

        with self._tracer.start_as_current_span(
            "langgraph.checkpoint.list",
            attributes={"thread_id": thread_id, "checkpoint_ns": checkpoint_ns},
        ):
            entries = await self._load_entries(self._cp_key(thread_id))
            ns_entries = [
                e for e in entries if e.get("checkpoint_ns", "") == checkpoint_ns
            ]
            # Sort descending by checkpoint_id
            ns_entries.sort(key=lambda e: e["checkpoint_id"], reverse=True)

        count = 0
        for saved in ns_entries:
            cp_id = saved["checkpoint_id"]

            if before_id and cp_id >= before_id:
                continue

            metadata = self.serde.loads_typed(
                (
                    saved["md_type"],
                    base64.b64decode(saved["md_data"]),
                )
            )
            if filter and not all(metadata.get(k) == v for k, v in filter.items()):
                continue

            if limit is not None and count >= limit:
                break
            count += 1

            cp = self.serde.loads_typed(
                (
                    saved["cp_type"],
                    base64.b64decode(saved["cp_data"]),
                )
            )
            channel_values = await self._load_blobs(
                thread_id,
                checkpoint_ns,
                cp.get("channel_versions", {}),
            )
            pending_writes = await self._load_writes(
                thread_id,
                checkpoint_ns,
                cp_id,
            )
            parent_id = saved.get("parent_checkpoint_id")

            yield CheckpointTuple(
                config={
                    "configurable": {
                        "thread_id": thread_id,
                        "checkpoint_ns": checkpoint_ns,
                        "checkpoint_id": cp_id,
                    }
                },
                checkpoint=cast(Checkpoint, {**cp, "channel_values": channel_values}),
                metadata=metadata,
                parent_config=(
                    {
                        "configurable": {
                            "thread_id": thread_id,
                            "checkpoint_ns": checkpoint_ns,
                            "checkpoint_id": parent_id,
                        }
                    }
                    if parent_id
                    else None
                ),
                pending_writes=pending_writes,
            )

    async def aput(
        self,
        config: Any,
        checkpoint: Checkpoint,
        metadata: CheckpointMetadata,
        new_versions: ChannelVersions,
    ) -> Any:
        """Asynchronously save a checkpoint and return the updated graph configuration."""
        thread_id = config["configurable"]["thread_id"]
        checkpoint_ns = config["configurable"].get("checkpoint_ns", "")
        parent_id = config["configurable"].get("checkpoint_id")

        with self._tracer.start_as_current_span(
            "langgraph.checkpoint.write",
            attributes={
                "thread_id": thread_id,
                "checkpoint_ns": checkpoint_ns,
                "checkpoint_id": checkpoint["id"],
            },
        ):
            c: dict[str, Any] = {**checkpoint}
            channel_values: dict[str, Any] = c.pop("channel_values", {})

            # Store channel blobs
            await self._store_blobs(
                thread_id,
                checkpoint_ns,
                channel_values,
                new_versions,
            )

            # Serialize checkpoint and metadata
            cp_type, cp_data = self.serde.dumps_typed(c)
            md_type, md_data = self.serde.dumps_typed(
                get_checkpoint_metadata(config, metadata)
            )

            record = {
                "checkpoint_id": checkpoint["id"],
                "checkpoint_ns": checkpoint_ns,
                "parent_checkpoint_id": parent_id,
                "cp_type": cp_type,
                "cp_data": base64.b64encode(cp_data).decode("ascii"),
                "md_type": md_type,
                "md_data": base64.b64encode(md_data).decode("ascii"),
            }
            await self._append(self._cp_key(thread_id), record)

        return {
            "configurable": {
                "thread_id": thread_id,
                "checkpoint_ns": checkpoint_ns,
                "checkpoint_id": checkpoint["id"],
            }
        }

    async def aput_writes(
        self,
        config: Any,
        writes: Sequence[tuple[str, Any]],
        task_id: str,
        task_path: str = "",
    ) -> None:
        """Asynchronously save graph writes associated with a checkpoint task."""
        thread_id = config["configurable"]["thread_id"]
        checkpoint_ns = config["configurable"].get("checkpoint_ns", "")
        checkpoint_id = config["configurable"]["checkpoint_id"]

        with self._tracer.start_as_current_span(
            "langgraph.checkpoint.write_pending",
            attributes={
                "thread_id": thread_id,
                "checkpoint_ns": checkpoint_ns,
                "checkpoint_id": checkpoint_id,
            },
        ):
            # Load existing writes to check for duplicates
            existing = await self._load_entries(self._wr_key(thread_id))
            existing_keys: set[str] = set()
            for entry in existing:
                if (
                    entry.get("checkpoint_ns") == checkpoint_ns
                    and entry.get("checkpoint_id") == checkpoint_id
                ):
                    existing_keys.add(f"{entry['task_id']}:{entry['write_idx']}")

            wr_label = self._wr_key(thread_id)
            await self._ensure_stm(wr_label)

            for idx, (channel, value) in enumerate(writes):
                write_idx = WRITES_IDX_MAP.get(channel, idx)
                dedup_key = f"{task_id}:{write_idx}"

                # Skip duplicates for non-negative indices
                if write_idx >= 0 and dedup_key in existing_keys:
                    continue

                v_type, v_data = self.serde.dumps_typed(value)
                record = {
                    "checkpoint_ns": checkpoint_ns,
                    "checkpoint_id": checkpoint_id,
                    "task_id": task_id,
                    "task_path": task_path,
                    "channel": channel,
                    "write_idx": write_idx,
                    "v_type": v_type,
                    "v_data": base64.b64encode(v_data).decode("ascii"),
                }
                await self._stm.add(
                    wr_label, json.dumps(record).encode(), ttl=self._ttl
                )

    async def _load_writes(
        self,
        thread_id: str,
        checkpoint_ns: str,
        checkpoint_id: str,
    ) -> builtins.list[tuple[str, str, Any]]:
        """Load pending writes for a specific checkpoint."""
        entries = await self._load_entries(self._wr_key(thread_id))
        writes: list[tuple[str, str, Any]] = []
        for entry in entries:
            if (
                entry.get("checkpoint_ns") == checkpoint_ns
                and entry.get("checkpoint_id") == checkpoint_id
            ):
                value = self.serde.loads_typed(
                    (
                        entry["v_type"],
                        base64.b64decode(entry["v_data"]),
                    )
                )
                writes.append(
                    (
                        entry["task_id"],
                        entry["channel"],
                        value,
                    )
                )
        return writes

    async def adelete_thread(self, thread_id: str) -> None:
        """Deletes all checkpoints and writes for a thread."""
        for label in (
            self._cp_key(thread_id),
            self._wr_key(thread_id),
            self._bl_key(thread_id),
        ):
            try:
                await self._stm.delete(label)
            except STMNotFoundError:
                pass  # Already deleted or never created
            except Exception:
                self._log.warning(
                    "Failed to delete STM key", extra={"stm_key": label}, exc_info=True
                )

    def get_next_version(self, current: str | None, channel: None) -> str:
        """Generates the next checkpoint version string."""
        if current is None:
            current_v = 0
        elif isinstance(current, int):
            current_v = current
        else:
            current_v = int(current.split(".")[0])
        next_v = current_v + 1
        next_h = random.random()  # noqa: S311
        return f"{next_v:032}.{next_h:016}"
