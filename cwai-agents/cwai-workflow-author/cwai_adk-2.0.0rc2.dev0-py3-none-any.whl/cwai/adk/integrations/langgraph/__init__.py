"""LangChain and LangGraph integration adapters for the ADK.

Components available with ``cwai-adk[langchain]``:
    - ``ADKChatModel`` wraps ``ctx.llm`` as a LangChain ``BaseChatModel``.
    - ``OTELGraphHandler`` emits OpenTelemetry spans for LangGraph callbacks.
    - ``to_langchain_tool`` converts an ADK ``Tool`` to a LangChain ``StructuredTool``.
    - ``to_langchain_tools`` converts ADK ``Tool`` objects to LangChain tools.

Components available with ``cwai-adk[langgraph]``:
    - ``ADKCheckpointer`` stores LangGraph checkpoints in Short-Term Memory (STM).
"""

# langchain-core is required for all components in this package
try:
    from cwai.adk.integrations.langgraph.chat_model import ADKChatModel
    from cwai.adk.integrations.langgraph.messages import (
        from_openai_message,
        to_openai_message,
    )
    from cwai.adk.integrations.langgraph.node import agent_as_node
    from cwai.adk.integrations.langgraph.otel import OTELGraphHandler
    from cwai.adk.integrations.langgraph.tools import (
        to_langchain_tool,
        to_langchain_tools,
    )
except ImportError as e:
    raise ImportError(
        "LangChain integration requires additional dependencies. "
        "Install with: pip install cwai-adk[langchain]"
    ) from e

# langgraph-checkpoint is only needed for ADKCheckpointer and invoke_or_resume.
# Users who only need ADKChatModel + OTELGraphHandler can skip it.
try:
    from cwai.adk.integrations.langgraph.checkpointer import ADKCheckpointer
    from cwai.adk.integrations.langgraph.recovery import invoke_or_resume
except ImportError:
    pass  # Available only with cwai-adk[langgraph]

__all__ = [
    "ADKChatModel",
    "ADKCheckpointer",
    "OTELGraphHandler",
    "agent_as_node",
    "from_openai_message",
    "invoke_or_resume",
    "to_langchain_tool",
    "to_langchain_tools",
    "to_openai_message",
]
