"""OpenTelemetry span emission for LangGraph execution.

Bridges LangChain's callback system with OpenTelemetry tracing so
LangGraph node, language model, and tool executions appear in the same
trace as native ADK spans.

Use the async context manager form so the caller's OpenTelemetry context
is restored after graph execution.

Examples:
    from cwai.adk.integrations.langgraph import OTELGraphHandler

    async with OTELGraphHandler(ctx) as handler:
        result = await graph.ainvoke(
            inputs, config={"callbacks": [handler]}
        )
"""

from __future__ import annotations

import asyncio
import logging
import time
from contextvars import Token
from typing import Any
from uuid import UUID

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import BaseMessage
from langchain_core.outputs import LLMResult
from opentelemetry import context as otel_context
from opentelemetry import trace
from opentelemetry.context import Context
from opentelemetry.trace import Span, StatusCode

from cwai.adk.observability._labels import _resolve_agent_type
from cwai.adk.observability.metrics import (
    record_langgraph_llm_tokens,
    record_tools_error,
    record_tools_request,
)
from cwai.adk.observability.trace_events import record_content_event


def _current_task_id() -> int:
    """Return an ID for the current asyncio task, or 0 if not in async."""
    try:
        task = asyncio.current_task()
        return id(task) if task else 0
    except RuntimeError:
        return 0


class OTELGraphHandler(BaseCallbackHandler):
    """LangChain callback handler that emits OpenTelemetry spans.

    Creates spans for chain, node, language model, and tool executions so they
    appear in the distributed trace alongside native ADK spans.

    All callbacks are exception-safe: errors are logged but do not
    propagate to LangGraph. Prefer ``async with OTELGraphHandler(ctx)``
    so the handler closes automatically after execution. Call ``close()``
    manually when using the handler without a context manager.

    Args:
        ctx: ADK ``Context`` instance.
    """

    # Run callbacks inline (in the calling task's context) rather than
    # dispatched onto a thread executor with a copied context. This is
    # what allows ``otel_context.attach()`` to actually propagate the
    # active span to user code inside node bodies. See ADR-0034.
    run_inline = True
    """Specifies whether LangChain calls this handler immediately during graph execution instead of scheduling callbacks separately."""

    def __init__(self, ctx: Any) -> None:
        super().__init__()
        self._tracer = ctx.tracer
        # ``ctx.log`` is typically a LoggerAdapter, but accept a plain
        # Logger as well to avoid a misannotation if a caller swaps it.
        self._log: logging.Logger | logging.LoggerAdapter = ctx.log
        self._spans: dict[UUID, Span] = {}
        # Tokens returned by ``otel_context.attach``, paired with the
        # asyncio task ID that performed the attach. We only detach when
        # the current task matches, avoiding the cross-task ValueError
        # from ``ContextVar.reset``.
        self._tokens: dict[UUID, tuple[Token[Context], int]] = {}
        # Snapshot of the caller's OTel context at handler construction.
        # Used as the fallback baseline for the legacy direct-``close()``
        # path. The async-context-manager path overrides this in
        # ``__aenter__`` so that constructing the handler before
        # entering the caller's parent span still works correctly.
        self._baseline_context: Context = otel_context.get_current()
        # Tracks whether ``close()`` has already restored the baseline.
        # Implemented as a flag (not a token) because we intentionally
        # never call ``otel_context.detach`` on the restoring attach:
        # detaching across asyncio tasks would re-introduce the same
        # cross-task LIFO problem the baseline restore exists to neutralize.
        self._baseline_restored: bool = False
        # Per-tool-run state for metric recording (start time + name).
        self._tool_runs: dict[UUID, tuple[float, str]] = {}
        # Active LangGraph node names by run_id (set in on_chain_start,
        # popped in on_chain_end/error). Used to attribute LLM calls to
        # the parent node via one-hop parent_run_id lookup.
        self._node_names: dict[UUID, str] = {}
        # LLM run_id -> resolved node name (or None) at start time, so the
        # node attribution is stable across the start/end pair even if the
        # parent chain ends concurrently.
        self._llm_runs: dict[UUID, str | None] = {}
        # Best-effort agent.type label for tool metrics.
        self._agent_type: str | None = _resolve_agent_type(ctx)

    async def __aenter__(self) -> OTELGraphHandler:
        # Re-snapshot inside the async context so the baseline reflects
        # the caller's OTel context at the moment of ``async with`` entry,
        # not at handler construction. This matters when the handler is
        # built before the caller's parent span scope is active.
        self._baseline_context = otel_context.get_current()
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def _attach(self, run_id: UUID, parent_run_id: UUID | None, span: Span) -> None:
        """Make ``span`` the current OTel context in this task.

        Skips the outermost callback (``parent_run_id is None``). That
        callback fires on the caller's asyncio task and the matching
        end callback runs on a different task, so OTel cannot symmetrically
        detach. The outermost span still serves as a parent for nested
        spans via ``_get_parent_context``.

        For non-outermost callbacks we attach unconditionally. This is
        what makes the LangGraph node span propagate into thread-executor
        node bodies (LangChain's ``run_in_executor`` snapshots
        ``copy_context()`` *after* ``on_chain_start`` returns, so the
        attached span is visible inside the user's node code).

        The asymmetric attach leaks tokens, but that is neutralized by
        ``close()`` resetting the caller's contextvar to the snapshot
        captured in ``__init__``. Because of this, callers should treat
        the handler as a single-use scope around a graph invocation;
        prefer ``async with OTELGraphHandler(ctx) as handler:``.
        """
        if parent_run_id is None:
            return
        try:
            token = otel_context.attach(trace.set_span_in_context(span))
            self._tokens[run_id] = (token, _current_task_id())
        except Exception:
            self._log.debug(
                "Failed to attach OTel context",
                extra={"run_id": str(run_id)},
                exc_info=True,
            )

    def _detach(self, run_id: UUID) -> None:
        """Detach the context for ``run_id`` if still on the same task.

        LangGraph dispatches start/end callbacks on different asyncio
        tasks. Calling ``otel_context.detach`` across tasks triggers a
        ``ValueError`` from ``ContextVar.reset`` (the token was created
        in a different ``contextvars.Context`` copy). We avoid this by
        only detaching when the current task matches the one that
        attached. Otherwise we silently discard the token and rely on
        ``close()`` to restore the caller's baseline context.
        """
        entry = self._tokens.pop(run_id, None)
        if entry is None:
            return
        token, attach_task_id = entry
        if _current_task_id() != attach_task_id:
            # Cross-task: detach would raise ValueError. Skip it;
            # close() will restore the baseline context.
            self._log.debug(
                "Skipping cross-task detach",
                extra={"run_id": str(run_id)},
            )
            return
        try:
            otel_context.detach(token)
        except Exception:
            self._log.debug(
                "Failed to detach context",
                extra={"run_id": str(run_id)},
                exc_info=True,
            )

    def close(self) -> None:
        """Ends active LangGraph spans and restores the caller's tracing context.

        Call this after graph execution, especially when a graph is interrupted
        or cancelled. Safe to call multiple times.
        """
        if not self._baseline_restored:
            try:
                # Intentionally not capturing the returned token: we never
                # detach this attach. See class init for the rationale.
                otel_context.attach(self._baseline_context)
                self._baseline_restored = True
            except Exception:
                self._log.debug(
                    "Failed to restore baseline OTel context", exc_info=True
                )
        self._tokens.clear()

        for run_id, span in list(self._spans.items()):
            try:
                self._log.debug("Closing orphaned span", extra={"run_id": str(run_id)})
                span.set_status(StatusCode.ERROR, "interrupted")
                span.end()
            except Exception:
                self._log.warning(
                    "Failed to close span",
                    extra={"run_id": str(run_id)},
                    exc_info=True,
                )
        self._spans.clear()
        self._node_names.clear()
        self._llm_runs.clear()

    def _get_parent_context(self, parent_run_id: UUID | None) -> Context | None:
        """Gets parent context for span creation.

        Returns context with parent span if parent_run_id exists in _spans,
        otherwise None to use ambient context.
        """
        if parent_run_id is None:
            return None
        parent_span = self._spans.get(parent_run_id)
        if parent_span is None:
            return None
        return trace.set_span_in_context(parent_span)

    def _ancestor_node(self, parent_run_id: UUID | None) -> str | None:
        """Return the immediate parent LangGraph node name, if any.

        One-hop lookup only — LangChain callbacks expose ``parent_run_id``
        but not the full ancestor chain. Covers the standard LangGraph
        shape (node → llm). Nested chains inside a node will not attribute
        to the enclosing node.
        """
        if parent_run_id is None:
            return None
        return self._node_names.get(parent_run_id)

    # --- Chain / node callbacks ---

    def on_chain_start(
        self,
        serialized: dict[str, Any] | None,
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Starts a span for a LangGraph chain or node."""
        try:
            # LangGraph passes name via kwargs; serialized can be None in
            # newer LangChain versions.
            name = (
                kwargs.get("name")
                or (serialized.get("name") if serialized else None)
                or "chain"
            )
            context = self._get_parent_context(parent_run_id)
            span = self._tracer.start_span(
                f"langgraph.node.{name}",
                context=context,
                attributes={"langchain.run_id": str(run_id)},
            )
            if tags:
                span.set_attribute("langchain.tags", tags)
            self._spans[run_id] = span
            self._attach(run_id, parent_run_id, span)
            self._node_names[run_id] = name
        except Exception:
            self._log.warning(
                "on_chain_start failed", extra={"run_id": str(run_id)}, exc_info=True
            )

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Ends the span for a completed LangGraph chain or node."""
        try:
            self._detach(run_id)
            self._node_names.pop(run_id, None)
            span = self._spans.pop(run_id, None)
            if span:
                span.set_status(StatusCode.OK)
                span.end()
        except Exception:
            self._log.warning(
                "on_chain_end failed", extra={"run_id": str(run_id)}, exc_info=True
            )

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Records an error on the span for a failed LangGraph chain or node."""
        try:
            self._detach(run_id)
            self._node_names.pop(run_id, None)
            span = self._spans.pop(run_id, None)
            if span:
                span.set_status(StatusCode.ERROR, str(error))
                span.record_exception(error)
                span.end()
        except Exception:
            self._log.warning(
                "on_chain_error failed", extra={"run_id": str(run_id)}, exc_info=True
            )

    # --- Chat model callbacks ---

    # Note: there is intentionally no ``on_chat_model_end`` /
    # ``on_chat_model_error`` here. LangChain dispatches chat-model end
    # via ``on_llm_end`` / ``on_llm_error`` for both raw LLM and
    # chat-model runs, so adding a chat-model end callback would never
    # fire. The asymmetry is by design.

    def on_chat_model_start(
        self,
        serialized: dict[str, Any] | None,
        messages: list[list[BaseMessage]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Starts a span for a chat model call."""
        try:
            context = self._get_parent_context(parent_run_id)
            span = self._tracer.start_span(
                "langgraph.chat_model",
                context=context,
                attributes={
                    "langchain.run_id": str(run_id),
                    "langchain.chat.message_count": sum(len(m) for m in messages),
                },
            )
            node = self._ancestor_node(parent_run_id)
            if node is not None:
                span.set_attribute("langgraph.node", node)
            if tags:
                span.set_attribute("langchain.tags", tags)
            self._spans[run_id] = span
            self._attach(run_id, parent_run_id, span)
            self._llm_runs[run_id] = node
        except Exception:
            self._log.warning(
                "on_chat_model_start failed",
                extra={"run_id": str(run_id)},
                exc_info=True,
            )

    # --- LLM callbacks ---

    def on_llm_start(
        self,
        serialized: dict[str, Any] | None,
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Starts a span for a language model call."""
        try:
            context = self._get_parent_context(parent_run_id)
            span = self._tracer.start_span(
                "langgraph.llm",
                context=context,
                attributes={
                    "langchain.run_id": str(run_id),
                    "langchain.llm.prompt_count": len(prompts),
                },
            )
            node = self._ancestor_node(parent_run_id)
            if node is not None:
                span.set_attribute("langgraph.node", node)
            self._spans[run_id] = span
            self._attach(run_id, parent_run_id, span)
            self._llm_runs[run_id] = node
        except Exception:
            self._log.warning(
                "on_llm_start failed", extra={"run_id": str(run_id)}, exc_info=True
            )

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Ends the span for a completed language model call."""
        try:
            self._detach(run_id)
            span = self._spans.pop(run_id, None)
            node = self._llm_runs.pop(run_id, None)
            usage: dict[str, Any] = {}
            if span:
                if response.llm_output:
                    if "model" in response.llm_output:
                        span.set_attribute(
                            "langchain.llm.model",
                            response.llm_output["model"],
                        )
                    usage = response.llm_output.get("usage", {}) or {}
                    for key in (
                        "prompt_tokens",
                        "completion_tokens",
                        "total_tokens",
                    ):
                        if key in usage:
                            span.set_attribute(f"langchain.llm.{key}", usage[key])
                span.set_status(StatusCode.OK)
                span.end()
            # Per-node token metric — only when we have both a node and usage.
            if node and usage:
                prompt_tokens = int(usage.get("prompt_tokens", 0) or 0)
                completion_tokens = int(usage.get("completion_tokens", 0) or 0)
                if prompt_tokens > 0 or completion_tokens > 0:
                    record_langgraph_llm_tokens(
                        node=node,
                        prompt_tokens=prompt_tokens,
                        completion_tokens=completion_tokens,
                        agent_type=self._agent_type,
                    )
        except Exception:
            self._log.warning(
                "on_llm_end failed", extra={"run_id": str(run_id)}, exc_info=True
            )

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Records an error on the span for a failed language model call."""
        try:
            self._detach(run_id)
            self._llm_runs.pop(run_id, None)
            span = self._spans.pop(run_id, None)
            if span:
                span.set_status(StatusCode.ERROR, str(error))
                span.record_exception(error)
                span.end()
        except Exception:
            self._log.warning(
                "on_llm_error failed", extra={"run_id": str(run_id)}, exc_info=True
            )

    # --- Tool callbacks ---

    def on_tool_start(
        self,
        serialized: dict[str, Any] | None,
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        """Starts a span for a tool call."""
        try:
            name = (
                kwargs.get("name")
                or (serialized.get("name") if serialized else None)
                or "unknown"
            )
            context = self._get_parent_context(parent_run_id)
            span = self._tracer.start_span(
                f"langgraph.tool.{name}",
                context=context,
                attributes={
                    "langchain.run_id": str(run_id),
                    "langchain.tool.name": name,
                    "tool.kind": "langgraph",
                },
            )
            record_content_event(span, "cwai.agent.tool.input", input_str)
            if tags:
                span.set_attribute("langchain.tags", tags)
            self._spans[run_id] = span
            self._attach(run_id, parent_run_id, span)
            self._tool_runs[run_id] = (time.monotonic(), name)
        except Exception:
            self._log.warning(
                "on_tool_start failed", extra={"run_id": str(run_id)}, exc_info=True
            )

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Ends the span for a completed tool call."""
        try:
            self._detach(run_id)
            span = self._spans.pop(run_id, None)
            if span:
                record_content_event(span, "cwai.agent.tool.result", output)
                span.set_status(StatusCode.OK)
                span.end()
            run = self._tool_runs.pop(run_id, None)
            if run is not None:
                t0, name = run
                duration_ms = (time.monotonic() - t0) * 1000
                record_tools_request(
                    "execute",
                    duration_ms,
                    success=True,
                    tool_name=name,
                    tool_kind="langgraph",
                    agent_type=self._agent_type,
                )
        except Exception:
            self._log.warning(
                "on_tool_end failed", extra={"run_id": str(run_id)}, exc_info=True
            )

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        """Records an error on the span for a failed tool call."""
        try:
            self._detach(run_id)
            span = self._spans.pop(run_id, None)
            if span:
                span.set_status(StatusCode.ERROR, str(error))
                span.record_exception(error)
                span.end()
            run = self._tool_runs.pop(run_id, None)
            if run is not None:
                t0, name = run
                duration_ms = (time.monotonic() - t0) * 1000
                record_tools_request(
                    "execute",
                    duration_ms,
                    success=False,
                    tool_name=name,
                    tool_kind="langgraph",
                    agent_type=self._agent_type,
                )
                record_tools_error(
                    "execute",
                    "execution_error",
                    tool_name=name,
                    tool_kind="langgraph",
                    agent_type=self._agent_type,
                )
        except Exception:
            self._log.warning(
                "on_tool_error failed", extra={"run_id": str(run_id)}, exc_info=True
            )
