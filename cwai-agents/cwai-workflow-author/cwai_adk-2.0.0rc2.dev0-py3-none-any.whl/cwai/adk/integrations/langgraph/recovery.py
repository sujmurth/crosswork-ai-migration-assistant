"""Recovery helper for LangGraph graphs with ``ADKCheckpointer``.

Provides ``invoke_or_resume()``, which detects an existing interrupted
checkpoint and returns it instead of starting the graph again.

Examples:
    from cwai.adk.integrations.langgraph import invoke_or_resume

    result = await invoke_or_resume(graph, input=initial_state, config=thread_config)
    if "__interrupt__" in result:
        # Handle the interrupt using the same shape as graph.ainvoke().
        ...
"""

from __future__ import annotations

from typing import Any

INTERRUPT_KEY = "__interrupt__"


async def invoke_or_resume(
    graph: Any,
    input: dict[str, Any],
    config: dict[str, Any],
) -> dict[str, Any]:
    """Invokes a graph, or recovers from a previous interrupted run.

    Checks the graph's checkpointer for an existing checkpoint with
    unresolved interrupts. If found, returns the checkpointed state
    with ``__interrupt__`` populated, matching the shape of ``ainvoke()``.
    If not found, calls ``graph.ainvoke(input, config)`` normally.

    This lets callers write interrupt-handling code once without
    needing separate initialization and recovery branches.

    Args:
        graph: Compiled LangGraph graph with a checkpointer.
        input: Initial state dict, passed to ``ainvoke()`` on fresh runs.
        config: Thread config, such as ``{"configurable": {"thread_id": "t1"}}``.

    Returns:
        State dict with ``__interrupt__`` if the graph is paused at an interrupt.
    """
    state = await graph.aget_state(config)

    if state.interrupts:
        # Existing checkpoint with unresolved interrupts — recovery path.
        # Return the checkpointed state with __interrupt__ merged in,
        # matching the shape that ainvoke() would return.
        values = state.values if isinstance(state.values, dict) else {}
        return {**values, INTERRUPT_KEY: list(state.interrupts)}

    # No existing interrupt — fresh invoke
    return await graph.ainvoke(input, config=config)
