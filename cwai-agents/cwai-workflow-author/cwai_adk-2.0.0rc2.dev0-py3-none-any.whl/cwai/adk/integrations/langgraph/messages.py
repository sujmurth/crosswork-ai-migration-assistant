"""Message conversion between LangChain and OpenAI formats.

Extracted from the POC adapters for reuse across chat model and
other integration components.
"""

from __future__ import annotations

import json
import uuid
from typing import Any

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)

# Keys that are handled explicitly when converting a tool call dict
# to LangChain's ToolCall format. Everything else is stashed in
# additional_kwargs["_tool_call_extras"] for round-tripping.
_HANDLED_TC_KEYS = frozenset({"id", "type", "function"})


def to_openai_message(msg: BaseMessage) -> dict[str, Any]:
    """Converts a LangChain message to OpenAI dict format."""
    if isinstance(msg, SystemMessage):
        return {"role": "system", "content": msg.content}
    if isinstance(msg, HumanMessage):
        return {"role": "user", "content": msg.content}
    if isinstance(msg, AIMessage):
        result: dict[str, Any] = {
            "role": "assistant",
            "content": msg.content,
        }
        if msg.tool_calls:
            # Per-tool-call extras (e.g. Gemini extra_content with
            # thought_signature) are stored by from_openai_message in
            # additional_kwargs["_tool_call_extras"] keyed by tool call id.
            tc_extras: dict[str, dict[str, Any]] = msg.additional_kwargs.get(
                "_tool_call_extras", {}
            )
            tool_calls_out = []
            for tc in msg.tool_calls:
                tc_dict: dict[str, Any] = {
                    "id": tc["id"],
                    "type": "function",
                    "function": {
                        "name": tc["name"],
                        "arguments": (
                            json.dumps(tc["args"])
                            if isinstance(tc["args"], dict)
                            else tc["args"]
                        ),
                    },
                }
                # Merge back any provider-specific fields that were on
                # the original tool call object.
                extras = tc_extras.get(tc["id"], {})
                for key, value in extras.items():
                    if key not in tc_dict:
                        tc_dict[key] = value
                tool_calls_out.append(tc_dict)
            result["tool_calls"] = tool_calls_out
        # Restore top-level provider-specific fields that were captured
        # in additional_kwargs by from_openai_message.
        for key, value in msg.additional_kwargs.items():
            if key not in result and key != "_tool_call_extras":
                result[key] = value
        return result
    if isinstance(msg, ToolMessage):
        return {
            "role": "tool",
            "tool_call_id": msg.tool_call_id,
            "content": (
                msg.content if isinstance(msg.content, str) else json.dumps(msg.content)
            ),
        }
    return {"role": "user", "content": str(msg.content)}


# Keys that from_openai_message handles explicitly — everything else
# is stashed in additional_kwargs so provider-specific fields like
# Gemini's thought_signature survive the round-trip.
_HANDLED_KEYS = frozenset({"role", "content", "tool_calls"})


def from_openai_message(msg_dict: dict[str, Any]) -> AIMessage:
    """Converts an OpenAI response message dict to a LangChain ``AIMessage``.

    Provider-specific fields beyond ``role``, ``content``, and
    ``tool_calls`` (such as Gemini ``thought_signature``) are preserved
    in ``AIMessage.additional_kwargs`` so they can be replayed on
    subsequent requests.

    Per-tool-call extras (such as ``extra_content`` containing Gemini's
    ``thought_signature``) are stashed in
    ``additional_kwargs["_tool_call_extras"]`` keyed by tool call id.
    """
    content = msg_dict.get("content") or ""
    tool_calls_raw = msg_dict.get("tool_calls", [])
    tool_calls = []
    tc_extras: dict[str, dict[str, Any]] = {}
    for tc in tool_calls_raw:
        fn = tc.get("function", {})
        args_str = fn.get("arguments", "{}")
        try:
            args = json.loads(args_str)
        except (json.JSONDecodeError, TypeError):
            args = {"raw": args_str}
        tc_id = tc.get("id", str(uuid.uuid4()))
        tool_calls.append(
            {
                "id": tc_id,
                "name": fn.get("name", ""),
                "args": args,
            }
        )
        # Capture any extra fields on the tool call itself (e.g.
        # extra_content with thought_signature from Gemini).
        per_tc_extra = {k: v for k, v in tc.items() if k not in _HANDLED_TC_KEYS}
        if per_tc_extra:
            tc_extras[tc_id] = per_tc_extra

    extra = {k: v for k, v in msg_dict.items() if k not in _HANDLED_KEYS}
    if tc_extras:
        extra["_tool_call_extras"] = tc_extras

    return AIMessage(
        content=content,
        tool_calls=tool_calls,
        additional_kwargs=extra,
    )
