"""Integrations with third-party AI frameworks.

Provides adapters for LangChain and LangGraph. Install extras to use:

- ``cwai-adk[langchain]`` for LangChain integration
- ``cwai-adk[langgraph]`` for LangGraph integration (includes LangChain)
"""
