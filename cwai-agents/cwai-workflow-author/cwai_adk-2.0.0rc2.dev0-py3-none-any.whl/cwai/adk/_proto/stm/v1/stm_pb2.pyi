import datetime

from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class STMStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    STM_STATUS_UNSPECIFIED: _ClassVar[STMStatus]
    STM_STATUS_OPEN: _ClassVar[STMStatus]
    STM_STATUS_DELETED: _ClassVar[STMStatus]

class STMErrorCode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    STM_ERROR_CODE_UNSPECIFIED: _ClassVar[STMErrorCode]
    STM_ERROR_NOT_FOUND: _ClassVar[STMErrorCode]
    STM_ERROR_ALREADY_EXISTS: _ClassVar[STMErrorCode]
    STM_ERROR_DELETED: _ClassVar[STMErrorCode]
    STM_ERROR_PAYLOAD_TOO_LARGE: _ClassVar[STMErrorCode]
    STM_ERROR_STM_SIZE_EXCEEDED: _ClassVar[STMErrorCode]
    STM_ERROR_MAX_ENTRIES_EXCEEDED: _ClassVar[STMErrorCode]
    STM_ERROR_INTERNAL: _ClassVar[STMErrorCode]
    STM_ERROR_TTL_OUT_OF_RANGE: _ClassVar[STMErrorCode]
STM_STATUS_UNSPECIFIED: STMStatus
STM_STATUS_OPEN: STMStatus
STM_STATUS_DELETED: STMStatus
STM_ERROR_CODE_UNSPECIFIED: STMErrorCode
STM_ERROR_NOT_FOUND: STMErrorCode
STM_ERROR_ALREADY_EXISTS: STMErrorCode
STM_ERROR_DELETED: STMErrorCode
STM_ERROR_PAYLOAD_TOO_LARGE: STMErrorCode
STM_ERROR_STM_SIZE_EXCEEDED: STMErrorCode
STM_ERROR_MAX_ENTRIES_EXCEEDED: STMErrorCode
STM_ERROR_INTERNAL: STMErrorCode
STM_ERROR_TTL_OUT_OF_RANGE: STMErrorCode

class StateEntry(_message.Message):
    __slots__ = ("entry_id", "sequence_number", "timestamp", "payload")
    ENTRY_ID_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    entry_id: str
    sequence_number: int
    timestamp: _timestamp_pb2.Timestamp
    payload: bytes
    def __init__(self, entry_id: _Optional[str] = ..., sequence_number: _Optional[int] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., payload: _Optional[bytes] = ...) -> None: ...

class StateEntity(_message.Message):
    __slots__ = ("stm_key", "status", "created_at", "last_updated_at", "deleted_at", "entries", "expires_at")
    STM_KEY_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    DELETED_AT_FIELD_NUMBER: _ClassVar[int]
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    stm_key: str
    status: STMStatus
    created_at: _timestamp_pb2.Timestamp
    last_updated_at: _timestamp_pb2.Timestamp
    deleted_at: _timestamp_pb2.Timestamp
    entries: _containers.RepeatedCompositeFieldContainer[StateEntry]
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, stm_key: _Optional[str] = ..., status: _Optional[_Union[STMStatus, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., last_updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., deleted_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., entries: _Optional[_Iterable[_Union[StateEntry, _Mapping]]] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class STMErrorDetail(_message.Message):
    __slots__ = ("code", "message", "current_size", "max_size", "current_count", "max_count")
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    CURRENT_SIZE_FIELD_NUMBER: _ClassVar[int]
    MAX_SIZE_FIELD_NUMBER: _ClassVar[int]
    CURRENT_COUNT_FIELD_NUMBER: _ClassVar[int]
    MAX_COUNT_FIELD_NUMBER: _ClassVar[int]
    code: STMErrorCode
    message: str
    current_size: int
    max_size: int
    current_count: int
    max_count: int
    def __init__(self, code: _Optional[_Union[STMErrorCode, str]] = ..., message: _Optional[str] = ..., current_size: _Optional[int] = ..., max_size: _Optional[int] = ..., current_count: _Optional[int] = ..., max_count: _Optional[int] = ...) -> None: ...

class CreateSTMRequest(_message.Message):
    __slots__ = ("stm_key", "ttl")
    STM_KEY_FIELD_NUMBER: _ClassVar[int]
    TTL_FIELD_NUMBER: _ClassVar[int]
    stm_key: str
    ttl: _duration_pb2.Duration
    def __init__(self, stm_key: _Optional[str] = ..., ttl: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class CreateSTMResponse(_message.Message):
    __slots__ = ("created_at",)
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class AddStateRequest(_message.Message):
    __slots__ = ("stm_key", "payload", "ttl")
    STM_KEY_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    TTL_FIELD_NUMBER: _ClassVar[int]
    stm_key: str
    payload: bytes
    ttl: _duration_pb2.Duration
    def __init__(self, stm_key: _Optional[str] = ..., payload: _Optional[bytes] = ..., ttl: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class AddStateResponse(_message.Message):
    __slots__ = ("entry_id", "sequence_number")
    ENTRY_ID_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    entry_id: str
    sequence_number: int
    def __init__(self, entry_id: _Optional[str] = ..., sequence_number: _Optional[int] = ...) -> None: ...

class GetSTMRequest(_message.Message):
    __slots__ = ("stm_key",)
    STM_KEY_FIELD_NUMBER: _ClassVar[int]
    stm_key: str
    def __init__(self, stm_key: _Optional[str] = ...) -> None: ...

class GetSTMResponse(_message.Message):
    __slots__ = ("stm",)
    STM_FIELD_NUMBER: _ClassVar[int]
    stm: StateEntity
    def __init__(self, stm: _Optional[_Union[StateEntity, _Mapping]] = ...) -> None: ...

class GetStreamHeader(_message.Message):
    __slots__ = ("stm_key", "status", "created_at", "last_updated_at", "deleted_at", "expires_at")
    STM_KEY_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    DELETED_AT_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    stm_key: str
    status: STMStatus
    created_at: _timestamp_pb2.Timestamp
    last_updated_at: _timestamp_pb2.Timestamp
    deleted_at: _timestamp_pb2.Timestamp
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, stm_key: _Optional[str] = ..., status: _Optional[_Union[STMStatus, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., last_updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., deleted_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class GetStreamResponse(_message.Message):
    __slots__ = ("header", "entry")
    HEADER_FIELD_NUMBER: _ClassVar[int]
    ENTRY_FIELD_NUMBER: _ClassVar[int]
    header: GetStreamHeader
    entry: StateEntry
    def __init__(self, header: _Optional[_Union[GetStreamHeader, _Mapping]] = ..., entry: _Optional[_Union[StateEntry, _Mapping]] = ...) -> None: ...

class DeleteSTMRequest(_message.Message):
    __slots__ = ("stm_key",)
    STM_KEY_FIELD_NUMBER: _ClassVar[int]
    stm_key: str
    def __init__(self, stm_key: _Optional[str] = ...) -> None: ...

class DeleteSTMResponse(_message.Message):
    __slots__ = ("deleted_at",)
    DELETED_AT_FIELD_NUMBER: _ClassVar[int]
    deleted_at: _timestamp_pb2.Timestamp
    def __init__(self, deleted_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ExtendLifespanRequest(_message.Message):
    __slots__ = ("stm_key", "ttl")
    STM_KEY_FIELD_NUMBER: _ClassVar[int]
    TTL_FIELD_NUMBER: _ClassVar[int]
    stm_key: str
    ttl: _duration_pb2.Duration
    def __init__(self, stm_key: _Optional[str] = ..., ttl: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class ExtendLifespanResponse(_message.Message):
    __slots__ = ("expires_at",)
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...
