from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MessageType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RESULT: _ClassVar[MessageType]
    PARTIAL_RESULT: _ClassVar[MessageType]
    MORE_INFO: _ClassVar[MessageType]
    NOTIFICATION: _ClassVar[MessageType]
    REQUEST: _ClassVar[MessageType]

class ControlMessageType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CREATE_AGENT: _ClassVar[ControlMessageType]
    REMOVE_AGENT: _ClassVar[ControlMessageType]
RESULT: MessageType
PARTIAL_RESULT: MessageType
MORE_INFO: MessageType
NOTIFICATION: MessageType
REQUEST: MessageType
CREATE_AGENT: ControlMessageType
REMOVE_AGENT: ControlMessageType

class Message(_message.Message):
    __slots__ = ("id", "reply_to", "thread_id", "type", "from_agent", "from_agent_id", "to_agent", "to_agent_id", "user_message", "system_message", "rbac_ctx", "observability_ctx")
    ID_FIELD_NUMBER: _ClassVar[int]
    REPLY_TO_FIELD_NUMBER: _ClassVar[int]
    THREAD_ID_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    FROM_AGENT_FIELD_NUMBER: _ClassVar[int]
    FROM_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TO_AGENT_FIELD_NUMBER: _ClassVar[int]
    TO_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    USER_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    SYSTEM_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    RBAC_CTX_FIELD_NUMBER: _ClassVar[int]
    OBSERVABILITY_CTX_FIELD_NUMBER: _ClassVar[int]
    id: str
    reply_to: str
    thread_id: str
    type: MessageType
    from_agent: str
    from_agent_id: int
    to_agent: str
    to_agent_id: int
    user_message: str
    system_message: str
    rbac_ctx: str
    observability_ctx: str
    def __init__(self, id: _Optional[str] = ..., reply_to: _Optional[str] = ..., thread_id: _Optional[str] = ..., type: _Optional[_Union[MessageType, str]] = ..., from_agent: _Optional[str] = ..., from_agent_id: _Optional[int] = ..., to_agent: _Optional[str] = ..., to_agent_id: _Optional[int] = ..., user_message: _Optional[str] = ..., system_message: _Optional[str] = ..., rbac_ctx: _Optional[str] = ..., observability_ctx: _Optional[str] = ...) -> None: ...

class ControlMessage(_message.Message):
    __slots__ = ("id", "reply_to", "thread_id", "type", "runtime_id", "agent_id", "rbac_ctx", "observability_ctx")
    ID_FIELD_NUMBER: _ClassVar[int]
    REPLY_TO_FIELD_NUMBER: _ClassVar[int]
    THREAD_ID_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    RBAC_CTX_FIELD_NUMBER: _ClassVar[int]
    OBSERVABILITY_CTX_FIELD_NUMBER: _ClassVar[int]
    id: str
    reply_to: str
    thread_id: str
    type: ControlMessageType
    runtime_id: int
    agent_id: int
    rbac_ctx: str
    observability_ctx: str
    def __init__(self, id: _Optional[str] = ..., reply_to: _Optional[str] = ..., thread_id: _Optional[str] = ..., type: _Optional[_Union[ControlMessageType, str]] = ..., runtime_id: _Optional[int] = ..., agent_id: _Optional[int] = ..., rbac_ctx: _Optional[str] = ..., observability_ctx: _Optional[str] = ...) -> None: ...

class CreateAgentRequest(_message.Message):
    __slots__ = ("name", "parent_id", "thread_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    PARENT_ID_FIELD_NUMBER: _ClassVar[int]
    THREAD_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    parent_id: int
    thread_id: str
    def __init__(self, name: _Optional[str] = ..., parent_id: _Optional[int] = ..., thread_id: _Optional[str] = ...) -> None: ...

class CreateAgentResponse(_message.Message):
    __slots__ = ("instance_id", "error")
    INSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    instance_id: int
    error: str
    def __init__(self, instance_id: _Optional[int] = ..., error: _Optional[str] = ...) -> None: ...

class RemoveAgentRequest(_message.Message):
    __slots__ = ("name", "instance_id")
    NAME_FIELD_NUMBER: _ClassVar[int]
    INSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    name: str
    instance_id: int
    def __init__(self, name: _Optional[str] = ..., instance_id: _Optional[int] = ...) -> None: ...

class RemoveAgentResponse(_message.Message):
    __slots__ = ("error",)
    ERROR_FIELD_NUMBER: _ClassVar[int]
    error: str
    def __init__(self, error: _Optional[str] = ...) -> None: ...

class SendAgentMessageRequest(_message.Message):
    __slots__ = ("message",)
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    message: Message
    def __init__(self, message: _Optional[_Union[Message, _Mapping]] = ...) -> None: ...

class SendAgentMessageResponse(_message.Message):
    __slots__ = ("error",)
    ERROR_FIELD_NUMBER: _ClassVar[int]
    error: str
    def __init__(self, error: _Optional[str] = ...) -> None: ...

class SendControlMessageRequest(_message.Message):
    __slots__ = ("message",)
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    message: ControlMessage
    def __init__(self, message: _Optional[_Union[ControlMessage, _Mapping]] = ...) -> None: ...

class SendControlMessageResponse(_message.Message):
    __slots__ = ("error",)
    ERROR_FIELD_NUMBER: _ClassVar[int]
    error: str
    def __init__(self, error: _Optional[str] = ...) -> None: ...

class ReceiveAgentMessageRequest(_message.Message):
    __slots__ = ("agent_name", "agent_id", "timeout_ms", "from_agent_id")
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    FROM_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    agent_id: int
    timeout_ms: int
    from_agent_id: int
    def __init__(self, agent_name: _Optional[str] = ..., agent_id: _Optional[int] = ..., timeout_ms: _Optional[int] = ..., from_agent_id: _Optional[int] = ...) -> None: ...

class ReceiveControlMessageRequest(_message.Message):
    __slots__ = ("runtime_id", "timeout_ms")
    RUNTIME_ID_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    runtime_id: int
    timeout_ms: int
    def __init__(self, runtime_id: _Optional[int] = ..., timeout_ms: _Optional[int] = ...) -> None: ...

class ReceiveAgentMessageResponse(_message.Message):
    __slots__ = ("data_message", "error")
    DATA_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    data_message: Message
    error: str
    def __init__(self, data_message: _Optional[_Union[Message, _Mapping]] = ..., error: _Optional[str] = ...) -> None: ...

class ReceiveControlMessageResponse(_message.Message):
    __slots__ = ("control_message", "error")
    CONTROL_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    control_message: ControlMessage
    error: str
    def __init__(self, control_message: _Optional[_Union[ControlMessage, _Mapping]] = ..., error: _Optional[str] = ...) -> None: ...

class AgentHandshakeRequest(_message.Message):
    __slots__ = ("runtime_id",)
    RUNTIME_ID_FIELD_NUMBER: _ClassVar[int]
    runtime_id: int
    def __init__(self, runtime_id: _Optional[int] = ...) -> None: ...

class AgentHandshakeResponse(_message.Message):
    __slots__ = ("settings", "llm_proxy_info", "error")
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    LLM_PROXY_INFO_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    settings: bytes
    llm_proxy_info: bytes
    error: str
    def __init__(self, settings: _Optional[bytes] = ..., llm_proxy_info: _Optional[bytes] = ..., error: _Optional[str] = ...) -> None: ...

class AgentLLMModelDetails(_message.Message):
    __slots__ = ("model",)
    MODEL_FIELD_NUMBER: _ClassVar[int]
    model: str
    def __init__(self, model: _Optional[str] = ...) -> None: ...

class GetLLMsRequest(_message.Message):
    __slots__ = ("agent_name",)
    AGENT_NAME_FIELD_NUMBER: _ClassVar[int]
    agent_name: str
    def __init__(self, agent_name: _Optional[str] = ...) -> None: ...

class GetLLMsResponse(_message.Message):
    __slots__ = ("models", "error")
    MODELS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    models: _containers.RepeatedCompositeFieldContainer[AgentLLMModelDetails]
    error: str
    def __init__(self, models: _Optional[_Iterable[_Union[AgentLLMModelDetails, _Mapping]]] = ..., error: _Optional[str] = ...) -> None: ...

class ListAgentsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class Agent(_message.Message):
    __slots__ = ("name", "full_name", "description", "tags", "image", "image_tag", "version", "source", "settings", "metadata", "capabilities", "allowed_roles", "status", "type", "created_at")
    NAME_FIELD_NUMBER: _ClassVar[int]
    FULL_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_TAG_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    ALLOWED_ROLES_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    name: str
    full_name: str
    description: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    image: str
    image_tag: str
    version: str
    source: str
    settings: _struct_pb2.Struct
    metadata: _struct_pb2.Struct
    capabilities: _containers.RepeatedScalarFieldContainer[str]
    allowed_roles: _containers.RepeatedScalarFieldContainer[str]
    status: str
    type: str
    created_at: str
    def __init__(self, name: _Optional[str] = ..., full_name: _Optional[str] = ..., description: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., image: _Optional[str] = ..., image_tag: _Optional[str] = ..., version: _Optional[str] = ..., source: _Optional[str] = ..., settings: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., capabilities: _Optional[_Iterable[str]] = ..., allowed_roles: _Optional[_Iterable[str]] = ..., status: _Optional[str] = ..., type: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class ListAgentsResponse(_message.Message):
    __slots__ = ("agents",)
    AGENTS_FIELD_NUMBER: _ClassVar[int]
    agents: _containers.RepeatedCompositeFieldContainer[Agent]
    def __init__(self, agents: _Optional[_Iterable[_Union[Agent, _Mapping]]] = ...) -> None: ...
