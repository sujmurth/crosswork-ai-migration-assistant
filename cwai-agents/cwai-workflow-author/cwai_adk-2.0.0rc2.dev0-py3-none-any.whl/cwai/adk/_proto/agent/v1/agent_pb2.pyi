from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StatusType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OK: _ClassVar[StatusType]
    ERROR: _ClassVar[StatusType]

class EnrollmentAction(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ACTION_UNKNOWN: _ClassVar[EnrollmentAction]
    ACTION_ADD: _ClassVar[EnrollmentAction]
    ACTION_UPDATE: _ClassVar[EnrollmentAction]
    ACTION_DELETE: _ClassVar[EnrollmentAction]
OK: StatusType
ERROR: StatusType
ACTION_UNKNOWN: EnrollmentAction
ACTION_ADD: EnrollmentAction
ACTION_UPDATE: EnrollmentAction
ACTION_DELETE: EnrollmentAction

class Enrollment(_message.Message):
    __slots__ = ("agent", "action")
    AGENT_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    agent: AgentInfo
    action: EnrollmentAction
    def __init__(self, agent: _Optional[_Union[AgentInfo, _Mapping]] = ..., action: _Optional[_Union[EnrollmentAction, str]] = ...) -> None: ...

class AgentInfo(_message.Message):
    __slots__ = ("name", "full_name", "image", "version", "capabilities", "metadata", "settings", "schemas")
    NAME_FIELD_NUMBER: _ClassVar[int]
    FULL_NAME_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    SCHEMAS_FIELD_NUMBER: _ClassVar[int]
    name: str
    full_name: str
    image: str
    version: str
    capabilities: _containers.RepeatedCompositeFieldContainer[Capability]
    metadata: AgentMetadata
    settings: _struct_pb2.Struct
    schemas: AgentSchemas
    def __init__(self, name: _Optional[str] = ..., full_name: _Optional[str] = ..., image: _Optional[str] = ..., version: _Optional[str] = ..., capabilities: _Optional[_Iterable[_Union[Capability, _Mapping]]] = ..., metadata: _Optional[_Union[AgentMetadata, _Mapping]] = ..., settings: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., schemas: _Optional[_Union[AgentSchemas, _Mapping]] = ...) -> None: ...

class AgentMetadata(_message.Message):
    __slots__ = ("tags", "description", "custom_fields")
    class CustomFieldsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    TAGS_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    CUSTOM_FIELDS_FIELD_NUMBER: _ClassVar[int]
    tags: _containers.RepeatedScalarFieldContainer[str]
    description: str
    custom_fields: _containers.ScalarMap[str, str]
    def __init__(self, tags: _Optional[_Iterable[str]] = ..., description: _Optional[str] = ..., custom_fields: _Optional[_Mapping[str, str]] = ...) -> None: ...

class AgentSchemas(_message.Message):
    __slots__ = ("request_schema", "response_schema", "settings_schema")
    REQUEST_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    RESPONSE_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    request_schema: str
    response_schema: str
    settings_schema: str
    def __init__(self, request_schema: _Optional[str] = ..., response_schema: _Optional[str] = ..., settings_schema: _Optional[str] = ...) -> None: ...

class Capability(_message.Message):
    __slots__ = ("property", "string_value", "int_value", "double_value", "bool_value", "object_value", "list_value")
    PROPERTY_FIELD_NUMBER: _ClassVar[int]
    STRING_VALUE_FIELD_NUMBER: _ClassVar[int]
    INT_VALUE_FIELD_NUMBER: _ClassVar[int]
    DOUBLE_VALUE_FIELD_NUMBER: _ClassVar[int]
    BOOL_VALUE_FIELD_NUMBER: _ClassVar[int]
    OBJECT_VALUE_FIELD_NUMBER: _ClassVar[int]
    LIST_VALUE_FIELD_NUMBER: _ClassVar[int]
    property: str
    string_value: str
    int_value: int
    double_value: float
    bool_value: bool
    object_value: _struct_pb2.Struct
    list_value: CapabilityList
    def __init__(self, property: _Optional[str] = ..., string_value: _Optional[str] = ..., int_value: _Optional[int] = ..., double_value: _Optional[float] = ..., bool_value: bool = ..., object_value: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., list_value: _Optional[_Union[CapabilityList, _Mapping]] = ...) -> None: ...

class CapabilityList(_message.Message):
    __slots__ = ("capabilities",)
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    capabilities: _containers.RepeatedCompositeFieldContainer[Capability]
    def __init__(self, capabilities: _Optional[_Iterable[_Union[Capability, _Mapping]]] = ...) -> None: ...

class RegisterRequest(_message.Message):
    __slots__ = ("enrollment",)
    ENROLLMENT_FIELD_NUMBER: _ClassVar[int]
    enrollment: Enrollment
    def __init__(self, enrollment: _Optional[_Union[Enrollment, _Mapping]] = ...) -> None: ...

class RegisterResponse(_message.Message):
    __slots__ = ("status", "msg")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MSG_FIELD_NUMBER: _ClassVar[int]
    status: StatusType
    msg: str
    def __init__(self, status: _Optional[_Union[StatusType, str]] = ..., msg: _Optional[str] = ...) -> None: ...

class HandshakeRequest(_message.Message):
    __slots__ = ("taskID", "correlationID")
    TASKID_FIELD_NUMBER: _ClassVar[int]
    CORRELATIONID_FIELD_NUMBER: _ClassVar[int]
    taskID: int
    correlationID: int
    def __init__(self, taskID: _Optional[int] = ..., correlationID: _Optional[int] = ...) -> None: ...

class HandshakeResponse(_message.Message):
    __slots__ = ("status", "msg", "query", "settings", "llm_proxy_info")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MSG_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    LLM_PROXY_INFO_FIELD_NUMBER: _ClassVar[int]
    status: StatusType
    msg: str
    query: bytes
    settings: bytes
    llm_proxy_info: bytes
    def __init__(self, status: _Optional[_Union[StatusType, str]] = ..., msg: _Optional[str] = ..., query: _Optional[bytes] = ..., settings: _Optional[bytes] = ..., llm_proxy_info: _Optional[bytes] = ...) -> None: ...

class HeartbeatRequest(_message.Message):
    __slots__ = ("taskID", "correlationID")
    TASKID_FIELD_NUMBER: _ClassVar[int]
    CORRELATIONID_FIELD_NUMBER: _ClassVar[int]
    taskID: int
    correlationID: int
    def __init__(self, taskID: _Optional[int] = ..., correlationID: _Optional[int] = ...) -> None: ...

class HeartbeatResponse(_message.Message):
    __slots__ = ("status", "msg")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MSG_FIELD_NUMBER: _ClassVar[int]
    status: StatusType
    msg: str
    def __init__(self, status: _Optional[_Union[StatusType, str]] = ..., msg: _Optional[str] = ...) -> None: ...

class ResultRequest(_message.Message):
    __slots__ = ("taskID", "correlationID", "result", "status", "msg")
    TASKID_FIELD_NUMBER: _ClassVar[int]
    CORRELATIONID_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MSG_FIELD_NUMBER: _ClassVar[int]
    taskID: int
    correlationID: int
    result: bytes
    status: StatusType
    msg: str
    def __init__(self, taskID: _Optional[int] = ..., correlationID: _Optional[int] = ..., result: _Optional[bytes] = ..., status: _Optional[_Union[StatusType, str]] = ..., msg: _Optional[str] = ...) -> None: ...

class ResultResponse(_message.Message):
    __slots__ = ("status", "msg")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MSG_FIELD_NUMBER: _ClassVar[int]
    status: StatusType
    msg: str
    def __init__(self, status: _Optional[_Union[StatusType, str]] = ..., msg: _Optional[str] = ...) -> None: ...
