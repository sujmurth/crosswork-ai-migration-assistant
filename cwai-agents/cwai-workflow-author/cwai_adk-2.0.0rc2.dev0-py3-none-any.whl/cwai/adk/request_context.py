"""Context propagation for outbound requests.

All ADK clients use RequestContext to inject identity, auth, and OTEL
trace context into HTTP headers and gRPC metadata automatically.
"""

from dataclasses import dataclass

from opentelemetry import propagate


@dataclass(frozen=True)
class RequestContext:
    """Immutable context holder for a single task execution.

    Built by the framework when a task is dispatched. Shared clients
    call get_headers() or get_grpc_metadata() on each outbound request.
    """

    agent_id: str
    """Identifier for this agent instance."""
    thread_id: str
    """Conversation or session identifier for the current task."""
    agent_type: str
    """Agent type name for this agent."""
    agent_instance_id: str
    """Instance identifier within the runtime."""
    auth_token: str | None = None
    """Authentication token to forward on outbound requests, if one is available."""

    def get_headers(self) -> dict[str, str]:
        """Build HTTP headers with OTEL trace context and app-level identity."""
        headers: dict[str, str] = {}

        # OTEL trace/span propagation (W3C traceparent, tracestate)
        propagate.inject(headers)

        headers["X-Agent-ID"] = self.agent_id
        headers["X-Thread-ID"] = self.thread_id
        headers["X-Agent-Type"] = self.agent_type
        headers["X-Agent-Instance-ID"] = self.agent_instance_id

        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"

        return headers

    def get_grpc_metadata(self) -> tuple[tuple[str, str], ...]:
        """Build gRPC metadata from headers, with lowercased keys."""
        return tuple((k.lower(), v) for k, v in self.get_headers().items())
