"""Crosswork AI Agent Development Kit.

Framework for building AI agents on the Crosswork AI platform.
"""

from importlib.metadata import version

from cwai.adk import features
from cwai.adk.agent_instance import AgentInstance
from cwai.adk.auth import Caller, GroupRoles
from cwai.adk.client.dra import DRAResponse
from cwai.adk.constants import ROUTING_AGENT_ID
from cwai.adk.context import Context
from cwai.adk.observability.tracing import traced_span
from cwai.adk.request_context import RequestContext
from cwai.adk.tools import Tool, ToolExecutor
from cwai.adk.types import (
    AssistantMessage,
    Message,
    MessageFormat,
    MessageTag,
    MessageType,
    Result,
    ResultStatus,
    UserReply,
)
from cwai.adk.types.rag import (
    RAGCollectionInfo,
    RAGDocument,
    RAGDocumentSection,
    RAGSearchResult,
    RAGUploadResult,
)
from cwai.adk.types.stm import (
    StateEntity,
    StateEntry,
    STMStatus,
)

__version__ = version("cwai-adk")

__all__ = [
    "__version__",
    "AgentInstance",
    "AssistantMessage",
    "Caller",
    "Context",
    "DRAResponse",
    "GroupRoles",
    "Message",
    "MessageFormat",
    "MessageTag",
    "RAGCollectionInfo",
    "RAGDocument",
    "RAGDocumentSection",
    "RAGSearchResult",
    "RAGUploadResult",
    "MessageType",
    "RequestContext",
    "ROUTING_AGENT_ID",
    "Result",
    "ResultStatus",
    "STMStatus",
    "StateEntity",
    "StateEntry",
    "Tool",
    "ToolExecutor",
    "UserReply",
    "features",
    "traced_span",
]
