"""LLM tool infrastructure for ADK clients.

Provides the `Tool` dataclass for defining LLM-callable tools and
`ToolExecutor` for executing tool calls from LLM responses.

Examples:
    from cwai.adk import ToolExecutor

    # Combine tools from multiple clients
    tools = ctx.kg.tools + ctx.rag.tools
    executor = ToolExecutor(tools)

    # Pass schemas to LLM
    response = await ctx.llm.complete(
        messages=messages,
        tools=executor.schemas,
        tool_choice="auto",
    )

    # Execute any tool calls
    tool_calls = response.message.get("tool_calls", [])
    if tool_calls:
        results = await executor.execute(tool_calls)
        for tc, result in zip(tool_calls, results):
            messages.append({
                "role": "tool",
                "tool_call_id": tc["id"],
                "content": result,
            })
"""

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from opentelemetry import trace

from cwai.adk.observability._labels import _resolve_agent_type
from cwai.adk.observability.metrics import record_tools_error, record_tools_request
from cwai.adk.observability.trace_events import record_content_event
from cwai.adk.request_context import RequestContext

tracer = trace.get_tracer("cwai.adk.tools")


@dataclass(frozen=True)
class Tool:
    """An LLM-callable tool with schema and executor.

    Tools are exposed by ADK clients via their `.tools` property and can
    be combined and passed to `ToolExecutor` for execution.

    Attributes:
        name: Tool name (such as "kg_query"). Should be short and match
            the client prefix for consistency.
        description: Human-readable description for the LLM. Should
            explain what the tool does and when to use it.
        parameters: JSON Schema for tool parameters. Must be a valid
            JSON Schema object with "type": "object".
        execute: Async function that executes the tool. Takes keyword
            arguments matching the parameters schema and returns a
            JSON string (result or error object).
        title: Human-readable display title from MCP, or None.
        annotations: MCP tool annotations (readOnlyHint, destructiveHint,
            etc.), or None if not provided.
        output_schema: JSON Schema for the tool's output, or None.

    Examples:
        Tool(
            name="kg_query",
            description="Execute a GraphQL query against the Knowledge Graph.",
            parameters={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "GraphQL query"},
                },
                "required": ["query"],
            },
            execute=self._tool_query,
        )
    """

    name: str
    description: str
    parameters: dict[str, Any]
    execute: Callable[..., Awaitable[str]]
    title: str | None = None
    annotations: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None

    def to_openai_schema(self) -> dict[str, Any]:
        """Convert to OpenAI function calling format.

        Returns:
            Dict in OpenAI tool format with "type": "function" and nested "function" object containing name, description, and parameters.
        """
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


class ToolExecutor:
    """Executes tool calls from LLM responses.

    Provides a bridge between LLM tool calls and ADK client tools.
    Handles argument parsing, parallel execution, and error handling.

    Args:
        tools: List of Tool objects to register. Duplicate names will
            use the last tool registered.
        request_context: Optional request context. When provided, the
            calling agent type is added as a label on tool execution
            metrics.

    Examples:
        tools = ctx.kg.tools + ctx.rag.tools
        executor = ToolExecutor(tools)

        response = await ctx.llm.complete(
            messages=messages,
            tools=executor.schemas,
        )

        tool_calls = response.message.get("tool_calls", [])
        results = await executor.execute(tool_calls)

        # Append results to messages for next LLM turn
        for tc, result in zip(tool_calls, results):
            messages.append({
                "role": "tool",
                "tool_call_id": tc["id"],
                "content": result,
            })
    """

    def __init__(
        self,
        tools: list[Tool],
        *,
        request_context: RequestContext | None = None,
    ) -> None:
        self._tools = {t.name: t for t in tools}
        self._request_context = request_context

    @property
    def _agent_type(self) -> str | None:
        return _resolve_agent_type(self)

    @property
    def schemas(self) -> list[dict[str, Any]]:
        """OpenAI-format tool schemas for ctx.llm.complete().

        Returns:
            List of tool schemas in OpenAI function calling format.
        """
        return [t.to_openai_schema() for t in self._tools.values()]

    @property
    def tools(self) -> list[Tool]:
        """List of registered tools."""
        return list(self._tools.values())

    def get(self, name: str) -> Tool | None:
        """Get a tool by name.

        Args:
            name: Tool name to look up.

        Returns:
            Tool if found, None otherwise.
        """
        return self._tools.get(name)

    async def execute(
        self,
        tool_calls: list[dict[str, Any]],
    ) -> list[str]:
        """Execute tool calls in parallel and return results.

        Args:
            tool_calls: List of tool call dicts from LLM response
                (response.message["tool_calls"]). Each dict should have
                "function" with "name" and "arguments" keys.

        Returns:
            List of result strings (JSON) in same order as input tool_calls. Errors are returned as JSON objects with an "error" key rather than raising exceptions.
        """
        if not tool_calls:
            return []

        # Execute all tools in parallel
        tasks = [self._execute_one(tc) for tc in tool_calls]
        return list(await asyncio.gather(*tasks))

    async def execute_one(self, tool_call: dict[str, Any]) -> str:
        """Execute a single tool call.

        Args:
            tool_call: Tool call dict from LLM response.

        Returns:
            Result string (JSON) or error object.
        """
        return await self._execute_one(tool_call)

    async def _execute_one(self, tool_call: dict[str, Any]) -> str:
        """Internal: execute a single tool call with error handling."""
        fn = tool_call.get("function", {})
        name = fn.get("name", "")
        args_str = fn.get("arguments", "{}")

        with tracer.start_as_current_span("tools.execute") as span:
            span.set_attribute("tools.tool_name", name)
            span.set_attribute("tool.kind", "native")
            # Record tool input as span event
            if args_str and args_str != "{}":
                record_content_event(span, "cwai.agent.tool.input", args_str)
            t0 = time.monotonic()

            def _record(success: bool, error_type: str | None = None) -> None:
                # All five outcome paths emit the same shape; the only
                # variations are success and (on failure) the error label.
                duration_ms = (time.monotonic() - t0) * 1000
                record_tools_request(
                    "execute",
                    duration_ms,
                    success=success,
                    tool_name=name,
                    tool_kind="native",
                    agent_type=self._agent_type,
                )
                if error_type is not None:
                    record_tools_error(
                        "execute",
                        error_type,
                        tool_name=name,
                        tool_kind="native",
                        agent_type=self._agent_type,
                    )

            tool = self._tools.get(name)
            if tool is None:
                span.set_status(trace.StatusCode.ERROR, f"Unknown tool: {name}")
                _record(False, "unknown_tool")
                return json.dumps({"error": f"Unknown tool: {name}"})

            try:
                args = json.loads(args_str)
            except json.JSONDecodeError as e:
                span.set_status(trace.StatusCode.ERROR, "Invalid arguments")
                _record(False, "invalid_arguments")
                return json.dumps({"error": f"Invalid arguments: {e}"})

            try:
                result = await tool.execute(**args)
            except TypeError as e:
                # Catch argument mismatch errors (missing/extra args)
                span.set_status(trace.StatusCode.ERROR, "Invalid arguments")
                _record(False, "invalid_arguments")
                return json.dumps({"error": f"Invalid arguments: {e}"})
            except Exception as e:
                span.set_status(trace.StatusCode.ERROR, str(e))
                span.record_exception(e)
                _record(False, "execution_error")
                return json.dumps({"error": f"Tool execution failed: {e}"})

            _record(True)
            record_content_event(span, "cwai.agent.tool.result", result)
            return result
