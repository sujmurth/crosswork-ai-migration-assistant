"""Context object for agent task execution.

Created by the framework per task. Provides access to platform services
and side-effect methods for sending messages and spawning agents.
"""

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx
from opentelemetry import trace

from cwai.adk.agent_instance import AgentInstance
from cwai.adk.auth import Caller, parse_jwt
from cwai.adk.client import (
    AgentCatalogClientProtocol,
    KnowledgeGraphClientProtocol,
    LLMClientProtocol,
    McpClientProtocol,
    RAGClientProtocol,
    STMClientProtocol,
    ToolsClientProtocol,
)
from cwai.adk.client.http import create_http_client
from cwai.adk.config import TLSConfig
from cwai.adk.constants import ROUTING_AGENT_ID
from cwai.adk.observability.logging import TaskLogger
from cwai.adk.observability.metrics import record_subagent_call
from cwai.adk.observability.trace_events import record_content_event
from cwai.adk.observability.tracing import get_task_tracer
from cwai.adk.request_context import RequestContext
from cwai.adk.types import (
    AssistantMessage,
    MessageFormat,
    MessageTag,
    MessageType,
    SendPartialCallback,
    UserReply,
)

if TYPE_CHECKING:
    from cwai.adk.client.agents import AgentCatalogClient
    from cwai.adk.client.dra import DRAClient
    from cwai.adk.client.kg import KGClient
    from cwai.adk.client.rag import RAGClient
    from cwai.adk.client.scoped_stm import ScopedSTMClient
    from cwai.adk.client.tools import ToolsClient
    from cwai.adk.types import Message, Result


# Routing agent name matches Go: agent.RoutingAgentName.
_ROUTING_AGENT_NAME = "Routing"


def _normalize_sender_id(sender_id: int | AgentInstance | None) -> int | None:
    """Normalize a public sender filter to a platform instance ID."""
    if sender_id is None:
        return None
    if isinstance(sender_id, AgentInstance):
        return sender_id.instance_id
    if isinstance(sender_id, bool):
        raise TypeError("sender_id must be an int, AgentInstance, or None")
    if isinstance(sender_id, int):
        if sender_id < 0:
            raise ValueError("sender_id must be non-negative")
        return sender_id
    raise TypeError("sender_id must be an int, AgentInstance, or None")


def _parse_result_message(msg: "Message") -> "Result":
    """Parse a RESULT message into a Result object.

    Used by call_agent() to convert the raw Message from the spawned
    agent into a structured Result.
    """
    # Import here to avoid circular dependency at module load time
    from cwai.adk.types import Result, ResultStatus

    if msg.type != MessageType.RESULT:
        return Result(
            status=ResultStatus.ERROR,
            message=AssistantMessage(content=f"Unexpected message type: {msg.type}"),
        )

    try:
        data = json.loads(msg.user_message)
        status_str = data.get("status", "complete")
        status = ResultStatus.ERROR if status_str == "error" else ResultStatus.COMPLETE

        message = None
        if "message" in data and data["message"]:
            msg_data = data["message"]
            message = AssistantMessage(
                content=msg_data.get("content", ""),
                format=MessageFormat(msg_data.get("format", "text")),
            )

        return Result(
            status=status,
            message=message,
            data=data.get("data"),
        )
    except (json.JSONDecodeError, TypeError, KeyError) as e:
        return Result(
            status=ResultStatus.ERROR,
            message=AssistantMessage(content=f"Failed to parse result: {e}"),
        )


class UserInteraction:
    """User interaction methods for human-in-the-loop workflows.

    Provides a high-level API for agents to communicate with users
    through the routing agent. Access via ``ctx.user``.

    Examples:
        # Ask user for approval (blocks until reply) - @agent.on_run only
        reply = await ctx.user.ask(AssistantMessage(
            content="Approve deployment?",
            format=MessageFormat.MARKDOWN,
            follow_ups=["yes", "no"],
        ))
        if reply.text == "yes":
            ...

        # Ask without waiting - works in both @agent.on_run and @agent.on_message
        await ctx.user.ask_nowait(AssistantMessage(
            content="Approve?",
            follow_ups=["yes", "no"],
        ))
        # In on_message: return None, reply comes as next msg
        # In on_run: call ctx.wait_for_message() when ready

        # Notify user (non-blocking)
        await ctx.user.notify("Deployment started...")
    """

    def __init__(self, ctx: "Context") -> None:
        self._ctx = ctx

    async def _ask_nowait(self, message: AssistantMessage) -> None:
        """Send a MORE_INFO message without tracing.

        Shared by ask() and ask_nowait().
        """
        await self._ctx._send_message_raw(
            _ROUTING_AGENT_NAME,
            ROUTING_AGENT_ID,
            type=MessageType.MORE_INFO,
            user_message=message.to_json(),
        )

    async def ask(self, message: AssistantMessage) -> UserReply:
        """Ask user for input. Blocks until reply.

        Send the message to the user and wait for their response.
        This is equivalent to calling ``ask_nowait()`` followed by
        ``ctx.wait_for_message()``.

        Only available in ``@agent.on_run`` handlers.

        Args:
            message: The message to display to the user.

        Returns:
            UserReply with the user's text response and parsed JSON data.

        Raises:
            RuntimeError: If called from an ``@agent.on_message`` handler
                (use ``ask_nowait()`` instead).
        """
        with self._ctx.tracer.start_as_current_span("agent.user.ask") as span:
            record_content_event(span, "cwai.agent.user.ask.content", message.to_json())

            await self._ask_nowait(message)

            reply_msg = await self._ctx._wait_for_message(sender_id=ROUTING_AGENT_ID)

            # Parse JSON if possible
            data: dict[str, Any] = {}
            try:
                data = json.loads(reply_msg.user_message)
            except (json.JSONDecodeError, TypeError):
                pass

            reply = UserReply(text=reply_msg.user_message, data=data)
            record_content_event(span, "cwai.agent.user.ask.reply", reply.text)
            return reply

    async def ask_nowait(self, message: AssistantMessage) -> None:
        """Ask user for input without waiting for reply.

        Send a MORE_INFO message to the user. Use this in
        ``@agent.on_message`` handlers where you cannot block,
        or in ``@agent.on_run`` handlers when you need more control
        over the wait.

        In ``@agent.on_message`` handlers:
            - The reply arrives as the next ``msg`` to your handler
            - Remember to return ``None`` to keep the task alive

        In ``@agent.on_run`` handlers:
            - Call ``ctx.wait_for_message(sender_id=ROUTING_AGENT_ID)`` when
              ready to receive the routing/user reply

        Args:
            message: The message to display to the user.

        Examples:
            # In an @agent.on_message handler:
            await ctx.user.ask_nowait(AssistantMessage(
                content="Approve?",
                follow_ups=["yes", "no"],
            ))
            ctx.state["awaiting_approval"] = True
            return None  # Reply comes as next msg

        Examples:
            # In an @agent.on_run handler with manual control:
            await ctx.user.ask_nowait(AssistantMessage(content="Approve?"))
            await ctx.user.notify("Processing in background...")
            reply_msg = await ctx.wait_for_message(sender_id=ROUTING_AGENT_ID)
        """
        with self._ctx.tracer.start_as_current_span("agent.user.ask_nowait") as span:
            record_content_event(span, "cwai.agent.user.ask.content", message.to_json())
            await self._ask_nowait(message)

    async def notify(
        self,
        message: str | AssistantMessage,
        tag: MessageTag = MessageTag.NONE,
    ) -> None:
        """Send a notification to the user. Non-blocking.

        Send a notification message to the user without waiting
        for a response.

        Args:
            message: Text string or AssistantMessage to display.
                If string, treated as markdown content.
            tag: Visual styling hint (ignored if message is AssistantMessage).
        """
        if isinstance(message, str):
            assistant_msg = AssistantMessage(
                content=message,
                format=MessageFormat.MARKDOWN,
                tag=tag,
            )
        else:
            assistant_msg = message

        with self._ctx.tracer.start_as_current_span("agent.user.notify") as span:
            span.set_attribute("message.tag", tag.name)
            record_content_event(
                span, "cwai.agent.user.notify.content", assistant_msg.to_json()
            )
            await self._ctx._send_message_raw(
                _ROUTING_AGENT_NAME,
                ROUTING_AGENT_ID,
                type=MessageType.NOTIFICATION,
                user_message=assistant_msg.to_json(),
            )


@dataclass
class Context:
    """Everything an agent needs for task execution.

    Created by the framework. Provides access to platform services
    with context propagation handled automatically.
    """

    # Task identity
    agent_id: str
    """Platform-assigned identifier for this agent instance."""
    thread_id: str
    """Conversation or session identifier for the current task."""
    agent_type: str
    """Registered name of this agent."""
    agent_instance_id: str
    """Instance identifier within the runtime."""
    parent_instance_id: str | None = None
    """Parent agent instance identifier, if this agent was created by another agent; otherwise, None."""

    # Task data
    settings: dict[str, Any] = field(default_factory=dict)
    """Agent settings for this task."""

    # Mutable state dict, persisted by framework between handler invocations
    state: dict[str, Any] = field(default_factory=dict)
    """Task state that the agent can update and that the framework saves between handler invocations."""

    # Client factories (injected by framework, not part of public API)
    _llm: LLMClientProtocol | None = field(default=None, repr=False)
    _http: httpx.AsyncClient | None = field(default=None, repr=False)
    _stm: STMClientProtocol | None = field(default=None, repr=False)
    _kg: KnowledgeGraphClientProtocol | None = field(default=None, repr=False)
    _rag: RAGClientProtocol | None = field(default=None, repr=False)
    _agents: AgentCatalogClientProtocol | None = field(default=None, repr=False)
    _dra: Any | None = field(default=None, repr=False)  # DRAClientProtocol
    _tools: ToolsClientProtocol | None = field(default=None, repr=False)
    _mcp: McpClientProtocol | None = field(default=None, repr=False)
    _send_message_fn: Any = field(default=None, repr=False)
    _spawn_agent_fn: Any = field(default=None, repr=False)
    _remove_agent_fn: Any = field(default=None, repr=False)
    _save_state_fn: Any = field(default=None, repr=False)
    _call_subagent_fn: Any = field(default=None, repr=False)
    _request_context: RequestContext | None = field(default=None, repr=False)
    _tls_config: TLSConfig | None = field(default=None, repr=False)
    _log: TaskLogger | None = field(default=None, repr=False)

    # Injected by framework for on_run handlers; None for on_message handlers.
    # Supports any object with an async get() -> Message method.
    _message_queue: Any | None = field(default=None, repr=False)

    # Injectable sleep function (for testing). Defaults to asyncio.sleep.
    _sleep_fn: Any = field(default=None, repr=False)

    # Callback for sending partial results (injected by framework).
    _send_partial: SendPartialCallback | None = field(default=None, repr=False)

    # Per-agent persistent storage root. The framework resolves this from
    # the FORESIGHT_DATA_PATH env var injected into the pod, or /mnt/data
    # as a default. Tests can override via mock_context(data_dir=...).
    # Note: set at construction only; the data_dir property is a
    # @cached_property and caches on first access, so post-init mutation
    # of _data_dir is ignored.
    _data_dir: Path | None = field(default=None, repr=False)

    # Tracked child agent instances spawned by this context.
    _children: list[AgentInstance] = field(default_factory=list, repr=False)

    @property
    def request_context(self) -> RequestContext | None:
        """Per-request context (agent type, tenant, headers) for this task.

        Returns ``None`` when the context was not constructed with a
        request context (for example, some test harnesses).
        """
        return self._request_context

    @cached_property
    def caller(self) -> Caller | None:
        """Identity of the user who initiated this task.

        Extracted from the authentication token provided by the platform.
        Returns ``None`` when no token is available (for example, in
        development mode or test harnesses without a caller configured).
        """
        if self._request_context is None:
            return None
        return parse_jwt(self._request_context.auth_token)

    @cached_property
    def llm(self) -> LLMClientProtocol:
        """LLM client for chat completions via the llm-proxy service.

        Routes requests through the platform's llm-proxy, which handles
        provider selection, auth, retries, and OTEL instrumentation.
        Supports model fallback lists and streaming responses.

        Examples:
            # Single completion
            response = await ctx.llm.complete(
                messages=[{"role": "user", "content": "Hello"}],
                model="gpt-4o",
            )
            print(response.content)

        Examples:
            # Streaming
            async for chunk in ctx.llm.complete_stream(
                messages=[{"role": "user", "content": "Hello"}],
            ):
                print(chunk.content, end="")
        """
        if self._llm is None:
            raise RuntimeError("LLM client not configured")
        return self._llm

    @cached_property
    def data_dir(self) -> Path:
        """Per-agent persistent storage root.

        Returns the on-disk root where this agent can read and write
        files that survive pod restarts. The platform mounts a per-agent
        subdirectory of the shared PVC here, so each agent type sees an
        isolated namespace.

        Resolution order:
            1. Explicit override passed to ``mock_context(data_dir=...)``.
            2. ``FORESIGHT_DATA_PATH`` env var (injected by the framework).
            3. ``/mnt/data`` default.

        Returns:
            Path to the agent's storage root.

        Examples:

            # Write a file the agent owns
            (ctx.data_dir / "state.json").write_text(json.dumps(state))

            # List uploads passed in via task params
            for upload_id in msg.query.get("file-ids", []):
                upload_dir = ctx.data_dir / upload_id
                for f in upload_dir.iterdir():
                    process(f)
        """
        if self._data_dir is not None:
            return self._data_dir
        return Path(os.environ.get("FORESIGHT_DATA_PATH", "/mnt/data"))

    @cached_property
    def user(self) -> UserInteraction:
        """User interaction methods for human-in-the-loop workflows.

        Provides methods to communicate with the user through the
        routing agent.

        Examples:
            # Ask user for approval (blocks until reply)
            reply = await ctx.user.ask(AssistantMessage(
                content="Approve deployment?",
                format=MessageFormat.MARKDOWN,
                follow_ups=["yes", "no"],
            ))
            if reply.text == "yes":
                ...

            # Notify user (non-blocking)
            await ctx.user.notify("Deployment started...")
        """
        return UserInteraction(self)

    @cached_property
    def http(self) -> httpx.AsyncClient:
        """HTTP client with automatic OTEL instrumentation and context propagation.

        Every request automatically includes task identity headers and
        creates OTEL spans with method, url, and status_code attributes.

        Examples:
            resp = await ctx.http.get("https://api.example.com/data")
            data = resp.json()

            resp = await ctx.http.post(
                "https://api.example.com/submit",
                json={"key": "value"},
                timeout=60.0,
            )
        """
        if self._http is not None:
            return self._http
        # Lazy-create with request context for header injection
        return create_http_client(self._request_context)

    @cached_property
    def kg(self) -> "KGClient":
        """Knowledge Graph client for GraphQL queries.

        Queries network topology, device state, and relationships stored
        in the KG service. The schema is dynamic — use ``get_skill()``
        for LLM context or ``get_schema()`` for full SDL.

        Examples:
            # Get the skill doc for LLM-assisted query construction
            skill = await ctx.kg.get_skill()

            # Execute a GraphQL query
            result = await ctx.kg.query('''
                query GetNodes {
                    queryNode(first: 10) {
                        nodeId
                        name
                        role
                    }
                }
            ''')
            nodes = result["queryNode"]
        """
        if self._kg is not None:
            # Use injected client (for testing or framework-provided)
            return self._kg  # type: ignore[return-value]
        # Lazy-create with default URL and request context
        import os

        from cwai.adk.client.kg import KGClient

        base_url = os.environ.get("CWAI_KG_URL", "https://knowledge-graph:8443")

        # Build TLS config: use injected config, or create from env vars
        tls_config = self._tls_config
        if tls_config is None:
            tls_config = TLSConfig.from_env()

        return KGClient(
            base_url,
            self._request_context,
            tls_config=tls_config,
            log=self._log,
        )

    @cached_property
    def rag(self) -> "RAGClient":
        """RAG/Context service client for document search and management.

        Stores and retrieves document sections as embedding vectors with
        semantic search, tag filtering, and date-based expiration.

        Examples:
            # Search for relevant documents
            results = await ctx.rag.search(
                "my-collection",
                "BGP configuration best practices",
                tags=["networking"],
                limit=5,
            )

            # Upload new document sections
            from cwai.adk.types.rag import RAGDocumentSection
            from datetime import date

            section = RAGDocumentSection(
                search_column="BGP peer configuration guide",
                content={"body": "Configure BGP peers with..."},
                date_created=date.today(),
                date_valid_until=date(2026, 1, 1),
                tags=["networking", "bgp"],
            )
            result = await ctx.rag.upload("my-collection", [section])
        """
        if self._rag is not None:
            return self._rag  # type: ignore[return-value]
        # Lazy-create with default URL and request context
        import os

        from cwai.adk.client.rag import RAGClient

        base_url = os.environ.get("CWAI_RAG_URL", "https://kontext:8000/api/v1/context")

        # Build TLS config: use injected config, or create from env vars.
        tls_config = self._tls_config
        if tls_config is None:
            tls_config = TLSConfig.from_env()

        return RAGClient(
            base_url,
            self._request_context,
            tls_config=tls_config,
            log=self._log,
        )

    @cached_property
    def tools(self) -> "ToolsClient":
        """Tools/MCP client for discovering and invoking platform tools.

        Connects to the mcp-gateway service via MCP Streamable HTTP
        transport. Tools are lazy-loaded on first access.

        Supports injection at two levels:
        - ``_tools``: inject a ToolsClient or MockToolsClient directly
        - ``_mcp``: inject an McpClient or MockMcpClient; ToolsClient
          is built automatically on top

        Examples:
            # List available tools
            tool_list = await ctx.tools.list_tools()

            # Call a tool directly
            result = await ctx.tools.call_tool("show_interfaces", {"device": "rtr1"})

            # Use with ToolExecutor
            executor = ToolExecutor(await ctx.tools.list_tools())
        """
        if self._tools is not None:
            return self._tools  # type: ignore[return-value]

        from cwai.adk.client.tools import ToolsClient

        # If an McpClient was injected, build ToolsClient on top of it
        if self._mcp is not None:
            return ToolsClient(
                self._mcp,
                request_context=self._request_context,
                log=self._log,
            )

        # Lazy-create both McpClient and ToolsClient from environment
        import os

        from cwai.adk.client.mcp import McpClient

        base_url = os.environ.get("CWAI_TOOLS_URL", "https://mcp-gateway:5000/mcp")

        tls_config = self._tls_config
        if tls_config is None:
            tls_config = TLSConfig.from_env()

        mcp = McpClient(
            base_url,
            self._request_context,
            tls_config=tls_config,
            log=self._log,
        )
        # Store so context teardown can close it. Use object.__setattr__
        # because Context is a frozen dataclass; direct assignment would fail.
        object.__setattr__(self, "_mcp", mcp)

        return ToolsClient(
            mcp,
            request_context=self._request_context,
            log=self._log,
        )

    @cached_property
    def agents(self) -> "AgentCatalogClient":
        """Agent Catalog client for discovering available agent types.

        Lists agent types registered with the Crosswork AI platform.

        Examples:
            # List all available agents
            agent_types = await ctx.agents.list_types()

            # Filter by type or capability
            builtin_agents = [a for a in agent_types if a.type == "BUILTIN"]
            llm_capable = [a for a in agent_types if "llm-proxy" in a.capabilities]
        """
        if self._agents is not None:
            # Use injected client (for testing or framework-provided)
            return self._agents  # type: ignore[return-value]
        # Lazy-create with default URL and request context
        import os

        from cwai.adk.client.agents import AgentCatalogClient

        host = os.environ.get("FORESIGHT_SERVICE_HOST", "foresight")
        port = int(os.environ.get("FORESIGHT_GRPC_PORT", "50051"))

        # Build TLS config: use injected config, or create from env vars
        tls_config = self._tls_config
        if tls_config is None:
            tls_config = TLSConfig.from_env()

        return AgentCatalogClient(
            host,
            self._request_context,
            port=port,
            tls_config=tls_config,
            log=self._log,
        )

    @cached_property
    def dra(self) -> "DRAClient":
        """DRA Gateway client for accessing Data Retrieval Adapters.

        Provides access to DRAs through the centralized gateway. Create
        gRPC stubs from the channel and use call_stream() (preferred) or
        call_unary() for automatic metadata injection, tracing, and metrics.

        Examples:
            from cwai.adk.proto.dra.v2 import deviceGrouping_pb2 as dg_pb2
            from cwai.adk.proto.dra.v2 import deviceGrouping_pb2_grpc as dg_grpc
            from cwai.adk.proto.dra.v2 import draCommon_pb2 as common_pb2

            await ctx.dra.connect()
            stub = dg_grpc.DeviceGroupingServiceStub(ctx.dra.channel)
            request = dg_pb2.GetDeviceGroupsServiceRequest(
                context=common_pb2.RequestContext(taskID=0, userID=0)
            )

            async for response in ctx.dra.call_stream(
                "get_device_groups", stub.GetDeviceGroups, request
            ):
                print(f"From DRA: {response.context.draID}")
                for group in response.groups:
                    print(f"  - {group.groupName}")
        """
        if self._dra is not None:
            # Use injected client (for testing or framework-provided)
            return self._dra
        # Lazy-create with default URL and request context
        import os

        from cwai.adk.client.dra import DRAClient

        if self._request_context is None:
            self.log.warning(
                "Creating DRA client without request context"
                " - RBAC will not be propagated"
            )

        gateway_url = os.environ.get("CWAI_DRA_GATEWAY_URL", "dra-gateway:50051")
        client = DRAClient(gateway_url, self._request_context, log=self._log)
        return client

    @property
    def log(self) -> logging.LoggerAdapter:
        """Logger with automatic task metadata injection.

        Every log call includes agent_id, thread_id, agent_type, and
        agent_instance_id in the JSON output. Additional fields can
        be passed via ``extra={}``::

            ctx.log.info("Processing", extra={"item_count": 42})
        """
        if self._log is None:
            raise RuntimeError("Logger not configured")
        return self._log

    @property
    def tracer(self) -> trace.Tracer:
        """Tracer for creating spans within this task.

        Spans created with this tracer appear as children of the
        framework's ``task.execute`` span::

            with ctx.tracer.start_as_current_span("my.operation") as span:
                span.set_attribute("key", "value")
                ...
        """
        return get_task_tracer()

    async def _send_message_raw(
        self,
        agent: str,
        agent_id: int,
        *,
        user_message: str = "",
        system_message: str = "",
        type: MessageType = MessageType.REQUEST,
        reply_to: str = "",
    ) -> None:
        """Send a message without tracing. Used internally by UserInteraction."""
        if self._send_message_fn is None:
            raise RuntimeError("send_message not configured")
        await self._send_message_fn(
            agent,
            agent_id,
            user_message=user_message,
            system_message=system_message,
            type=type,
            reply_to=reply_to,
        )

    async def send_message(
        self,
        agent: "str | AgentInstance",
        agent_id: int = 0,
        *,
        user_message: str = "",
        system_message: str = "",
        type: MessageType = MessageType.REQUEST,
        reply_to: str = "",
    ) -> None:
        """Send a message to another agent.

        Args:
            agent: Agent type name (str) or an ``AgentInstance`` returned
                by ``spawn_agent()``. If you pass an ``AgentInstance``,
                ``agent_id`` is ignored.
            agent_id: Instance ID of the target agent. Required when
                ``agent`` is a string, ignored when it's an
                ``AgentInstance``.
            user_message: User-visible message content.
            system_message: System or internal message content.
            type: Message type.
            reply_to: Message ID this is a reply to.

        Examples:
            # Using AgentInstance (preferred)
            agent = await ctx.spawn_agent("worker", user_message="init")
            await ctx.send_message(agent, user_message="more work")

        Examples:
            # Using raw type name and ID
            await ctx.send_message("worker", 42, user_message="hello")
        """
        if self._send_message_fn is None:
            raise RuntimeError("send_message not configured")
        # Resolve AgentInstance to (name, id) pair
        if isinstance(agent, AgentInstance):
            agent_name = agent.agent_type
            agent_id = agent.instance_id
        else:
            agent_name = agent
        with self.tracer.start_as_current_span("agent.send_message") as span:
            span.set_attribute("target.agent_type", agent_name)
            span.set_attribute("target.agent_id", agent_id)
            span.set_attribute("message.type", type.name)
            if user_message:
                record_content_event(span, "cwai.agent.message.user", user_message)
            if system_message:
                record_content_event(span, "cwai.agent.message.system", system_message)
            await self._send_message_raw(
                agent_name,
                agent_id,
                user_message=user_message,
                system_message=system_message,
                type=type,
                reply_to=reply_to,
            )

    async def spawn_agent(
        self,
        agent_type: str,
        *,
        user_message: str = "",
    ) -> AgentInstance:
        """Spawn an agent instance and return a handle to it.

        Creates a new instance of the specified agent type on the
        platform. The returned ``AgentInstance`` can be used to send
        messages, stop the agent, or manage the agent lifecycle with an async context manager.

        Args:
            agent_type: Name of the agent type to spawn.
            user_message: Initial message content sent to the agent.

        Returns:
            An ``AgentInstance`` handle for the spawned agent.

        Raises:
            RuntimeError: If spawn_agent is not configured.

        Examples:
            agent = await ctx.spawn_agent("worker", user_message="go")
            await agent.send_message(user_message="more work")
            await agent.stop()

        Examples:
            # With context manager for automatic cleanup
            async with await ctx.spawn_agent("echo", user_message="hi") as agent:
                reply = await ctx.wait_for_message(sender_id=agent)
        """
        if self._spawn_agent_fn is None:
            raise RuntimeError("spawn_agent not configured")
        with self.tracer.start_as_current_span("agent.spawn_agent") as span:
            span.set_attribute("target.agent_type", agent_type)
            t0 = time.monotonic()
            success = False
            try:
                instance_id = await self._spawn_agent_fn(
                    agent_type, user_message=user_message
                )
                agent = AgentInstance(self, agent_type, instance_id)
                self._children.append(agent)
                success = True
                return agent
            finally:
                duration_ms = (time.monotonic() - t0) * 1000
                record_subagent_call(
                    mode="spawn",
                    target_agent_type=agent_type,
                    duration_ms=duration_ms,
                    success=success,
                    agent_type=self.agent_type,
                )

    async def stop_agent(self, agent: AgentInstance) -> None:
        """Stop a previously spawned agent instance.

        Sends a ``RemoveAgent`` request to the platform to stop the target agent.
        The operation is idempotent: it succeeds silently if the agent
        has already exited.

        Args:
            agent: The ``AgentInstance`` to stop (returned by
                ``spawn_agent()``).

        Raises:
            RuntimeError: If stop_agent is not configured (no transport).

        Examples:
            agent = await ctx.spawn_agent("worker", user_message="task")
            # ... later ...
            await ctx.stop_agent(agent)
        """
        if self._remove_agent_fn is None:
            raise RuntimeError("stop_agent not configured")
        with self.tracer.start_as_current_span("agent.stop_agent") as span:
            span.set_attribute("target.agent_type", agent.agent_type)
            span.set_attribute("target.instance_id", agent.instance_id)
            t0 = time.monotonic()
            success = False
            try:
                await self._remove_agent_fn(agent.agent_type, str(agent.instance_id))
                success = True
            finally:
                duration_ms = (time.monotonic() - t0) * 1000
                record_subagent_call(
                    mode="stop",
                    target_agent_type=agent.agent_type,
                    duration_ms=duration_ms,
                    success=success,
                    agent_type=self.agent_type,
                )
            if agent in self._children:
                self._children.remove(agent)

    async def _stop_all_children(self) -> None:
        """Stop all tracked child agents. Best-effort, logs errors."""
        if not self._children:
            return
        self.log.info(
            "Stopping %d children",
            len(self._children),
            extra={
                "agent_id": self.agent_id,
                "agent_type": self.agent_type,
                "child_count": len(self._children),
            },
        )
        # Copy list since stop_agent mutates _children
        children = list(self._children)
        for child in children:
            try:
                await self.stop_agent(child)
            except Exception:
                self.log.warning(
                    "Failed to stop child agent",
                    exc_info=True,
                    extra={
                        "child_agent_type": child.agent_type,
                        "child_instance_id": child.instance_id,
                    },
                )

    async def call_subagent(
        self,
        agent_name: str,
        query: dict[str, Any] | None = None,
    ) -> "Result":
        """Call a local sub-agent and wait for its result.

        Invokes a named agent registered with ``@agent.on_run("name")``
        in the same process. The sub-agent runs with its own context
        (fresh state, derived task_id) but shares the same LLM and STM
        clients.

        This is a synchronous request-response call — the sub-agent
        runs to completion and returns a ``Result``.

        Args:
            agent_name: Name of the registered sub-agent.
            query: Query dict passed as ``msg.query`` to the sub-agent.

        Returns:
            The ``Result`` returned by the sub-agent handler.

        Raises:
            ValueError: If no agent with the given name is registered.
            RuntimeError: If ``call_subagent`` is not configured.

        Examples:
            result = await ctx.call_subagent("analyzer", query={"prompt": "check BGP"})
            findings = result.data.get("findings", "")

        See Also:
            - ``call_agent()``: For external agents in separate containers
        """
        if self._call_subagent_fn is None:
            raise RuntimeError("call_subagent not configured")

        with self.tracer.start_as_current_span("agent.call_subagent") as span:
            span.set_attribute("target.agent_name", agent_name)
            t0 = time.monotonic()
            success = False
            try:
                result = await self._call_subagent_fn(
                    agent_name,
                    query=query,
                )
                success = True
                return result
            finally:
                duration_ms = (time.monotonic() - t0) * 1000
                record_subagent_call(
                    mode="local",
                    target_agent_type=agent_name,
                    duration_ms=duration_ms,
                    success=success,
                    agent_type=self.agent_type,
                )

    async def call_agent(
        self,
        agent_type: str,
        query: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
    ) -> "Result":
        """Spawn an external agent and wait for its result.

        Creates a new instance of the specified agent type, sends it a
        request with the given query, and waits for its RESULT message.
        The spawned agent runs in a separate container/process.

        Args:
            agent_type: Name of the agent type to spawn (such as "demo-hello").
            query: Query dict sent as the request payload. Will be JSON-encoded
                and available as ``msg.query`` in the spawned agent.
            timeout: Maximum seconds to wait for result. None means wait
                indefinitely (default). Consider setting a reasonable timeout
                for production use.

        Returns:
            The Result returned by the spawned agent, with status, message, and data fields populated.

        Raises:
            TimeoutError: If timeout expires before receiving a result.
            RuntimeError: If called from @agent.on_message handler (requires
                @agent.on_run for message queue support).

        Examples:
            # Simple call
            result = await ctx.call_agent("demo-hello", query={"person": "Alice"})
            if result.message:
                print(result.message.content)  # "Hello Alice!"

            # With timeout
            result = await ctx.call_agent(
                "analyzer",
                query={"target": "10.0.0.1"},
                timeout=30.0,
            )

        Note:
            Only available in ``@agent.on_run`` handlers.

        See Also:
            - ``call_subagent()``: For local sub-agents in the same process
            - ``spawn_agent()``: Fire-and-forget without waiting for result
        """
        if self._spawn_agent_fn is None:
            raise RuntimeError("call_agent not configured")
        if self._message_queue is None:
            raise RuntimeError(
                "call_agent() is only available in @agent.on_run handlers"
            )

        with self.tracer.start_as_current_span("agent.call_agent") as span:
            span.set_attribute("target.agent_type", agent_type)
            t0 = time.monotonic()
            success = False
            try:
                # Encode query as JSON
                user_message = json.dumps(query) if query else "{}"

                # Spawn the agent and track as child
                instance_id = await self._spawn_agent_fn(
                    agent_type, user_message=user_message
                )
                agent = AgentInstance(self, agent_type, instance_id)
                self._children.append(agent)

                # Wait for result with optional timeout
                try:
                    if timeout is not None:
                        msg = await asyncio.wait_for(
                            self._wait_for_message(sender_id=agent.instance_id),
                            timeout=timeout,
                        )
                    else:
                        msg = await self._wait_for_message(sender_id=agent.instance_id)
                except (TimeoutError, asyncio.CancelledError):
                    # Stop the orphaned child on timeout/cancellation.
                    # Shield from cancellation so stop_agent completes
                    # even if our task is being cancelled.
                    try:
                        await asyncio.shield(self.stop_agent(agent))
                    except BaseException:
                        # Catches CancelledError from shield + any transport error
                        self.log.warning(
                            "Failed to stop orphaned child in call_agent cleanup",
                            exc_info=True,
                        )

                    raise

                # Child completed - remove from tracking
                if agent in self._children:
                    self._children.remove(agent)

                # Parse the result message into a Result object
                result = _parse_result_message(msg)
                success = True
                return result
            finally:
                duration_ms = (time.monotonic() - t0) * 1000
                record_subagent_call(
                    mode="call",
                    target_agent_type=agent_type,
                    duration_ms=duration_ms,
                    success=success,
                    agent_type=self.agent_type,
                )

    @cached_property
    def stm(self) -> "ScopedSTMClient":
        """STM client for persistent storage beyond ctx.state.

        Keys are automatically scoped to this task. The 'state' and
        'recovery' labels are reserved for framework use.

        Examples:
            # Create and use a custom STM
            await ctx.stm.create("conversation-history")
            await ctx.stm.add("conversation-history", json.dumps(messages).encode())

            # Retrieve later
            entity = await ctx.stm.get("conversation-history")
            if entity and entity.entries:
                messages = json.loads(entity.entries[-1].payload)

            # Clean up when done
            await ctx.stm.delete("conversation-history")
        """
        if self._stm is None:
            raise RuntimeError("STM client not configured")
        # Import here to avoid circular dependency
        from cwai.adk.client.scoped_stm import ScopedSTMClient

        return ScopedSTMClient(
            self._stm,
            self.agent_type,
            self.agent_id,
        )

    async def save_state(self) -> None:
        """Explicitly persist ctx.state to STM.

        The framework automatically persists state after each handler
        invocation. Use this method to checkpoint state mid-handler,
        for example before a risky external call or during long-running
        operations.

        Examples:
            ctx.state["step"] = 1
            await ctx.save_state()  # Checkpoint before external call

            response = await risky_external_call()

            ctx.state["step"] = 2
            ctx.state["response"] = response
            # Framework will auto-persist after handler returns
        """
        if self._save_state_fn is None:
            raise RuntimeError("save_state not configured")
        await self._save_state_fn()

    async def sleep(self, seconds: float) -> None:
        """Sleep for the specified duration.

        Use this instead of ``asyncio.sleep()`` to allow tests to
        skip delays by injecting a no-op sleep function.

        Examples:
            await ctx.sleep(1.0)  # Waits 1 second in production, instant in tests
        """
        if self._sleep_fn is not None:
            await self._sleep_fn(seconds)
        else:
            await asyncio.sleep(seconds)

    async def _wait_for_message(
        self,
        *,
        sender_id: int | AgentInstance | None = None,
    ) -> "Message":
        """Wait for the next inbound message without emitting a span.

        Used internally by higher-level helpers that have their own spans.
        """
        normalized_sender_id = _normalize_sender_id(sender_id)
        log_extra: dict[str, Any] = {
            "agent_id": self.agent_id,
            "thread_id": self.thread_id,
        }
        if normalized_sender_id is not None:
            log_extra["from_agent_id"] = normalized_sender_id
        if self._log is not None:
            self.log.info("Waiting for message", extra=log_extra)
        if normalized_sender_id is None:
            msg = await self._message_queue.get()  # type: ignore[union-attr]
        else:
            msg = await self._message_queue.get(sender_id=normalized_sender_id)  # type: ignore[union-attr]
        received_extra: dict[str, Any] = {
            "agent_id": self.agent_id,
            "thread_id": self.thread_id,
            "message_id": msg.id,
            "sender": msg.sender,
        }
        if normalized_sender_id is not None:
            received_extra["from_agent_id"] = normalized_sender_id
        if self._log is not None:
            self.log.info(
                "Received message from wait_for_message",
                extra=received_extra,
            )
        return msg

    async def wait_for_message(
        self,
        *,
        sender_id: int | AgentInstance | None = None,
    ) -> "Message":
        """Wait for the next inbound message.

        Only available in ``@agent.on_run`` handlers. Suspends the
        handler coroutine until a message arrives on the task queue.

        Args:
            sender_id: Optional sender filter. Pass an ``AgentInstance`` or
                non-negative sender instance ID to wait only for messages
                from that source. ``None`` keeps the existing unfiltered
                behavior. Use ``ROUTING_AGENT_ID`` to explicitly wait for
                routing-agent or user-originated messages.

        Examples:
            child = await ctx.spawn_agent("worker", user_message="go")
            reply = await ctx.wait_for_message(sender_id=child)

        Examples:
            first = await ctx.wait_for_message()
            follow_up = await ctx.wait_for_message(sender_id=first.sender_id)

        Examples:
            # Advanced: wait for a routing/user-originated message.
            reply = await ctx.wait_for_message(sender_id=ROUTING_AGENT_ID)

        Raises:
            RuntimeError: If called from an ``@agent.on_message`` handler
                (where ``_message_queue`` is None).
            ValueError: If ``sender_id`` is a negative integer.
            TypeError: If ``sender_id`` is not an int, AgentInstance, or None.
        """
        if self._message_queue is None:
            raise RuntimeError(
                "wait_for_message() is only available in @agent.on_run handlers"
            )
        normalized_sender_id = _normalize_sender_id(sender_id)
        with self.tracer.start_as_current_span("agent.wait_for_message") as span:
            if normalized_sender_id is not None:
                span.set_attribute("from_agent_id", normalized_sender_id)
            msg = await self._wait_for_message(sender_id=normalized_sender_id)
            span.set_attribute("message.sender", msg.sender or "")
            span.set_attribute("message.type", msg.type.name if msg.type else "")
            if msg.user_message:
                record_content_event(
                    span, "cwai.agent.wait_for_message.content", msg.user_message
                )
            return msg

    async def send_partial_result(
        self,
        message: AssistantMessage | None = None,
        data: dict[str, Any] | None = None,
    ) -> None:
        """Send a partial result to the platform.

        Use this to send progress updates or intermediate results while
        the task continues. The task completes when the handler returns
        a ``Result``. Works in both ``@agent.on_run`` and
        ``@agent.on_message`` handlers.

        Args:
            message: Optional message to display in the UI.
            data: Optional structured data.

        Raises:
            ValueError: If both message and data are None.
            RuntimeError: If partial results are not supported by the
                current transport (such as V1 protocol).

        Note:
            Sub-agents (invoked via ``ctx.call_subagent()``) cannot send
            partial results to the platform. Calls are logged as warnings
            and ignored. Sub-agents run synchronously in-process without
            a platform connection.

        Examples:
            @agent.on_run("my-agent")
            async def run(ctx: Context, msg: Message) -> Result:
                await ctx.send_partial_result(
                    message=AssistantMessage(content="Processing step 1...")
                )
                # ... do work ...
                await ctx.send_partial_result(
                    message=AssistantMessage(content="Processing step 2..."),
                    data={"progress": 50},
                )
                return Result(message=AssistantMessage(content="Done"))
        """
        if message is None and data is None:
            raise ValueError("At least one of message or data must be provided")
        if self._send_partial is None:
            raise RuntimeError(
                "send_partial_result is not available. "
                "This may be because the transport does not support partial results."
            )
        with self.tracer.start_as_current_span("agent.send_partial_result") as span:
            span.set_attribute("partial.has_message", message is not None)
            span.set_attribute("partial.has_data", data is not None)
            if message is not None and getattr(message, "content", None) is not None:
                # Best-effort byte size of the textual message content.
                try:
                    span.set_attribute(
                        "partial.message_size_bytes",
                        len(message.content.encode("utf-8")),
                    )
                except Exception:
                    pass
            if data is not None:
                try:
                    span.set_attribute(
                        "partial.data_size_bytes",
                        len(json.dumps(data).encode("utf-8")),
                    )
                except Exception:
                    pass
            await self._send_partial(message, data)
