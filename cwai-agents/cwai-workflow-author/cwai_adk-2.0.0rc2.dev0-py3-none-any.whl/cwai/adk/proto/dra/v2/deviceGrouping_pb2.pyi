from cwai.adk.proto.dra.v2 import draCommon_pb2 as _draCommon_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GroupID(_message.Message):
    __slots__ = ("groupID", "groupName", "controllerType")
    GROUPID_FIELD_NUMBER: _ClassVar[int]
    GROUPNAME_FIELD_NUMBER: _ClassVar[int]
    CONTROLLERTYPE_FIELD_NUMBER: _ClassVar[int]
    groupID: str
    groupName: str
    controllerType: str
    def __init__(self, groupID: _Optional[str] = ..., groupName: _Optional[str] = ..., controllerType: _Optional[str] = ...) -> None: ...

class DeviceID(_message.Message):
    __slots__ = ("deviceID", "deviceName")
    DEVICEID_FIELD_NUMBER: _ClassVar[int]
    DEVICENAME_FIELD_NUMBER: _ClassVar[int]
    deviceID: str
    deviceName: str
    def __init__(self, deviceID: _Optional[str] = ..., deviceName: _Optional[str] = ...) -> None: ...

class GetDeviceGroupsServiceRequest(_message.Message):
    __slots__ = ("context",)
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ...) -> None: ...

class GetDeviceGroupsServiceResponse(_message.Message):
    __slots__ = ("context", "groups")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    GROUPS_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    groups: _containers.RepeatedCompositeFieldContainer[GroupID]
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., groups: _Optional[_Iterable[_Union[GroupID, _Mapping]]] = ...) -> None: ...

class GetDeviceGroupMembersRequest(_message.Message):
    __slots__ = ("context", "groupID")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    GROUPID_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    groupID: str
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., groupID: _Optional[str] = ...) -> None: ...

class GetDeviceGroupMembersResponse(_message.Message):
    __slots__ = ("context", "deviceGroupID", "devices")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    DEVICEGROUPID_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    deviceGroupID: GroupID
    devices: _containers.RepeatedCompositeFieldContainer[DeviceID]
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., deviceGroupID: _Optional[_Union[GroupID, _Mapping]] = ..., devices: _Optional[_Iterable[_Union[DeviceID, _Mapping]]] = ...) -> None: ...
