from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class RequestContext(_message.Message):
    __slots__ = ("taskID", "userID")
    TASKID_FIELD_NUMBER: _ClassVar[int]
    USERID_FIELD_NUMBER: _ClassVar[int]
    taskID: int
    userID: int
    def __init__(self, taskID: _Optional[int] = ..., userID: _Optional[int] = ...) -> None: ...

class ResponseContext(_message.Message):
    __slots__ = ("draID", "taskID")
    DRAID_FIELD_NUMBER: _ClassVar[int]
    TASKID_FIELD_NUMBER: _ClassVar[int]
    draID: str
    taskID: int
    def __init__(self, draID: _Optional[str] = ..., taskID: _Optional[int] = ...) -> None: ...
