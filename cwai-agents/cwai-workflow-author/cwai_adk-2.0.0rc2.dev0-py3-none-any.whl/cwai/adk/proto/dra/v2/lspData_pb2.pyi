from cwai.adk.proto.dra.v2 import draCommon_pb2 as _draCommon_pb2
from cwai.adk.proto.dra.v2 import deviceStatistics_pb2 as _deviceStatistics_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class LSPType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    LSP_TYPE_UNSPECIFIED: _ClassVar[LSPType]
    SR: _ClassVar[LSPType]
    RSVP: _ClassVar[LSPType]
LSP_TYPE_UNSPECIFIED: LSPType
SR: LSPType
RSVP: LSPType

class LinkGraphRequest(_message.Message):
    __slots__ = ("context", "localDeviceId", "localInterfaceName", "neighborDeviceId", "neighborInterfaceName", "metricNames", "startTime", "endTime")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    LOCALDEVICEID_FIELD_NUMBER: _ClassVar[int]
    LOCALINTERFACENAME_FIELD_NUMBER: _ClassVar[int]
    NEIGHBORDEVICEID_FIELD_NUMBER: _ClassVar[int]
    NEIGHBORINTERFACENAME_FIELD_NUMBER: _ClassVar[int]
    METRICNAMES_FIELD_NUMBER: _ClassVar[int]
    STARTTIME_FIELD_NUMBER: _ClassVar[int]
    ENDTIME_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    localDeviceId: str
    localInterfaceName: str
    neighborDeviceId: str
    neighborInterfaceName: str
    metricNames: _containers.RepeatedScalarFieldContainer[str]
    startTime: int
    endTime: int
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., localDeviceId: _Optional[str] = ..., localInterfaceName: _Optional[str] = ..., neighborDeviceId: _Optional[str] = ..., neighborInterfaceName: _Optional[str] = ..., metricNames: _Optional[_Iterable[str]] = ..., startTime: _Optional[int] = ..., endTime: _Optional[int] = ...) -> None: ...

class LSPGraphRequest(_message.Message):
    __slots__ = ("context", "headRouterId", "endRouterId", "colorOrTunnel", "lspType", "metricNames", "startTime", "endTime")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    HEADROUTERID_FIELD_NUMBER: _ClassVar[int]
    ENDROUTERID_FIELD_NUMBER: _ClassVar[int]
    COLORORTUNNEL_FIELD_NUMBER: _ClassVar[int]
    LSPTYPE_FIELD_NUMBER: _ClassVar[int]
    METRICNAMES_FIELD_NUMBER: _ClassVar[int]
    STARTTIME_FIELD_NUMBER: _ClassVar[int]
    ENDTIME_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    headRouterId: str
    endRouterId: str
    colorOrTunnel: int
    lspType: LSPType
    metricNames: _containers.RepeatedScalarFieldContainer[str]
    startTime: int
    endTime: int
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., headRouterId: _Optional[str] = ..., endRouterId: _Optional[str] = ..., colorOrTunnel: _Optional[int] = ..., lspType: _Optional[_Union[LSPType, str]] = ..., metricNames: _Optional[_Iterable[str]] = ..., startTime: _Optional[int] = ..., endTime: _Optional[int] = ...) -> None: ...

class LinkGraphResponse(_message.Message):
    __slots__ = ("context", "deviceId", "interfaceName", "metricsResponse")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    DEVICEID_FIELD_NUMBER: _ClassVar[int]
    INTERFACENAME_FIELD_NUMBER: _ClassVar[int]
    METRICSRESPONSE_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    deviceId: str
    interfaceName: str
    metricsResponse: _deviceStatistics_pb2.MetricDataResponse
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., deviceId: _Optional[str] = ..., interfaceName: _Optional[str] = ..., metricsResponse: _Optional[_Union[_deviceStatistics_pb2.MetricDataResponse, _Mapping]] = ...) -> None: ...

class LSPGraphResponse(_message.Message):
    __slots__ = ("context", "metricsResponse")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    METRICSRESPONSE_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    metricsResponse: _deviceStatistics_pb2.MetricDataResponse
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., metricsResponse: _Optional[_Union[_deviceStatistics_pb2.MetricDataResponse, _Mapping]] = ...) -> None: ...

class LSPStatusRequest(_message.Message):
    __slots__ = ("context", "headRouterId", "endRouterId", "color")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    HEADROUTERID_FIELD_NUMBER: _ClassVar[int]
    ENDROUTERID_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    headRouterId: str
    endRouterId: str
    color: int
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., headRouterId: _Optional[str] = ..., endRouterId: _Optional[str] = ..., color: _Optional[int] = ...) -> None: ...

class LSPStatusResponse(_message.Message):
    __slots__ = ("context",)
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ...) -> None: ...
