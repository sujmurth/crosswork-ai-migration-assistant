from cwai.adk.proto.dra.v2 import draCommon_pb2 as _draCommon_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetConfigurationChangedRequest(_message.Message):
    __slots__ = ("context", "timeInMinutes")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    TIMEINMINUTES_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    timeInMinutes: int
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., timeInMinutes: _Optional[int] = ...) -> None: ...

class GetConfigurationChangedResponse(_message.Message):
    __slots__ = ("context", "nodeId")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    NODEID_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    nodeId: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., nodeId: _Optional[_Iterable[str]] = ...) -> None: ...

class ResultStatus(_message.Message):
    __slots__ = ("success", "timestamp", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    timestamp: int
    error: str
    def __init__(self, success: bool = ..., timestamp: _Optional[int] = ..., error: _Optional[str] = ...) -> None: ...

class RunShowCommandsRequest(_message.Message):
    __slots__ = ("context", "commands")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    COMMANDS_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    commands: _containers.RepeatedCompositeFieldContainer[DeviceShowCommandInput]
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., commands: _Optional[_Iterable[_Union[DeviceShowCommandInput, _Mapping]]] = ...) -> None: ...

class DeviceShowCommandInput(_message.Message):
    __slots__ = ("nodeId", "show_command")
    NODEID_FIELD_NUMBER: _ClassVar[int]
    SHOW_COMMAND_FIELD_NUMBER: _ClassVar[int]
    nodeId: str
    show_command: str
    def __init__(self, nodeId: _Optional[str] = ..., show_command: _Optional[str] = ...) -> None: ...

class DeviceShowCommandOutput(_message.Message):
    __slots__ = ("input", "status", "output")
    INPUT_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FIELD_NUMBER: _ClassVar[int]
    input: DeviceShowCommandInput
    status: ResultStatus
    output: str
    def __init__(self, input: _Optional[_Union[DeviceShowCommandInput, _Mapping]] = ..., status: _Optional[_Union[ResultStatus, _Mapping]] = ..., output: _Optional[str] = ...) -> None: ...

class RunShowCommandResponse(_message.Message):
    __slots__ = ("context", "output")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    output: DeviceShowCommandOutput
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., output: _Optional[_Union[DeviceShowCommandOutput, _Mapping]] = ...) -> None: ...

class GetDeviceRunningConfigRequest(_message.Message):
    __slots__ = ("context", "nodeId")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    NODEID_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    nodeId: str
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., nodeId: _Optional[str] = ...) -> None: ...

class GetDeviceRunningConfigResponse(_message.Message):
    __slots__ = ("context", "nodeId", "status", "output")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    NODEID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    nodeId: str
    status: ResultStatus
    output: str
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., nodeId: _Optional[str] = ..., status: _Optional[_Union[ResultStatus, _Mapping]] = ..., output: _Optional[str] = ...) -> None: ...
