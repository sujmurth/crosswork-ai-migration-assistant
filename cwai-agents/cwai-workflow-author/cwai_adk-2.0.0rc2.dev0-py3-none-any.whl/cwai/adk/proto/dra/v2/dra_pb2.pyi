from cwai.adk.proto.dra.v2 import draCommon_pb2 as _draCommon_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetAsyncDataRequest(_message.Message):
    __slots__ = ("context", "funcName", "funcParam")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    FUNCNAME_FIELD_NUMBER: _ClassVar[int]
    FUNCPARAM_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    funcName: str
    funcParam: _struct_pb2.Value
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., funcName: _Optional[str] = ..., funcParam: _Optional[_Union[_struct_pb2.Value, _Mapping]] = ...) -> None: ...

class GetAsyncDataResponse(_message.Message):
    __slots__ = ("context", "response")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    RESPONSE_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    response: _struct_pb2.Struct
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., response: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...
