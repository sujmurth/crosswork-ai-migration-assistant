from cwai.adk.proto.dra.v2 import draCommon_pb2 as _draCommon_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetDeviceDataRequest(_message.Message):
    __slots__ = ("context", "deviceId", "metricNames", "startTime", "endTime")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    DEVICEID_FIELD_NUMBER: _ClassVar[int]
    METRICNAMES_FIELD_NUMBER: _ClassVar[int]
    STARTTIME_FIELD_NUMBER: _ClassVar[int]
    ENDTIME_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    deviceId: str
    metricNames: _containers.RepeatedScalarFieldContainer[str]
    startTime: int
    endTime: int
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., deviceId: _Optional[str] = ..., metricNames: _Optional[_Iterable[str]] = ..., startTime: _Optional[int] = ..., endTime: _Optional[int] = ...) -> None: ...

class GetInterfaceDataRequest(_message.Message):
    __slots__ = ("context", "deviceId", "interfaceName", "metricNames", "startTime", "endTime")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    DEVICEID_FIELD_NUMBER: _ClassVar[int]
    INTERFACENAME_FIELD_NUMBER: _ClassVar[int]
    METRICNAMES_FIELD_NUMBER: _ClassVar[int]
    STARTTIME_FIELD_NUMBER: _ClassVar[int]
    ENDTIME_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    deviceId: str
    interfaceName: str
    metricNames: _containers.RepeatedScalarFieldContainer[str]
    startTime: int
    endTime: int
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., deviceId: _Optional[str] = ..., interfaceName: _Optional[str] = ..., metricNames: _Optional[_Iterable[str]] = ..., startTime: _Optional[int] = ..., endTime: _Optional[int] = ...) -> None: ...

class GetTopNDataRequest(_message.Message):
    __slots__ = ("context", "metricName", "startTime", "endTime", "limit")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    METRICNAME_FIELD_NUMBER: _ClassVar[int]
    STARTTIME_FIELD_NUMBER: _ClassVar[int]
    ENDTIME_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    metricName: str
    startTime: int
    endTime: int
    limit: int
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., metricName: _Optional[str] = ..., startTime: _Optional[int] = ..., endTime: _Optional[int] = ..., limit: _Optional[int] = ...) -> None: ...

class GetDataResponse(_message.Message):
    __slots__ = ("context", "metricsResponse")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    METRICSRESPONSE_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    metricsResponse: MetricDataResponse
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., metricsResponse: _Optional[_Union[MetricDataResponse, _Mapping]] = ...) -> None: ...

class MetricDataResponse(_message.Message):
    __slots__ = ("metricName", "valueUnit", "stats", "graphs")
    METRICNAME_FIELD_NUMBER: _ClassVar[int]
    VALUEUNIT_FIELD_NUMBER: _ClassVar[int]
    STATS_FIELD_NUMBER: _ClassVar[int]
    GRAPHS_FIELD_NUMBER: _ClassVar[int]
    metricName: str
    valueUnit: str
    stats: PMStats
    graphs: PMGraphs
    def __init__(self, metricName: _Optional[str] = ..., valueUnit: _Optional[str] = ..., stats: _Optional[_Union[PMStats, _Mapping]] = ..., graphs: _Optional[_Union[PMGraphs, _Mapping]] = ...) -> None: ...

class PMStats(_message.Message):
    __slots__ = ("elementStatsData",)
    ELEMENTSTATSDATA_FIELD_NUMBER: _ClassVar[int]
    elementStatsData: _containers.RepeatedCompositeFieldContainer[PMStatsEntry]
    def __init__(self, elementStatsData: _Optional[_Iterable[_Union[PMStatsEntry, _Mapping]]] = ...) -> None: ...

class PMStatsEntry(_message.Message):
    __slots__ = ("name", "value", "min", "max")
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    MIN_FIELD_NUMBER: _ClassVar[int]
    MAX_FIELD_NUMBER: _ClassVar[int]
    name: str
    value: float
    min: float
    max: float
    def __init__(self, name: _Optional[str] = ..., value: _Optional[float] = ..., min: _Optional[float] = ..., max: _Optional[float] = ...) -> None: ...

class PMGraphs(_message.Message):
    __slots__ = ("elementGraphData",)
    ELEMENTGRAPHDATA_FIELD_NUMBER: _ClassVar[int]
    elementGraphData: _containers.RepeatedCompositeFieldContainer[PMGraph]
    def __init__(self, elementGraphData: _Optional[_Iterable[_Union[PMGraph, _Mapping]]] = ...) -> None: ...

class PMGraph(_message.Message):
    __slots__ = ("name", "point", "avg", "min", "max")
    NAME_FIELD_NUMBER: _ClassVar[int]
    POINT_FIELD_NUMBER: _ClassVar[int]
    AVG_FIELD_NUMBER: _ClassVar[int]
    MIN_FIELD_NUMBER: _ClassVar[int]
    MAX_FIELD_NUMBER: _ClassVar[int]
    name: str
    point: _containers.RepeatedCompositeFieldContainer[PMGraphDataEntry]
    avg: float
    min: float
    max: float
    def __init__(self, name: _Optional[str] = ..., point: _Optional[_Iterable[_Union[PMGraphDataEntry, _Mapping]]] = ..., avg: _Optional[float] = ..., min: _Optional[float] = ..., max: _Optional[float] = ...) -> None: ...

class PMGraphDataEntry(_message.Message):
    __slots__ = ("timestamp", "value", "min", "max")
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    MIN_FIELD_NUMBER: _ClassVar[int]
    MAX_FIELD_NUMBER: _ClassVar[int]
    timestamp: str
    value: float
    min: float
    max: float
    def __init__(self, timestamp: _Optional[str] = ..., value: _Optional[float] = ..., min: _Optional[float] = ..., max: _Optional[float] = ...) -> None: ...
