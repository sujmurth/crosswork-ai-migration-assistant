from cwai.adk.proto.dra.v2 import draCommon_pb2 as _draCommon_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GetAlarmsOrEventsRequest(_message.Message):
    __slots__ = ("context", "deviceId", "eventName", "limit", "startTime", "endTime")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    DEVICEID_FIELD_NUMBER: _ClassVar[int]
    EVENTNAME_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    STARTTIME_FIELD_NUMBER: _ClassVar[int]
    ENDTIME_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    deviceId: str
    eventName: _containers.RepeatedScalarFieldContainer[str]
    limit: int
    startTime: int
    endTime: int
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., deviceId: _Optional[str] = ..., eventName: _Optional[_Iterable[str]] = ..., limit: _Optional[int] = ..., startTime: _Optional[int] = ..., endTime: _Optional[int] = ...) -> None: ...

class GetEventsDataResponse(_message.Message):
    __slots__ = ("context", "events")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    events: _containers.RepeatedCompositeFieldContainer[EventEntry]
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., events: _Optional[_Iterable[_Union[EventEntry, _Mapping]]] = ...) -> None: ...

class EventEntry(_message.Message):
    __slots__ = ("eventName", "category", "timestamp", "nodeId", "deviceIp", "description", "severity")
    EVENTNAME_FIELD_NUMBER: _ClassVar[int]
    CATEGORY_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    NODEID_FIELD_NUMBER: _ClassVar[int]
    DEVICEIP_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    eventName: str
    category: str
    timestamp: str
    nodeId: str
    deviceIp: str
    description: str
    severity: str
    def __init__(self, eventName: _Optional[str] = ..., category: _Optional[str] = ..., timestamp: _Optional[str] = ..., nodeId: _Optional[str] = ..., deviceIp: _Optional[str] = ..., description: _Optional[str] = ..., severity: _Optional[str] = ...) -> None: ...

class GetAlarmsDataResponse(_message.Message):
    __slots__ = ("context", "alarms")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ALARMS_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    alarms: _containers.RepeatedCompositeFieldContainer[AlarmEntry]
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., alarms: _Optional[_Iterable[_Union[AlarmEntry, _Mapping]]] = ...) -> None: ...

class AlarmEntry(_message.Message):
    __slots__ = ("eventName", "created", "updated", "deviceUuid", "deviceIp", "description", "severity")
    EVENTNAME_FIELD_NUMBER: _ClassVar[int]
    CREATED_FIELD_NUMBER: _ClassVar[int]
    UPDATED_FIELD_NUMBER: _ClassVar[int]
    DEVICEUUID_FIELD_NUMBER: _ClassVar[int]
    DEVICEIP_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    eventName: str
    created: str
    updated: str
    deviceUuid: str
    deviceIp: str
    description: str
    severity: str
    def __init__(self, eventName: _Optional[str] = ..., created: _Optional[str] = ..., updated: _Optional[str] = ..., deviceUuid: _Optional[str] = ..., deviceIp: _Optional[str] = ..., description: _Optional[str] = ..., severity: _Optional[str] = ...) -> None: ...

class GetEventTypesRequest(_message.Message):
    __slots__ = ("context", "ids")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    IDS_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.RequestContext
    ids: str
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.RequestContext, _Mapping]] = ..., ids: _Optional[str] = ...) -> None: ...

class GetEventTypesResponse(_message.Message):
    __slots__ = ("context", "types")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    TYPES_FIELD_NUMBER: _ClassVar[int]
    context: _draCommon_pb2.ResponseContext
    types: _containers.RepeatedCompositeFieldContainer[EventType]
    def __init__(self, context: _Optional[_Union[_draCommon_pb2.ResponseContext, _Mapping]] = ..., types: _Optional[_Iterable[_Union[EventType, _Mapping]]] = ...) -> None: ...

class EventType(_message.Message):
    __slots__ = ("name", "severity")
    NAME_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    name: str
    severity: str
    def __init__(self, name: _Optional[str] = ..., severity: _Optional[str] = ...) -> None: ...
