"""Centralized feature flags for the ADK.

Feature flags are read from environment variables. Each flag has a default
value that is used when the variable is not set. Programmatic overrides set by the setter functions
take precedence over environment variables.
"""

import os

# State persistence strategy.
# "snapshot" — full state snapshot on each persist (default).
# "delta" — JSON Patch deltas with periodic snapshots.
STATE_PERSISTENCE = "CWAI_STATE_PERSISTENCE"
"""Environment variable that controls how task state is persisted."""
STATE_PERSISTENCE_DEFAULT = "snapshot"
"""State persistence strategy used when the environment variable is not set."""
STATE_PERSISTENCE_DELTA = "delta"
"""Persist only state changes after the initial snapshot."""
STATE_PERSISTENCE_SNAPSHOT = "snapshot"
"""Persist the full task state each time state is saved."""

# STM payload compression.
# "none" — no compression.
# "zlib" — zlib compression for payloads above the size threshold (default).
STM_COMPRESSION = "CWAI_STM_COMPRESSION"
"""Environment variable that controls compression for STM payloads."""
STM_COMPRESSION_DEFAULT = "zlib"
"""STM compression algorithm used when the environment variable is not set."""
STM_COMPRESSION_NONE = "none"
"""Store STM payloads without compression."""
STM_COMPRESSION_ZLIB = "zlib"
"""Compress STM payloads with zlib."""

# Trace content logging (LLM prompts/responses, tool inputs/results).
# When enabled, content is captured as span events on LLM and tool spans.
# Value is the max character length per field (0 = disabled).
TRACE_CONTENT_MAX_LENGTH = "CWAI_TRACE_CONTENT_MAX_LENGTH"
TRACE_CONTENT_MAX_LENGTH_DEFAULT = "32768"  # 32k; set "0" to disable

# Valid values for validated setters.
_STATE_PERSISTENCE_VALUES = {STATE_PERSISTENCE_SNAPSHOT, STATE_PERSISTENCE_DELTA}
_STM_COMPRESSION_VALUES = {STM_COMPRESSION_NONE, STM_COMPRESSION_ZLIB}

# Programmatic overrides take precedence over environment variables.
_overrides: dict[str, str] = {}


def get(name: str, default: str) -> str:
    """Read a feature flag value.

    Resolution order: programmatic override, environment variable, then default.

    Args:
        name: Environment variable name for the flag.
        default: Value to use when neither an override nor an environment variable is set.
    """
    if name in _overrides:
        return _overrides[name]
    return os.environ.get(name, default)


def set_state_persistence(value: str) -> None:
    """Set the state persistence strategy.

    Args:
        value: Use STATE_PERSISTENCE_SNAPSHOT or STATE_PERSISTENCE_DELTA.

    Raises:
        ValueError: If value is not a valid persistence strategy.
    """
    if value not in _STATE_PERSISTENCE_VALUES:
        raise ValueError(
            f"invalid state persistence value {value!r}, "
            f"expected one of {sorted(_STATE_PERSISTENCE_VALUES)}"
        )
    _overrides[STATE_PERSISTENCE] = value


def set_stm_compression(value: str) -> None:
    """Set the STM compression algorithm.

    Args:
        value: Use STM_COMPRESSION_NONE or STM_COMPRESSION_ZLIB.

    Raises:
        ValueError: If value is not a valid compression algorithm.
    """
    if value not in _STM_COMPRESSION_VALUES:
        raise ValueError(
            f"invalid STM compression value {value!r}, "
            f"expected one of {sorted(_STM_COMPRESSION_VALUES)}"
        )
    _overrides[STM_COMPRESSION] = value


def set_trace_content_max_length(value: int) -> None:
    """Set the max character length for trace content span events.

    Args:
        value: Maximum characters per field. Set to `0` to disable trace content logging. Must be non-negative.

    Raises:
        ValueError: If value is negative.
    """
    if value < 0:
        raise ValueError(f"trace content max length must be >= 0, got {value}")
    _overrides[TRACE_CONTENT_MAX_LENGTH] = str(value)


def reset() -> None:
    """Clear all programmatic overrides and revert to environment variables and defaults."""
    _overrides.clear()


def get_state_persistence() -> str:
    """Return the configured state persistence strategy."""
    return get(STATE_PERSISTENCE, STATE_PERSISTENCE_DEFAULT)


def get_stm_compression() -> str:
    """Return the configured STM compression algorithm."""
    return get(STM_COMPRESSION, STM_COMPRESSION_DEFAULT)


def get_trace_content_max_length() -> int:
    """Return the maximum character length for trace content span events.

    Returns 0 if trace content logging is disabled.
    """
    value = get(TRACE_CONTENT_MAX_LENGTH, TRACE_CONTENT_MAX_LENGTH_DEFAULT)
    try:
        return int(value)
    except ValueError:
        return 0
