"""Core message and result types for the Crosswork AI ADK."""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from dataclasses import asdict, dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from opentelemetry.context import Context as OtelContext


class MessageType(StrEnum):
    """V2 protocol message type."""

    REQUEST = "request"
    RESULT = "result"
    PARTIAL_RESULT = "partial_result"
    MORE_INFO = "more_info"
    NOTIFICATION = "notification"


class ResultStatus(StrEnum):
    """Task completion status returned in Result."""

    COMPLETE = "complete"
    PARTIAL = "partial"
    ESCALATE = "escalate"
    ERROR = "error"


class MessageFormat(StrEnum):
    """Output format for AssistantMessage content."""

    TEXT = "text"
    MARKDOWN = "markdown"
    SKILL = "skill"


class MessageTag(StrEnum):
    """Visual styling hint for AssistantMessage in the UI."""

    NONE = ""
    INFO = "info"
    POSITIVE = "positive"
    WARNING = "warning"
    LOW_WARNING = "low-warning"
    SEVERE_WARNING = "severe-warning"
    ERROR = "error"


@dataclass
class AssistantMessage:
    """Outbound message for the AI assistant UI.

    Used in Result.message to display formatted responses with
    optional follow-up suggestions.
    """

    content: str
    format: MessageFormat = MessageFormat.TEXT
    tag: MessageTag = MessageTag.NONE
    skill: str | None = None
    follow_ups: list[str] = field(default_factory=list)

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(asdict(self))


@dataclass
class Result:
    """Agent task result.

    Contains an optional UI message and/or structured data.
    """

    status: ResultStatus = ResultStatus.COMPLETE
    message: AssistantMessage | None = None
    data: dict[str, Any] | None = None


@dataclass
class Message:
    """Inbound message delivered to the agent handler.

    Every handler invocation receives a Message. The type field indicates
    the V2 protocol message type. The transport attempts to JSON-decode
    user_message into query; if decoding fails, query defaults to an empty dict.

    The system_message field carries conversation context injected by the
    routing agent when it dispatches a task. It contains a JSON payload with
    the thread's global intent (the user's original request) and recent message
    history. This field is only populated on messages sent from the routing
    agent. Messages from other sources, such as direct agent-to-agent calls through
    ctx.send_message() or ctx.call_agent(), have an empty system_message.

    Examples:
        import json

        if msg.system_message:
            history = json.loads(msg.system_message)
            # history == {
            #     "global_intent": "Show me network anomalies from last week",
            #     "messages": [
            #         {"source": "SYSTEM", "content": "Found 3 anomalies..."},
            #         {"source": "USER", "content": "Tell me about the second one"}
            #     ]
            # }
    """

    type: MessageType
    sender: str
    sender_id: int = 0
    user_message: str = ""
    system_message: str = ""
    """Conversation context from the routing agent (JSON). See class docstring."""
    query: dict[str, Any] = field(default_factory=dict)
    id: str = ""
    reply_to: str = ""
    thread_id: str = ""
    _otel_parent_ctx: OtelContext | None = field(default=None, repr=False)


@dataclass
class UserReply:
    """Response from a user interaction.

    Returned by ``ctx.user.ask()``. Contains the raw text response
    and parsed JSON data if the text was valid JSON.
    """

    text: str
    """Raw text response from user."""

    data: dict[str, Any] = field(default_factory=dict)
    """Parsed JSON if text was valid JSON, otherwise empty dict."""


SendPartialCallback = Callable[
    [AssistantMessage | None, dict[str, Any] | None],
    Awaitable[None],
]
"""Callback type for sending partial results from handlers."""
