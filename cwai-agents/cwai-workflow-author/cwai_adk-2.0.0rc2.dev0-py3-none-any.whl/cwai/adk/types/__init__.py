"""Types for the Crosswork AI ADK.

Public types are organized by subsystem:

- ``cwai.adk.types.messages`` - Core message and result types
  (``Message``, ``Result``, ``AssistantMessage``, ``UserReply``, ...)
- ``cwai.adk.types.rag`` - RAG/Context service types
  (``RAGDocument``, ``RAGSearchResult``, ...)
- ``cwai.adk.types.stm`` - STM (Short-Term Memory) types
  (``StateEntity``, ``StateEntry``, ``STMStatus``)

All public symbols are re-exported here for convenience, so
``from cwai.adk.types import Message`` and
``from cwai.adk.types.messages import Message`` are equivalent.
"""

from cwai.adk.types.messages import (
    AssistantMessage,
    Message,
    MessageFormat,
    MessageTag,
    MessageType,
    Result,
    ResultStatus,
    SendPartialCallback,
    UserReply,
)
from cwai.adk.types.rag import (
    RAGCollectionInfo,
    RAGDocument,
    RAGDocumentSection,
    RAGSearchResult,
    RAGUploadResult,
)
from cwai.adk.types.stm import (
    StateEntity,
    StateEntry,
    STMStatus,
)

__all__ = [
    # messages
    "AssistantMessage",
    "Message",
    "MessageFormat",
    "MessageTag",
    "MessageType",
    "Result",
    "ResultStatus",
    "SendPartialCallback",
    "UserReply",
    # rag
    "RAGCollectionInfo",
    "RAGDocument",
    "RAGDocumentSection",
    "RAGSearchResult",
    "RAGUploadResult",
    # stm
    "StateEntity",
    "StateEntry",
    "STMStatus",
]
