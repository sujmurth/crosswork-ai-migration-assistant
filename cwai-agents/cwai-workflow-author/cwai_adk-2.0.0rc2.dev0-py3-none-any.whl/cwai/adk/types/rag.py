"""Types for the RAG/Context service client."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any


@dataclass(frozen=True)
class RAGDocumentSection:
    """A document section for upload.

    Attributes:
        search_column: Text that gets embedded for similarity search.
        content: Structured document content as JSON.
        date_created: Creation date.
        date_valid_until: Expiration date for validity filtering.
        tags: Optional list of tags for filtering.
    """

    search_column: str
    content: dict[str, Any]
    date_created: date
    date_valid_until: date
    tags: list[str] | None = None


@dataclass(frozen=True)
class RAGDocument:
    """A stored document section returned by get.

    Attributes:
        id: Internal numeric ID.
        section_id: UUID string identifying the section.
        search_column: Text that was embedded for search.
        tags: Tags associated with the section.
        date_created: Creation date.
        date_valid_until: Expiration date.
        content: Structured document content.
    """

    id: int
    section_id: str
    search_column: str
    tags: list[str] | None
    date_created: date | None
    date_valid_until: date | None
    content: dict[str, Any] | None


@dataclass(frozen=True)
class RAGSearchResult:
    """A single search result with similarity score.

    Attributes:
        id: Internal numeric ID.
        section_id: UUID string identifying the section.
        search_column: Text that was embedded for search.
        score: Similarity score (0-1, higher is more similar).
        tags: Tags associated with the section.
        date_created: Creation date.
        date_valid_until: Expiration date.
        content: Structured document content.
    """

    id: int
    section_id: str
    search_column: str
    score: float
    tags: list[str] | None
    date_created: date | None
    date_valid_until: date | None
    content: dict[str, Any] | None


@dataclass(frozen=True)
class RAGCollectionInfo:
    """Collection metadata.

    Attributes:
        name: Collection name.
        document_count: Number of document sections in the collection.
    """

    name: str
    document_count: int


@dataclass(frozen=True)
class RAGUploadResult:
    """Result of a document upload.

    Attributes:
        inserted: Number of sections inserted.
        section_ids: UUIDs of the inserted sections.
    """

    inserted: int
    section_ids: list[str] = field(default_factory=list)
