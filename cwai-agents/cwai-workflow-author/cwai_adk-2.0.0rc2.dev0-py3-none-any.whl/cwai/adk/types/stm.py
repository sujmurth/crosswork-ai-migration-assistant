"""STM (Short-Term Memory) client types.

These are client-side dataclasses that mirror the proto messages
but are easier to work with in Python code.
"""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum


class STMStatus(Enum):
    """Lifecycle state of an STM object."""

    OPEN = "open"
    DELETED = "deleted"


@dataclass
class StateEntry:
    """A single state entry within an STM object."""

    entry_id: str
    sequence_number: int
    timestamp: datetime
    payload: bytes


@dataclass
class StateEntity:
    """Full STM container with all entries."""

    stm_key: str
    status: STMStatus
    created_at: datetime
    last_updated_at: datetime
    deleted_at: datetime | None
    entries: list[StateEntry]
    expires_at: datetime | None = None
