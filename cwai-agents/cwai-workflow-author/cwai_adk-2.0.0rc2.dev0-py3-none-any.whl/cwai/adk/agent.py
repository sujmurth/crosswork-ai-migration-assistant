"""Register agent handlers and start an agent process."""

import asyncio
import logging
import os
import sys
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import Enum

from opentelemetry import trace

from cwai.adk import __version__
from cwai.adk._framework.runner import run_agent
from cwai.adk._framework.transport import PlatformTransport
from cwai.adk.context import Context
from cwai.adk.observability.logging import configure_logging
from cwai.adk.observability.metrics import configure_metrics
from cwai.adk.observability.tracing import configure_tracing
from cwai.adk.types import Message, Result

HandlerFunc = Callable[[Context, Message], Awaitable[Result | None]]
"""Async function type for handlers registered with @agent.on_message. Receives Context and Message; returns Result or None."""
RunHandlerFunc = Callable[[Context, Message], Awaitable[Result]]
"""Async function type for handlers registered with @agent.on_run. Receives Context and the first Message; returns Result."""

_logger = logging.getLogger("cwai.adk.agent")


class HandlerType(Enum):
    """Distinguishes on_message from on_run handlers in the catalog."""

    MESSAGE = "message"
    """Handler registered with @agent.on_message; runs once for each inbound message."""
    RUN = "run"
    """Handler registered with @agent.on_run; owns the message loop for multi-turn or long-running workflows."""


@dataclass
class AgentEntry:
    """An entry in the agent catalog.

    Each entry represents a registered agent handler that can be
    invoked via ``ctx.call_agent()`` or ``ctx.spawn_agent()``.
    """

    name: str
    """Registered handler name used for platform dispatch and local lookup."""
    handler: HandlerFunc | RunHandlerFunc
    """Function that runs when the handler is invoked."""
    handler_type: HandlerType
    """Handler style: message-based or run-based."""
    description: str | None = None
    """Optional human-readable description of what the handler does."""
    local: bool = False
    """If True, the handler is available only for in-process sub-agent calls and is not advertised to the platform."""


# Agent catalog: all named handlers, keyed by name.
_catalog: dict[str, AgentEntry] = {}

_transport: PlatformTransport | None = None

log: logging.Logger = logging.getLogger("cwai.adk.agent.handler")
"""Module-level logger for code that runs outside a task context."""

tracer: trace.Tracer = trace.get_tracer("cwai.adk.agent.handler")
"""Module-level tracer for spans created outside a task context."""


def on_message(
    name: str,
    *,
    description: str | None = None,
    local: bool = False,
) -> Callable[[HandlerFunc], HandlerFunc]:
    """Register a handler for inbound messages. Return ``Result`` to complete the task, or return ``None`` to wait for another message.

    Examples:
        @agent.on_message("echo-agent")
        async def handle(ctx: Context, msg: Message) -> Result | None:
            ...

    Args:
        name: Registered handler name used for platform dispatch and local lookup.
        description: Optional human-readable description of what the
            agent does.
        local: If True, the agent is only available for local
            invocation and is not advertised to the platform.
    """

    def decorator(func: HandlerFunc) -> HandlerFunc:
        if name in _catalog:
            raise ValueError(f"Agent '{name}' is already registered")
        _catalog[name] = AgentEntry(
            name=name,
            handler=func,
            handler_type=HandlerType.MESSAGE,
            description=description,
            local=local,
        )
        return func

    return decorator


def on_run(
    name: str,
    *,
    description: str | None = None,
    local: bool = False,
) -> Callable[[RunHandlerFunc], RunHandlerFunc]:
    """Register a named run handler function.

    Examples:
        @agent.on_run("analyzer")
        async def analyze(ctx: Context, msg: Message) -> Result:
            ...

    Named handlers are registered in the agent catalog and can be
    invoked by other handlers via ``ctx.call_agent("analyzer", ...)``,
    or dispatched by the platform when ``FORESIGHT_AGENT_NAME`` matches.

    Args:
        name: Registered handler name used for platform dispatch and local lookup.
        description: Optional human-readable description of what the
            agent does.
        local: If True, the agent is only available for local
            ``ctx.call_agent()`` calls and is not advertised to the
            platform.
    """

    def decorator(func: RunHandlerFunc) -> RunHandlerFunc:
        if name in _catalog:
            raise ValueError(f"Agent '{name}' is already registered")
        _catalog[name] = AgentEntry(
            name=name,
            handler=func,
            handler_type=HandlerType.RUN,
            description=description,
            local=local,
        )
        return func

    return decorator


def set_transport(transport: PlatformTransport) -> None:
    """Set the platform transport (called by MockPlatform or gRPC setup)."""
    global _transport  # noqa: PLW0603
    _transport = transport


# Foresight reserves runtime IDs 0–999 (routing, pipeline, etc.); real agent
# runtimes use IDs >= 1000. Task-scoped K8s Jobs still set FORESIGHT_RUNTIME_ID=0
# for env symmetry, which must not select V2 (handshake would hit the wrong
# runtime and fail with "agent not found"). See foresight/agent/runtime.go.
_MIN_V2_AGENT_RUNTIME_ID = 1000


def _use_v2_grpc_transport_from_env() -> bool:
    raw = os.environ.get("FORESIGHT_RUNTIME_ID", "").strip()
    if not raw:
        return False
    try:
        runtime_id = int(raw)
    except ValueError:
        return False
    return runtime_id >= _MIN_V2_AGENT_RUNTIME_ID


def _transport_from_env() -> PlatformTransport:
    """Select V1 or V2 transport based on environment variables.

    V2 uses FORESIGHT_RUNTIME_ID when it is a real agent runtime (>= 1000).
    V1 uses FORESIGHT_TASK_ID (single task per process), including when
    FORESIGHT_RUNTIME_ID is 0–999 (placeholder on task-scoped Jobs).
    """
    if _use_v2_grpc_transport_from_env():
        from cwai.adk.client.grpc_v2_transport import GrpcV2Transport

        return GrpcV2Transport.from_env()

    if os.environ.get("FORESIGHT_TASK_ID", "").strip() != "":
        from cwai.adk.client.grpc_transport import GrpcTransport

        return GrpcTransport.from_env()

    raise ValueError(
        "No transport environment variables found. "
        "Set FORESIGHT_RUNTIME_ID (V2, agent runtime id >= 1000) or "
        "FORESIGHT_TASK_ID (V1)."
    )


def start() -> None:
    """Start the agent process.

    Configure logging and tracing, open a persistent connection to the
    platform, and process tasks as they are dispatched. The main
    handler is resolved by matching ``FORESIGHT_AGENT_NAME`` against
    the registered catalog entries.

    Examples:
        agent.start()
    """
    if not _catalog:
        _logger.error(
            "No handlers registered. "
            "Use @agent.on_message(name) or @agent.on_run(name)."
        )
        sys.exit(1)

    transport = _transport
    if transport is None:
        transport = _transport_from_env()

    _configure_observability()

    _logger.info(
        "Agent starting",
        extra={
            "adk_version": __version__,
            "python_version": sys.version.split()[0],
            "agent_name": os.environ.get("FORESIGHT_AGENT_NAME", "unknown-agent"),
        },
    )

    asyncio.run(
        run_agent(
            transport=transport,
            catalog=_catalog,
        )
    )


def _configure_observability() -> None:
    """Configure logging, tracing, and metrics for the agent.

    Reads configuration from environment variables:
    - FORESIGHT_AGENT_NAME: Agent name for service identity
    - OTEL_EXPORTER_OTLP_ENDPOINT: Base OTLP endpoint (fallback for all signals)
    - OTEL_EXPORTER_OTLP_LOGS_ENDPOINT: Logs-specific endpoint
    - OTEL_EXPORTER_OTLP_TRACES_ENDPOINT: Traces-specific endpoint
    - OTEL_EXPORTER_OTLP_METRICS_ENDPOINT: Metrics-specific endpoint

    Signal-specific endpoints take precedence over the base endpoint.
    """
    agent_name = os.environ.get("FORESIGHT_AGENT_NAME", "unknown-agent")

    # OTEL endpoint resolution: signal-specific env var takes precedence,
    # falls back to generic OTEL_EXPORTER_OTLP_ENDPOINT.
    otlp_base = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
    logs_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_LOGS_ENDPOINT") or otlp_base
    traces_endpoint = os.environ.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT") or otlp_base
    metrics_endpoint = (
        os.environ.get("OTEL_EXPORTER_OTLP_METRICS_ENDPOINT") or otlp_base
    )

    configure_logging(agent_name, otlp_endpoint=logs_endpoint)
    configure_tracing(agent_name, otlp_endpoint=traces_endpoint)
    configure_metrics(agent_name, __version__, otlp_endpoint=metrics_endpoint)
