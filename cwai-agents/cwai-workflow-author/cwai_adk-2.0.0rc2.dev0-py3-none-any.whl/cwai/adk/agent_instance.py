"""Agent instance handle returned by spawn_agent.

Represents a spawned agent instance and provides methods
for interacting with it. All methods delegate to the parent Context.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from cwai.adk.types import MessageType

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from cwai.adk.context import Context


class AgentInstance:
    """Handle to a spawned agent instance.

    Returned by ``ctx.spawn_agent()``. Provides convenience methods
    that delegate to the parent context, and can be used as an async
    context manager for automatic lifecycle management.

    Attributes:
        agent_type: Registered agent type of the spawned agent.
        instance_id: Platform-assigned instance identifier.

    Examples:
        # Manual lifecycle
        agent = await ctx.spawn_agent("worker", user_message="go")
        await agent.send_message(user_message="more work")
        await agent.stop()

    Examples:
        # Context manager (auto-stop on exit)
        async with await ctx.spawn_agent("worker", user_message="go") as agent:
            await agent.send_message(user_message="more work")
    """

    __slots__ = ("_ctx", "agent_type", "instance_id")

    def __init__(self, ctx: Context, agent_type: str, instance_id: int) -> None:
        self._ctx = ctx
        self.agent_type = agent_type
        self.instance_id = instance_id

    async def stop(self) -> None:
        """Stop this agent instance.

        Sends a RemoveAgent request to the platform. The operation is idempotent:
        it succeeds silently if the agent has already exited.

        Examples:
            agent = await ctx.spawn_agent("worker", user_message="task")
            # ... later ...
            await agent.stop()
        """
        await self._ctx.stop_agent(self)

    async def send_message(
        self,
        *,
        user_message: str = "",
        system_message: str = "",
        type: MessageType = MessageType.REQUEST,
    ) -> None:
        """Send a message to this agent instance.

        Args:
            user_message: User-visible message content.
            system_message: System or internal message content.
            type: Message type.

        Examples:
            agent = await ctx.spawn_agent("worker", user_message="init")
            await agent.send_message(user_message="do more work")
        """
        await self._ctx.send_message(
            self.agent_type,
            self.instance_id,
            user_message=user_message,
            system_message=system_message,
            type=type,
        )

    async def __aenter__(self) -> AgentInstance:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        logger.debug(
            "Auto-stopping agent on context exit",
            extra={
                "agent_type": self.agent_type,
                "instance_id": self.instance_id,
            },
        )
        try:
            await self.stop()
        except Exception:
            logger.warning(
                "Failed to auto-stop agent on context exit",
                exc_info=True,
                extra={
                    "agent_type": self.agent_type,
                    "instance_id": self.instance_id,
                },
            )

    def __repr__(self) -> str:
        return (
            f"AgentInstance(agent_type={self.agent_type!r}, "
            f"instance_id={self.instance_id})"
        )
