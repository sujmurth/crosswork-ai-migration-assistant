"""Exception hierarchy for the Crosswork AI ADK."""


class ADKError(Exception):
    """Base exception for all ADK errors."""


class ClientError(ADKError):
    """Base exception for client errors."""


class TaskError(ADKError):
    """Error during task execution."""


class TimeoutError(ADKError):
    """Timeout waiting for a message or event."""


class LLMError(ADKError):
    """Error from LLM client operations."""


class LLMUnavailableError(LLMError):
    """All requested models failed or are unavailable."""


class TransportClosed(ADKError):
    """Transport has shut down; no more messages will arrive."""


# --- STM Errors ---


class STMError(ADKError):
    """Base exception for all STM errors."""


class STMNotFoundError(STMError):
    """STM with given key does not exist."""


class STMAlreadyExistsError(STMError):
    """STM with given key already exists."""


class STMDeletedError(STMError):
    """Cannot write to a deleted STM."""


class STMPayloadTooLargeError(STMError):
    """Single state entry exceeds size limit (1MB).

    Attributes:
        current_size: Size of the payload that was rejected.
        max_size: Maximum allowed payload size.
    """

    def __init__(
        self, message: str, *, current_size: int = 0, max_size: int = 0
    ) -> None:
        super().__init__(message)
        self.current_size = current_size
        self.max_size = max_size


class STMSizeExceededError(STMError):
    """Total STM size would exceed limit (100MB).

    Attributes:
        current_size: Total STM size when the limit was exceeded.
        max_size: Maximum allowed total size.
    """

    def __init__(
        self, message: str, *, current_size: int = 0, max_size: int = 0
    ) -> None:
        super().__init__(message)
        self.current_size = current_size
        self.max_size = max_size


class STMMaxEntriesError(STMError):
    """STM has reached maximum entry count (10,000).

    Attributes:
        current_count: Current number of entries.
        max_count: Maximum allowed entries.
    """

    def __init__(
        self, message: str, *, current_count: int = 0, max_count: int = 0
    ) -> None:
        super().__init__(message)
        self.current_count = current_count
        self.max_count = max_count


class STMTTLOutOfRangeError(STMError):
    """TTL value is out of the allowed range (must be > 0 and <= server MaxTTL)."""


class STMSerializationError(STMError):
    """ctx.state contains non-JSON-serializable data."""


class STMConnectionError(STMError):
    """Failed to connect to STM service."""


# --- KG Errors ---


class KGError(ADKError):
    """Base exception for Knowledge Graph operations."""


class KGQueryError(KGError):
    """GraphQL query returned errors.

    Attributes:
        errors: List of error dicts from the GraphQL response.
    """

    def __init__(self, message: str, errors: list[dict[str, object]]) -> None:
        super().__init__(message)
        self.errors = errors


class KGConnectionError(KGError):
    """Failed to connect to KG service."""


# --- RAG Errors ---


class RAGError(ADKError):
    """Base exception for RAG/Context service operations."""


class RAGConnectionError(RAGError):
    """Failed to connect to RAG service."""


class RAGNotFoundError(RAGError):
    """Requested collection or document section does not exist."""


class RAGValidationError(RAGError):
    """Request failed validation (for example, missing required fields).

    Attributes:
        detail: Validation error detail from the service.
    """

    def __init__(self, message: str, detail: str = "") -> None:
        super().__init__(message)
        self.detail = detail


class RAGPayloadTooLargeError(RAGError):
    """Request body exceeds the service size limit."""


# --- Agent Catalog Errors ---


class AgentCatalogError(ADKError):
    """Base exception for Agent Catalog operations."""


class AgentCatalogConnectionError(AgentCatalogError):
    """Failed to connect to Crosswork AI service."""


# --- DRA Errors ---


class DRAError(ADKError):
    """Base exception for DRA Gateway operations."""


class DRAConnectionError(DRAError):
    """Failed to connect to DRA Gateway."""


class DRARequestError(DRAError):
    """DRA request failed (gRPC error, timeout, etc.)."""


# --- Tools Errors ---


class ToolsError(ADKError):
    """Base exception for Tools/MCP client operations."""


class ToolsConnectionError(ToolsError):
    """Failed to connect to MCP server."""


class ToolsCallError(ToolsError):
    """Tool invocation returned an error.

    Attributes:
        tool_name: Name of the tool that failed.
    """

    def __init__(self, message: str, *, tool_name: str) -> None:
        super().__init__(message)
        self.tool_name = tool_name
