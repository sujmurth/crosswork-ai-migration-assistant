"""Mock RAG/Context service client for testing."""

import json
from dataclasses import asdict, dataclass, field
from typing import Any

from cwai.adk.errors import RAGError, RAGNotFoundError
from cwai.adk.tools import Tool
from cwai.adk.types.rag import (
    RAGCollectionInfo,
    RAGDocument,
    RAGDocumentSection,
    RAGSearchResult,
    RAGUploadResult,
)


@dataclass
class MockRAGClient:
    """In-memory RAG client for testing.

    Supports pre-configured responses and operation recording for testing
    agent handlers that use the RAG/Context service.

    Args:
        search_results: Results to return from search().
        upload_result: Result to return from upload().
        documents: Dict mapping "collection/section_id" to RAGDocument.
        collections: List of collections to return from list_collections().
        delete_collection_count: Number to return from delete_collection().

    Examples:
        from datetime import date
        from cwai.adk.types.rag import RAGSearchResult

        mock_rag = MockRAGClient(
            search_results=[
                RAGSearchResult(
                    id=1,
                    section_id="abc-123",
                    search_column="BGP config guide",
                    score=0.95,
                    tags=["networking"],
                    date_created=date(2024, 1, 1),
                    date_valid_until=date(2025, 12, 31),
                    content={"body": "Configure BGP..."},
                ),
            ],
        )

        ctx = mock_context(rag_client=mock_rag)
        result = await my_handler(ctx, msg)

        # Assert on recorded operations
        assert len(mock_rag.calls) == 1
        assert mock_rag.calls[0][0] == "search"
    """

    search_results: list[RAGSearchResult] = field(default_factory=list)
    upload_result: RAGUploadResult | None = None
    documents: dict[str, RAGDocument] = field(default_factory=dict)
    collections: list[RAGCollectionInfo] = field(default_factory=list)
    delete_collection_count: int = 0

    # Records all operations: list of (operation, args_dict) tuples
    calls: list[tuple[str, dict]] = field(default_factory=list)  # pyright: ignore[reportMissingTypeArgument]

    async def search(
        self,
        collection: str,
        query: str,
        *,
        tags: list[str] | None = None,
        limit: int | None = None,
        date_valid: bool | None = None,
        timeout: float | None = None,
    ) -> list[RAGSearchResult]:
        """Return configured search results."""
        self.calls.append(
            (
                "search",
                {
                    "collection": collection,
                    "query": query,
                    "tags": tags,
                    "limit": limit,
                    "date_valid": date_valid,
                },
            )
        )
        return self.search_results

    async def upload(
        self,
        collection: str,
        sections: list[RAGDocumentSection],
        *,
        timeout: float | None = None,
    ) -> RAGUploadResult:
        """Return configured upload result."""
        self.calls.append(
            (
                "upload",
                {"collection": collection, "sections": sections},
            )
        )
        if self.upload_result is not None:
            return self.upload_result
        return RAGUploadResult(inserted=len(sections), section_ids=[])

    async def get_document(
        self,
        collection: str,
        section_id: str,
        *,
        timeout: float | None = None,
    ) -> RAGDocument:
        """Return document from configured map or raise RAGNotFoundError."""
        self.calls.append(
            (
                "get_document",
                {"collection": collection, "section_id": section_id},
            )
        )
        key = f"{collection}/{section_id}"
        if key not in self.documents:
            raise RAGNotFoundError(
                f"Section {section_id} not found in collection {collection}"
            )
        return self.documents[key]

    async def delete_document(
        self,
        collection: str,
        section_id: str,
        *,
        timeout: float | None = None,
    ) -> None:
        """Record deletion; raise RAGNotFoundError if not in documents map."""
        self.calls.append(
            (
                "delete_document",
                {"collection": collection, "section_id": section_id},
            )
        )
        key = f"{collection}/{section_id}"
        if key not in self.documents:
            raise RAGNotFoundError(
                f"Section {section_id} not found in collection {collection}"
            )

    async def list_collections(
        self,
        *,
        timeout: float | None = None,
    ) -> list[RAGCollectionInfo]:
        """Return configured collections list."""
        self.calls.append(("list_collections", {}))
        return self.collections

    async def delete_collection(
        self,
        collection: str,
        *,
        timeout: float | None = None,
    ) -> int:
        """Return configured delete count."""
        self.calls.append(
            (
                "delete_collection",
                {"collection": collection},
            )
        )
        return self.delete_collection_count

    async def upload_markdown(
        self,
        collection: str,
        markdown: str,
        *,
        timeout: float | None = None,
    ) -> RAGUploadResult:
        """Return configured upload result."""
        self.calls.append(
            (
                "upload_markdown",
                {"collection": collection, "markdown": markdown},
            )
        )
        if self.upload_result is not None:
            return self.upload_result
        return RAGUploadResult(inserted=1, section_ids=[])

    async def close(self) -> None:
        """No-op for mock client."""
        pass

    @property
    def tools(self) -> list[Tool]:
        """LLM tools for RAG operations.

        Returns a list of Tool objects matching RAGClient.tools.
        """
        return [
            Tool(
                name="rag_search",
                description=(
                    "Search for documents in a RAG collection using semantic "
                    "similarity. Returns matching document sections with "
                    "relevance scores. Use rag_list_collections first to "
                    "discover available collections."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "collection": {
                            "type": "string",
                            "description": "Name of the collection to search",
                        },
                        "query": {
                            "type": "string",
                            "description": "Search query text",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum number of results to return",
                        },
                    },
                    "required": ["collection", "query"],
                },
                execute=self._tool_search,
            ),
            Tool(
                name="rag_list_collections",
                description=(
                    "List all available RAG collections with their document "
                    "counts. Call this to discover what collections exist "
                    "before searching."
                ),
                parameters={"type": "object", "properties": {}},
                execute=self._tool_list_collections,
            ),
            Tool(
                name="rag_get_document",
                description=(
                    "Get a specific document section by its ID. Use this to "
                    "retrieve the full content of a document found via search."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "collection": {
                            "type": "string",
                            "description": "Name of the collection",
                        },
                        "section_id": {
                            "type": "string",
                            "description": "UUID of the document section",
                        },
                    },
                    "required": ["collection", "section_id"],
                },
                execute=self._tool_get_document,
            ),
        ]

    async def _tool_search(
        self,
        collection: str,
        query: str,
        limit: int | None = None,
    ) -> str:
        """Execute rag_search tool, returning JSON result or error."""
        try:
            results = await self.search(collection, query, limit=limit)
            return json.dumps(
                [self._search_result_to_dict(r) for r in results],
                default=str,
            )
        except RAGError as e:
            return json.dumps({"error": str(e)})

    async def _tool_list_collections(self) -> str:
        """Execute rag_list_collections tool, returning JSON result or error."""
        try:
            collections = await self.list_collections()
            return json.dumps([asdict(c) for c in collections])
        except RAGError as e:
            return json.dumps({"error": str(e)})

    async def _tool_get_document(
        self,
        collection: str,
        section_id: str,
    ) -> str:
        """Execute rag_get_document tool, returning JSON result or error."""
        try:
            doc = await self.get_document(collection, section_id)
            return json.dumps(self._document_to_dict(doc), default=str)
        except RAGError as e:
            return json.dumps({"error": str(e)})

    @staticmethod
    def _search_result_to_dict(r: RAGSearchResult) -> dict[str, Any]:
        """Convert RAGSearchResult to dict for JSON serialization."""
        return {
            "id": r.id,
            "section_id": r.section_id,
            "search_column": r.search_column,
            "score": r.score,
            "tags": r.tags,
            "date_created": r.date_created.isoformat() if r.date_created else None,
            "date_valid_until": (
                r.date_valid_until.isoformat() if r.date_valid_until else None
            ),
            "content": r.content,
        }

    @staticmethod
    def _document_to_dict(doc: RAGDocument) -> dict[str, Any]:
        """Convert RAGDocument to dict for JSON serialization."""
        return {
            "id": doc.id,
            "section_id": doc.section_id,
            "search_column": doc.search_column,
            "tags": doc.tags,
            "date_created": doc.date_created.isoformat() if doc.date_created else None,
            "date_valid_until": (
                doc.date_valid_until.isoformat() if doc.date_valid_until else None
            ),
            "content": doc.content,
        }
