"""Mock MCP client for testing.

Implements McpClientProtocol with configurable responses and call
recording. Use this to test domain clients (ToolsClient, etc.)
without any network or httpx mocking.
"""

from dataclasses import dataclass, field
from typing import Any

from cwai.adk.errors import ToolsCallError, ToolsConnectionError


@dataclass
class MockMcpClient:
    """In-memory MCP client for testing.

    Pre-configure responses for each MCP method. All calls are recorded
    for test assertions.

    Args:
        tools_list_responses: List of dicts to return from list_tools(),
            consumed in order. Each should have "tools" and optionally
            "nextCursor" keys.
        call_tool_results: Dict mapping tool name to raw result dict
            (with "content", "isError", "structuredContent" keys).
        capabilities: Server capabilities returned by get_server_capabilities().

    Examples:
        mock = MockMcpClient(
            tools_list_responses=[{
                "tools": [
                    {"name": "show_interfaces", "description": "Show interfaces",
                     "inputSchema": {"type": "object", "properties": {}}},
                ],
            }],
            call_tool_results={
                "show_interfaces": {
                    "content": [{"type": "text", "text": '{"interfaces": ["eth0"]}'}],
                },
            },
        )
        tools_client = ToolsClient(mock)
        tools = await tools_client.list_tools()
    """

    tools_list_responses: list[dict[str, Any]] = field(default_factory=list)
    call_tool_results: dict[str, dict[str, Any]] = field(default_factory=dict)
    prompts_list_responses: list[dict[str, Any]] = field(default_factory=list)
    get_prompt_results: dict[str, dict[str, Any]] = field(default_factory=dict)
    resources_list_responses: list[dict[str, Any]] = field(default_factory=list)
    read_resource_results: dict[str, dict[str, Any]] = field(default_factory=dict)
    resource_templates_responses: list[dict[str, Any]] = field(default_factory=list)
    capabilities: dict[str, Any] | None = field(default=None)

    # Records all operations: list of (method, *args, **kwargs) tuples
    calls: list[tuple[Any, ...]] = field(default_factory=list)

    _tools_list_idx: int = field(default=0, repr=False)
    _prompts_list_idx: int = field(default=0, repr=False)
    _resources_list_idx: int = field(default=0, repr=False)
    _resource_templates_idx: int = field(default=0, repr=False)
    _closed: bool = field(default=False, repr=False)

    def _check_closed(self) -> None:
        if self._closed:
            raise ToolsConnectionError("Client is closed")

    async def list_tools(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]:
        self._check_closed()
        self.calls.append(("list_tools", cursor))
        if self._tools_list_idx < len(self.tools_list_responses):
            resp = self.tools_list_responses[self._tools_list_idx]
            self._tools_list_idx += 1
            return resp
        return {"tools": []}

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        self._check_closed()
        self.calls.append(("call_tool", name, arguments))
        if name not in self.call_tool_results:
            raise ToolsCallError(f"Tool '{name}' not found", tool_name=name)
        return self.call_tool_results[name]

    async def list_prompts(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]:
        self._check_closed()
        self.calls.append(("list_prompts", cursor))
        if self._prompts_list_idx < len(self.prompts_list_responses):
            resp = self.prompts_list_responses[self._prompts_list_idx]
            self._prompts_list_idx += 1
            return resp
        return {"prompts": []}

    async def get_prompt(
        self,
        name: str,
        arguments: dict[str, str] | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        self._check_closed()
        self.calls.append(("get_prompt", name, arguments))
        if name not in self.get_prompt_results:
            raise ToolsConnectionError(f"Prompt '{name}' not found")
        return self.get_prompt_results[name]

    async def list_resources(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]:
        self._check_closed()
        self.calls.append(("list_resources", cursor))
        if self._resources_list_idx < len(self.resources_list_responses):
            resp = self.resources_list_responses[self._resources_list_idx]
            self._resources_list_idx += 1
            return resp
        return {"resources": []}

    async def read_resource(
        self, uri: str, *, timeout: float | None = None
    ) -> dict[str, Any]:
        self._check_closed()
        self.calls.append(("read_resource", uri))
        if uri not in self.read_resource_results:
            raise ToolsConnectionError(f"Resource '{uri}' not found")
        return self.read_resource_results[uri]

    async def list_resource_templates(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]:
        self._check_closed()
        self.calls.append(("list_resource_templates", cursor))
        if self._resource_templates_idx < len(self.resource_templates_responses):
            resp = self.resource_templates_responses[self._resource_templates_idx]
            self._resource_templates_idx += 1
            return resp
        return {"resourceTemplates": []}

    def get_server_capabilities(self) -> dict[str, Any] | None:
        return self.capabilities

    async def close(self) -> None:
        self._closed = True
