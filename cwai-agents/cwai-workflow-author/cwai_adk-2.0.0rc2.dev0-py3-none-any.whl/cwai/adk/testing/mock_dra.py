"""Mock DRA Gateway client for testing."""

from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any
from unittest.mock import MagicMock

from cwai.adk.client.dra import DRAResponse
from cwai.adk.errors import DRAConnectionError, DRARequestError
from cwai.adk.request_context import RequestContext


@dataclass
class MockDRAClient:
    """In-memory DRA client for testing.

    Supports configurable responses and error injection for testing
    agent handlers that use the DRA Gateway.

    Args:
        request_context: Optional request context (ignored, for API consistency).
        async_data_responses: List of DRAResponse objects for get_async_data.
        error: If set, raises DRARequestError with this message for all calls.
        get_async_data_error: Error specific to get_async_data.
        call_unary_error: Error specific to call_unary().
        call_stream_error: Error specific to call_stream().

    Examples:
        mock_dra = MockDRAClient()
        mock_dra.call_unary_responses["get_data"] = {"result": "ok"}

        ctx = mock_context(dra_client=mock_dra)
        result = await my_handler(ctx, msg)

        # Assert on recorded calls
        assert len(mock_dra.call_unary_invocations) == 1
    """

    request_context: RequestContext | None = None
    """Request context passed to the mock client."""

    async_data_responses: list[DRAResponse] = field(default_factory=list)
    """Responses that the mock returns when the test calls get_async_data()."""

    error: str | None = None
    """Error message used when any DRA call raises DRARequestError."""

    get_async_data_error: str | None = None
    """Error message used when get_async_data() raises DRARequestError."""

    get_async_data_calls: int = field(default=0, init=False)
    """Number of times get_async_data() was called."""

    connect_calls: int = field(default=0, init=False)
    """Number of times connect() was called."""

    close_calls: int = field(default=0, init=False)
    """Number of times close() was called."""

    get_async_data_calls_args: list[tuple[str, Any]] = field(
        default_factory=list, init=False
    )
    """Function names and parameters recorded each time the test calls get_async_data()."""

    call_unary_invocations: list[tuple[str, Any, Any, float | None]] = field(
        default_factory=list, init=False
    )
    """Unary calls recorded by call_unary(), including operation name, method, request, and timeout."""

    call_stream_invocations: list[tuple[str, Any, Any, float | None]] = field(
        default_factory=list, init=False
    )
    """Streaming calls recorded by call_stream(), including operation name, method, request, and timeout."""

    call_unary_responses: dict[str, Any] = field(default_factory=dict)
    """Response that the mock returns from call_unary() for each operation name."""

    call_stream_responses: dict[str, list[Any]] = field(default_factory=dict)
    """Responses that the mock returns from call_stream() for each operation name."""

    call_unary_error: str | None = None
    """Error message used when call_unary() raises DRARequestError."""

    call_stream_error: str | None = None
    """Error message used when call_stream() raises DRARequestError."""
    _connected: bool = field(default=False, init=False)

    async def connect(self) -> None:
        """No-op connect for mock client."""
        self.connect_calls += 1
        self._connected = True

    async def close(self) -> None:
        """No-op close for mock client."""
        self.close_calls += 1
        self._connected = False

    @property
    def channel(self) -> Any:
        """Return a mock channel for custom stub creation.

        Raises:
            DRAConnectionError: If client is not connected.
        """
        if not self._connected:
            raise DRAConnectionError("Client not connected. Call connect() first.")
        return MagicMock()

    async def call_unary(
        self,
        name: str,
        method: Callable[[Any], Awaitable[Any]],
        request: Any,
        *,
        timeout: float | None = None,
    ) -> Any:
        """Mock unary call that returns configured responses.

        Most DRA operations use streaming (call_stream) due to the fan-out
        pattern. Use call_unary only for single-response methods like
        GetDeviceRunningConfig.

        Args:
            name: Operation name (recorded for assertions).
            method: gRPC stub method (ignored in mock).
            request: Request message (recorded for assertions).
            timeout: Timeout (recorded for assertions).

        Returns:
            Configured response for the name, or None if not configured.

        Raises:
            DRAConnectionError: If client is not connected.
            DRARequestError: If call_unary_error is configured.
        """
        if not self._connected:
            raise DRAConnectionError("Client not connected. Call connect() first.")

        self.call_unary_invocations.append((name, method, request, timeout))

        if self.error:
            raise DRARequestError(self.error)
        if self.call_unary_error:
            raise DRARequestError(self.call_unary_error)

        return self.call_unary_responses.get(name)

    async def call_stream(
        self,
        name: str,
        method: Callable[[Any], AsyncIterator[Any]],
        request: Any,
        *,
        timeout: float | None = None,
    ) -> AsyncIterator[Any]:
        """Mock streaming call that yields configured responses.

        This is the preferred method for most DRA operations due to the
        fan-out pattern where multiple DRAs can respond to a single request.

        Args:
            name: Operation name (recorded for assertions).
            method: gRPC stub streaming method (ignored in mock).
            request: Request message (recorded for assertions).
            timeout: Timeout (recorded for assertions).

        Yields:
            Configured responses for the name.

        Raises:
            DRAConnectionError: If client is not connected.
            DRARequestError: If call_stream_error is configured.
        """
        if not self._connected:
            raise DRAConnectionError("Client not connected. Call connect() first.")

        self.call_stream_invocations.append((name, method, request, timeout))

        if self.error:
            raise DRARequestError(self.error)
        if self.call_stream_error:
            raise DRARequestError(self.call_stream_error)

        for response in self.call_stream_responses.get(name, []):
            yield response

    async def __aenter__(self) -> "MockDRAClient":
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        await self.close()

    async def get_async_data(
        self,
        func_name: str,
        func_param: dict[str, Any] | list[Any] | str | int | float | bool | None = None,
        task_id: int = 0,
        user_id: int = 0,
        *,
        timeout: float | None = None,
    ) -> AsyncIterator[DRAResponse]:
        """Return configured async data responses or raise error.

        Args:
            func_name: Name of the DRA function (recorded for assertions).
            func_param: Parameters to pass (recorded for assertions).
            task_id: Task ID for request context (ignored in mock).
            user_id: User ID for request context (ignored in mock).
            timeout: Request timeout in seconds (ignored in mock).

        Yields:
            Configured DRAResponse objects.

        Raises:
            DRARequestError: If error is configured.
        """
        self.get_async_data_calls += 1
        self.get_async_data_calls_args.append((func_name, func_param))

        if self.error:
            raise DRARequestError(self.error)
        if self.get_async_data_error:
            raise DRARequestError(self.get_async_data_error)

        for response in self.async_data_responses:
            yield response
