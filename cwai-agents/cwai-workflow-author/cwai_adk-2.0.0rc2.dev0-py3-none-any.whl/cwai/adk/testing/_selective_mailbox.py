"""Private selective mailbox helper for ADK tests and mocks."""

from __future__ import annotations

import asyncio
from collections import deque
from typing import Generic, TypeVar

MailboxMessage = TypeVar("MailboxMessage")


def _sender_id(msg: object) -> int | None:
    sender_id = getattr(msg, "sender_id", None)
    if isinstance(sender_id, int):
        return sender_id
    from_agent_id = getattr(msg, "from_agent_id", None)
    if isinstance(from_agent_id, int):
        return from_agent_id
    return None


class SelectiveMailbox(Generic[MailboxMessage]):
    """In-memory message mailbox with optional sender filtering.

    This mirrors the ADK-visible platform behavior needed by tests:
    filtered receives skip non-matching messages without removing them,
    preserving their relative order for later receives.
    """

    def __init__(self) -> None:
        self._messages: deque[MailboxMessage] = deque()
        self._condition = asyncio.Condition()

    async def put(self, msg: MailboxMessage) -> None:
        async with self._condition:
            self._messages.append(msg)
            self._condition.notify_all()

    def put_nowait(self, msg: MailboxMessage) -> None:
        self._messages.append(msg)
        self._wake_waiters()

    def empty(self) -> bool:
        return not self._messages

    async def get(self, *, sender_id: int | None = None) -> MailboxMessage:
        async with self._condition:
            while True:
                index = self._find_index(sender_id)
                if index is not None:
                    return self._pop_index(index)
                await self._condition.wait()

    def _find_index(self, sender_id: int | None) -> int | None:
        if sender_id is None:
            return 0 if self._messages else None
        for index, msg in enumerate(self._messages):
            if msg is None:
                return index
            if _sender_id(msg) == sender_id:
                return index
        return None

    def _pop_index(self, index: int) -> MailboxMessage:
        if index == 0:
            return self._messages.popleft()
        self._messages.rotate(-index)
        msg = self._messages.popleft()
        self._messages.rotate(index)
        return msg

    def _wake_waiters(self) -> None:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        loop.create_task(self._notify_waiters())

    async def _notify_waiters(self) -> None:
        async with self._condition:
            self._condition.notify_all()
