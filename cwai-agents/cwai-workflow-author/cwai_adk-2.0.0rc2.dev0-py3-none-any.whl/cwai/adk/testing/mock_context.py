"""MockContext for unit testing agent handlers."""

import asyncio
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx

from cwai.adk.auth import Caller
from cwai.adk.context import Context
from cwai.adk.observability.logging import get_task_logger
from cwai.adk.request_context import RequestContext
from cwai.adk.testing.mock_agents import MockAgentCatalogClient
from cwai.adk.testing.mock_dra import MockDRAClient
from cwai.adk.testing.mock_kg import MockKGClient
from cwai.adk.testing.mock_llm import MockLLMClient
from cwai.adk.testing.mock_platform import SentMessage
from cwai.adk.testing.mock_rag import MockRAGClient
from cwai.adk.testing.mock_stm import MockSTMClient
from cwai.adk.testing.mock_tools import MockToolsClient
from cwai.adk.types import AssistantMessage, Message, MessageType


class _QueueAdapter:
    """Add ADK MessageQueue keyword compatibility to plain asyncio queues."""

    def __init__(self, queue: asyncio.Queue[Message]) -> None:
        self._queue = queue
        self._skipped: deque[Message] = deque()

    async def get(self, *, sender_id: int | None = None) -> Message:
        if sender_id is None:
            if self._skipped:
                return self._skipped.popleft()
            return await self._queue.get()

        for index, msg in enumerate(self._skipped):
            if msg.sender_id == sender_id:
                self._skipped.rotate(-index)
                match = self._skipped.popleft()
                self._skipped.rotate(index)
                return match

        while True:
            msg = await self._queue.get()
            if msg.sender_id == sender_id:
                return msg
            self._skipped.append(msg)


@dataclass
class PartialResult:
    """A partial result sent during handler execution (for test assertions)."""

    message: AssistantMessage | None
    """Message sent with the partial result."""

    data: dict[str, Any] | None
    """Structured data sent with the partial result."""


@dataclass
class MockContext(Context):
    """Context subclass with test assertion attributes.

    Returned by ``mock_context()``. Extends ``Context`` with typed
    attributes for inspecting side-effects in tests::

        ctx = mock_context()
        await my_handler(ctx, msg)
        assert len(ctx.sent_messages) == 1
        assert ctx.called_subagents[0]["agent_name"] == "sub"
    """

    sent_messages: list[SentMessage] = field(default_factory=list)
    """Messages recorded by ctx.send_message()."""

    spawned_agents: list[dict[str, Any]] = field(default_factory=list)
    """Agent creation requests recorded by ctx.spawn_agent() or ctx.call_agent()."""

    stopped_agents: list[dict[str, Any]] = field(default_factory=list)
    saved_states: list[dict[str, Any]] = field(default_factory=list)
    """State snapshots recorded by ctx.save_state()."""

    called_subagents: list[dict[str, Any]] = field(default_factory=list)
    """Local sub-agent calls recorded by ctx.call_subagent()."""

    partial_results: list[PartialResult] = field(default_factory=list)
    """Partial results recorded by ctx.send_partial_result()."""


def mock_context(
    agent_id: str = "test-task",
    thread_id: str = "test-corr",
    agent_type: str = "test-agent",
    agent_instance_id: str = "test-instance",
    parent_instance_id: str | None = None,
    settings: dict | None = None,
    state: dict | None = None,
    http_client: httpx.AsyncClient | None = None,
    stm_client: MockSTMClient | None = None,
    kg_client: MockKGClient | None = None,
    rag_client: MockRAGClient | None = None,
    agents_client: MockAgentCatalogClient | None = None,
    dra_client: MockDRAClient | None = None,
    tools_client: MockToolsClient | None = None,
    mcp_client: Any | None = None,
    caller: Caller | None = None,
    message_queue: asyncio.Queue[Message] | None = None,
    subagents: dict[str, Any] | None = None,
    data_dir: Path | str | None = None,
) -> MockContext:
    """Create a MockContext with mock clients for testing.

    All side-effect calls are recorded for assertions::

        ctx = mock_context(settings={"model": "gpt-4o"})
        result = await my_handler(ctx, msg)
        assert ctx.sent_messages == [...]
        assert ctx.called_subagents == [...]

    Args:
        agent_id: Agent identifier.
        thread_id: Thread identifier.
        agent_type: Agent type name.
        agent_instance_id: Agent instance identifier.
        parent_instance_id: Parent agent instance identifier.
        settings: Agent settings dict.
        state: Initial state dict (defaults to empty).
        http_client: Optional httpx.AsyncClient for testing HTTP calls.
            If not provided, ctx.http will create a default client.
        stm_client: Optional MockSTMClient for testing STM operations.
            If not provided, a new MockSTMClient is created.
        kg_client: Optional MockKGClient for testing KG operations.
            If not provided, a new MockKGClient is created.
        rag_client: Optional MockRAGClient for testing RAG operations.
            If not provided, a new MockRAGClient is created.
        agents_client: Optional MockAgentCatalogClient for testing agent
            catalog operations. If not provided, a new MockAgentCatalogClient
            is created.
        dra_client: Optional MockDRAClient for testing DRA Gateway operations.
            If not provided, a new MockDRAClient is created.
        tools_client: Optional MockToolsClient for testing MCP tool operations.
            If not provided, a new MockToolsClient is created.
        caller: Optional Caller instance for testing permission-based logic.
            If provided, ``ctx.caller`` will return this value. If not
            provided, ``ctx.caller`` returns None (no auth token).
        message_queue: Optional message queue for testing on_run handlers.
            Pass a pre-loaded queue to simulate inbound messages for
            ``ctx.wait_for_message()`` or ``ctx.call_agent()`` (external).
            For testing ``call_agent()``, pre-load the queue with RESULT
            messages that use the spawned child instance ID as ``sender_id``.
            The first mocked spawn uses instance ID 1.
        subagents: Optional dict mapping agent names to async handler functions
            for testing ``ctx.call_subagent()``. Each handler receives
            ``(ctx, msg)`` and must return a ``Result``.
        data_dir: Optional override for ``ctx.data_dir``. Pass a
            ``tmp_path`` fixture to give the handler an isolated storage
            root that won't touch ``/mnt/data``.

    Examples:
        # Testing call_subagent
        async def analyzer(ctx, msg):
            return Result(data={"analysis": "done"})

        ctx = mock_context(subagents={"analyzer": analyzer})
        result = await ctx.call_subagent("analyzer", query={"prompt": "test"})
        assert ctx.called_subagents[0]["agent_name"] == "analyzer"

    Examples:
        # Testing call_agent for external agents
        import json

        # Pre-load queue with expected RESULT message from the first spawned child
        queue = asyncio.Queue()
        result_payload = {"status": "complete", "message": {"content": "Hello!"}}
        queue.put_nowait(Message(
            type=MessageType.RESULT,
            sender="demo-hello",
            sender_id=1,
            user_message=json.dumps(result_payload),
        ))

        ctx = mock_context(message_queue=queue)
        result = await ctx.call_agent("demo-hello", query={"person": "Alice"})
        assert result.message.content == "Hello!"
        assert ctx.spawned_agents[0]["agent_type"] == "demo-hello"
    """
    if stm_client is None:
        stm_client = MockSTMClient()
    if kg_client is None:
        kg_client = MockKGClient()
    if rag_client is None:
        rag_client = MockRAGClient()
    if agents_client is None:
        agents_client = MockAgentCatalogClient()
    if dra_client is None:
        dra_client = MockDRAClient()
    if tools_client is None:
        tools_client = MockToolsClient()

    # These lists are shared between closures and the MockContext instance.
    # Created here so closures can capture them before ctx exists.
    sent_messages: list[SentMessage] = []
    spawned_agents: list[dict[str, Any]] = []
    stopped_agents: list[dict[str, Any]] = []
    saved_states: list[dict[str, Any]] = []
    called_subagents: list[dict[str, Any]] = []
    partial_results: list[PartialResult] = []

    async def _send_message(
        agent: str,
        agent_id_param: int,
        *,
        user_message: str = "",
        system_message: str = "",
        type: MessageType = MessageType.REQUEST,
        reply_to: str = "",
        from_agent_id: int = 0,
    ) -> None:
        sent_messages.append(
            SentMessage(agent=agent, agent_id=agent_id_param, user_message=user_message)
        )

    async def _spawn_agent(
        agent_type: str,
        *,
        user_message: str = "",
        from_agent_id: int = 0,
    ) -> int:
        spawned_agents.append(
            {
                "agent_type": agent_type,
                "user_message": user_message,
            }
        )
        return len(spawned_agents)

    async def _remove_agent(agent_name: str, agent_id: str) -> None:
        stopped_agents.append(
            {
                "agent_name": agent_name,
                "agent_id": agent_id,
            }
        )

    async def _save_state() -> None:
        # Record a copy of state at save time for test assertions
        saved_states.append(dict(ctx.state))

    async def _send_partial(
        message: AssistantMessage | None,
        data: dict[str, Any] | None,
    ) -> None:
        partial_results.append(PartialResult(message=message, data=data))

    async def _noop_sleep(seconds: float) -> None:
        # No-op sleep for tests - don't actually wait
        pass

    # call_subagent implementation for testing: look up handler in subagents dict,
    # create a child mock context, and call the handler.
    subagent_handlers = subagents or {}

    async def _call_subagent(
        agent_name: str,
        *,
        query: dict[str, Any] | None = None,
    ) -> Any:
        called_subagents.append(
            {
                "agent_name": agent_name,
                "query": query,
            }
        )
        handler_fn = subagent_handlers.get(agent_name)
        if handler_fn is None:
            raise ValueError(f"Agent '{agent_name}' not found in catalog")
        child_ctx = mock_context(
            agent_id=f"{agent_id}::{agent_name}",
            thread_id=thread_id,
            agent_type=agent_type,
            agent_instance_id=agent_instance_id,
            subagents=subagents,
        )
        child_msg = Message(
            type=MessageType.REQUEST,
            sender="agent",
            query=query or {},
        )
        return await handler_fn(child_ctx, child_msg)

    adapted_message_queue: Any | None = None
    if message_queue is not None:
        adapted_message_queue = _QueueAdapter(message_queue)

    task_log = get_task_logger(
        task_id=agent_id,
        corr_id=thread_id,
        agent_type=agent_type,
        agent_instance_id=agent_instance_id,
    )

    ctx = MockContext(
        agent_id=agent_id,
        thread_id=thread_id,
        agent_type=agent_type,
        agent_instance_id=agent_instance_id,
        parent_instance_id=parent_instance_id,
        settings=settings or {},
        state=state or {},
        _llm=MockLLMClient(),
        _http=http_client,
        _stm=stm_client,
        _kg=kg_client,
        _rag=rag_client,
        _agents=agents_client,
        _dra=dra_client,
        _tools=tools_client,
        _mcp=mcp_client,
        _send_message_fn=_send_message,
        _spawn_agent_fn=_spawn_agent,
        _remove_agent_fn=_remove_agent,
        _save_state_fn=_save_state,
        _call_subagent_fn=_call_subagent,
        _send_partial=_send_partial,
        _sleep_fn=_noop_sleep,
        _data_dir=Path(data_dir) if data_dir is not None else None,
        _request_context=RequestContext(
            agent_id=agent_id,
            thread_id=thread_id,
            agent_type=agent_type,
            agent_instance_id=agent_instance_id,
        ),
        _log=task_log,
        _message_queue=adapted_message_queue,
        sent_messages=sent_messages,
        spawned_agents=spawned_agents,
        stopped_agents=stopped_agents,
        saved_states=saved_states,
        called_subagents=called_subagents,
        partial_results=partial_results,
    )
    if caller is not None:
        # Pre-set the cached_property so ctx.caller returns the provided value
        ctx.__dict__["caller"] = caller
    return ctx
