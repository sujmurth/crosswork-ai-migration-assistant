"""Mock LLM client for testing."""

from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

from cwai.adk.client import LLMStreamEvent


@dataclass
class MockLLMResponse:
    """Mock LLM response.

    When ``content`` is set and ``message`` is left empty, ``message``
    is auto-populated to match the real ``LLMClient`` response structure
    (``{"role": "assistant", "content": ...}``).
    """

    content: str | None = ""
    """Text returned as the completion content."""

    model: str = "mock-model"
    """Model name returned with the mock response."""

    message: dict[str, Any] = field(default_factory=dict)
    """Message returned with the mock response."""

    usage: dict[str, Any] = field(default_factory=dict)
    """Token usage returned with the mock response."""

    finish_reason: str | None = None
    """Finish reason returned with the mock response."""

    def __post_init__(self) -> None:
        # Match real LLMClient behavior: message always contains the
        # assistant response dict. Only auto-populate if the caller
        # didn't provide an explicit message.
        if not self.message and self.content is not None:
            self.message = {"role": "assistant", "content": self.content}


@dataclass
class MockLLMClient:
    """Mock LLM client that records calls and returns pre-configured responses.

    Examples:
        ctx = mock_context()
        llm = ctx.llm
        llm.set_response("OSPF is a link-state routing protocol.")
        result = await handle(ctx, msg)
        assert llm.calls[0]["messages"][0]["role"] == "user"
    """

    responses: list[MockLLMResponse] = field(default_factory=list)
    """Mock responses returned by completion calls."""

    calls: list[dict[str, Any]] = field(default_factory=list)
    """Messages and completion options passed to each completion call, recorded for test assertions."""

    models: list[str] = field(default_factory=list)
    """Model names configured on the mock client."""
    _call_index: int = field(default=0, repr=False)

    @property
    def total_usage(self) -> dict[str, int]:
        """Always returns zeroed usage for mocks."""
        return {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}

    def set_response(self, content: str) -> None:
        """Set a single response for the next call.

        Examples:
            llm = ctx.llm
            llm.set_response("interface GigabitEthernet0/0 is up")
            response = await llm.complete(messages)
            assert "is up" in response.content
        """
        self.responses.append(MockLLMResponse(content=content))

    async def complete(
        self, messages: list[dict[str, Any]], **kwargs: Any
    ) -> MockLLMResponse:
        """Send a mock completion request and return the next response."""
        self.calls.append({"messages": messages, **kwargs})
        if self._call_index < len(self.responses):
            response = self.responses[self._call_index]
            self._call_index += 1
            return response
        return MockLLMResponse()

    async def complete_stream(
        self, messages: list[dict[str, Any]], **kwargs: Any
    ) -> AsyncIterator[LLMStreamEvent]:
        """Stream pre-configured responses as word-level token events.

        Splits the response content on whitespace and yields one token
        event per word (with spaces re-inserted), then a final ``done``
        event carrying the full ``MockLLMResponse``.
        """
        self.calls.append({"messages": messages, **kwargs})
        if self._call_index < len(self.responses):
            response = self.responses[self._call_index]
            self._call_index += 1
        else:
            response = MockLLMResponse()

        if response.content:
            words = response.content.split(" ")
            for i, word in enumerate(words):
                token = word if i == 0 else f" {word}"
                yield LLMStreamEvent(type="token", token=token)

        # Emit tool_call_delta events if the response message has tool_calls
        tool_calls = response.message.get("tool_calls", [])
        for i, tc in enumerate(tool_calls):
            yield LLMStreamEvent(
                type="tool_call_delta",
                tool_call_delta={"index": i, **tc},
            )

        yield LLMStreamEvent(type="done", response=response)

    async def close(self) -> None:
        """No-op for mock client."""
        pass
