"""Mock MCP Tools client for testing."""

import json
from dataclasses import dataclass, field
from typing import Any

from cwai.adk.errors import ToolsCallError, ToolsError
from cwai.adk.tools import Tool


@dataclass
class MockToolsClient:
    """In-memory Tools/MCP client for testing.

    Supports pre-configured tools and call results, with operation
    recording for test assertions.

    Args:
        available_tools: Tools returned by list_tools(). Each tool's
            execute callable is auto-generated from call_results if not
            explicitly provided.
        call_results: Dict mapping tool name to result string.
            If a tool name is not in this dict, call_tool() raises
            ToolsCallError.

    Examples:
        mock_tools = MockToolsClient(
            available_tools=[
                Tool(
                    name="show_interfaces",
                    description="Show device interfaces",
                    parameters={
                        "type": "object",
                        "properties": {
                            "device": {"type": "string"},
                        },
                        "required": ["device"],
                    },
                    execute=_noop,
                ),
            ],
            call_results={
                "show_interfaces": '{"interfaces": ["eth0", "eth1"]}',
            },
        )

        ctx = mock_context(tools_client=mock_tools)
        tools = await ctx.tools.list_tools()
        result = await ctx.tools.call_tool("show_interfaces", {"device": "rtr1"})

        assert len(mock_tools.calls) == 1
        assert mock_tools.calls[0] == (
            "call_tool", "show_interfaces", {"device": "rtr1"},
        )
    """

    available_tools: list[Tool] = field(default_factory=list)
    call_results: dict[str, str] = field(default_factory=dict)

    # Records all operations: list of (operation, *args) tuples
    calls: list[tuple[Any, ...]] = field(default_factory=list)

    async def list_tools(
        self, *, timeout: float | None = None, refresh: bool = False
    ) -> list[Tool]:
        """Return tools with executors bound to call_tool().

        Mirrors real ToolsClient behavior: each tool's execute callable
        delegates to call_tool(), so calls are recorded and use call_results.
        """
        self.calls.append(("list_tools",))
        # Rebind execute callables to route through call_tool for recording
        result: list[Tool] = []
        for tool in self.available_tools:
            name = tool.name

            async def _execute(_name: str = name, **kwargs: Any) -> str:
                try:
                    return await self.call_tool(_name, kwargs)
                except ToolsError as e:
                    return json.dumps({"error": str(e)})

            result.append(
                Tool(
                    name=tool.name,
                    description=tool.description,
                    parameters=tool.parameters,
                    execute=_execute,
                    title=tool.title,
                    annotations=tool.annotations,
                    output_schema=tool.output_schema,
                )
            )
        return result

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> str:
        """Return configured result or raise ToolsCallError."""
        self.calls.append(("call_tool", name, arguments))
        if name not in self.call_results:
            raise ToolsCallError(
                f"Tool '{name}' not found",
                tool_name=name,
            )
        return self.call_results[name]


async def _noop(**_kwargs: Any) -> str:
    """No-op execute callable for mock tools."""
    return json.dumps({"error": "mock tool not configured"})


def mock_tool(
    name: str,
    description: str = "",
    parameters: dict[str, Any] | None = None,
) -> Tool:
    """Create a Tool with a no-op executor, for use with MockToolsClient."""
    return Tool(
        name=name,
        description=description,
        parameters=parameters or {"type": "object", "properties": {}},
        execute=_noop,
    )
