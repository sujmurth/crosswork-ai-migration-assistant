"""Mock STM client for testing.

Provides an in-memory implementation of the STM service with full validation
of size limits, entry counts, and status transitions.

Examples:
    from cwai.adk.testing import MockSTMClient

    stm = MockSTMClient()
    await stm.create("my-key")
    await stm.add("my-key", b"some data")
    entity = await stm.get("my-key")
    await stm.extend_lifespan("my-key", 3600.0)
    await stm.delete("my-key")

    # With custom limits for testing edge cases:
    stm = MockSTMClient(max_entries=5, max_payload_size=100)
"""

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta

from cwai.adk._framework._compression import compress, decompress
from cwai.adk.errors import (
    STMAlreadyExistsError,
    STMDeletedError,
    STMMaxEntriesError,
    STMNotFoundError,
    STMPayloadTooLargeError,
    STMSizeExceededError,
)
from cwai.adk.types.stm import StateEntity, StateEntry, STMStatus

# Default STM limits from the proto spec
DEFAULT_MAX_PAYLOAD_SIZE = 1 * 1024 * 1024  # 1MB per entry
DEFAULT_MAX_STM_SIZE = 100 * 1024 * 1024  # 100MB total
DEFAULT_MAX_ENTRIES = 10_000


@dataclass
class _MockSTMEntry:
    """Internal representation of an STM entry."""

    entry_id: str
    sequence_number: int
    timestamp: datetime
    payload: bytes


@dataclass
class _MockSTM:
    """Internal representation of an STM object."""

    stm_key: str
    status: STMStatus = STMStatus.OPEN
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    last_updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    deleted_at: datetime | None = None
    entries: list[_MockSTMEntry] = field(default_factory=list)
    expires_at: datetime | None = None

    def total_size(self) -> int:
        """Calculate total payload size of all entries."""
        return sum(len(e.payload) for e in self.entries)


class MockSTMClient:
    """In-memory mock implementation of the STM client.

    Implements STMClientProtocol with full validation of size limits,
    entry counts, and status transitions.

    Args:
        max_payload_size: Maximum size of a single payload in bytes.
            Defaults to 1MB.
        max_stm_size: Maximum total size of all entries in bytes.
            Defaults to 100MB.
        max_entries: Maximum number of entries per STM.
            Defaults to 10,000.
    """

    def __init__(
        self,
        *,
        max_payload_size: int = DEFAULT_MAX_PAYLOAD_SIZE,
        max_stm_size: int = DEFAULT_MAX_STM_SIZE,
        max_entries: int = DEFAULT_MAX_ENTRIES,
    ) -> None:
        self._stms: dict[str, _MockSTM] = {}
        self._max_payload_size = max_payload_size
        self._max_stm_size = max_stm_size
        self._max_entries = max_entries

    async def connect(self) -> None:
        """No-op for mock client. Satisfies STMClientProtocol."""

    async def close(self) -> None:
        """No-op for mock client. Satisfies STMClientProtocol."""

    async def create(
        self, stm_key: str, *, ttl: float | None = None, timeout: float | None = None
    ) -> datetime:
        """Create a new STM.

        Args:
            stm_key: Unique identifier for the STM.
            ttl: Optional time-to-live in seconds. Stored but not enforced
                by the mock (no background expiry).
            timeout: Ignored in mock (for protocol compatibility).

        Returns:
            Timestamp when the STM was created.

        Raises:
            STMAlreadyExistsError: If STM with this key already exists.
        """
        if stm_key in self._stms:
            raise STMAlreadyExistsError(f"STM with key '{stm_key}' already exists")

        if ttl is not None and ttl < 0:
            raise ValueError(f"ttl must be >= 0, got {ttl}")

        now = datetime.now(UTC)
        expires_at = now + timedelta(seconds=ttl) if ttl and ttl > 0 else None
        self._stms[stm_key] = _MockSTM(
            stm_key=stm_key,
            created_at=now,
            last_updated_at=now,
            expires_at=expires_at,
        )
        return now

    async def add(
        self,
        stm_key: str,
        payload: bytes,
        *,
        ttl: float | None = None,
        timeout: float | None = None,
    ) -> tuple[str, int]:
        """Append a state entry to an existing STM.

        Args:
            stm_key: Identifier of the STM to append to.
            payload: State data to store (max 1MB).
            ttl: Optional TTL update in seconds. Updates expires_at but
                not enforced by the mock (no background expiry).
            timeout: Ignored in mock (for protocol compatibility).

        Returns:
            Tuple of (entry_id, sequence_number) for the new entry.

        Raises:
            STMNotFoundError: If STM does not exist.
            STMDeletedError: If STM has been deleted.
            STMPayloadTooLargeError: If payload exceeds 1MB.
            STMSizeExceededError: If total STM size would exceed 100MB.
            STMMaxEntriesError: If STM has reached 10,000 entries.
        """
        if stm_key not in self._stms:
            raise STMNotFoundError(f"STM with key '{stm_key}' not found")

        if ttl is not None and ttl < 0:
            raise ValueError(f"ttl must be >= 0, got {ttl}")

        stm = self._stms[stm_key]

        if stm.status == STMStatus.DELETED:
            raise STMDeletedError(f"Cannot write to deleted STM '{stm_key}'")

        # Compress before size validation — limits apply to wire size.
        payload = compress(payload)

        # Validate payload size
        payload_size = len(payload)
        if payload_size > self._max_payload_size:
            raise STMPayloadTooLargeError(
                f"Payload size {payload_size} exceeds limit {self._max_payload_size}",
                current_size=payload_size,
                max_size=self._max_payload_size,
            )

        # Validate total STM size
        new_total = stm.total_size() + payload_size
        if new_total > self._max_stm_size:
            raise STMSizeExceededError(
                f"Total size {new_total} would exceed limit {self._max_stm_size}",
                current_size=stm.total_size(),
                max_size=self._max_stm_size,
            )

        # Validate entry count
        if len(stm.entries) >= self._max_entries:
            raise STMMaxEntriesError(
                f"Entry count {len(stm.entries)} has reached limit {self._max_entries}",
                current_count=len(stm.entries),
                max_count=self._max_entries,
            )

        # Create entry
        now = datetime.now(UTC)
        entry = _MockSTMEntry(
            entry_id=str(uuid.uuid4()),
            sequence_number=len(stm.entries) + 1,
            timestamp=now,
            payload=payload,
        )
        stm.entries.append(entry)
        stm.last_updated_at = now

        # Update expiry if ttl > 0 (0 means unchanged, proto3 semantics)
        if ttl is not None and ttl > 0:
            stm.expires_at = now + timedelta(seconds=ttl)

        return entry.entry_id, entry.sequence_number

    async def get(
        self, stm_key: str, *, timeout: float | None = None
    ) -> StateEntity | None:
        """Retrieve all entries from an STM.

        Args:
            stm_key: Identifier of the STM to retrieve.
            timeout: Ignored in mock (for protocol compatibility).

        Returns:
            StateEntity with all entries, or None if not found.
        """
        if stm_key not in self._stms:
            return None

        stm = self._stms[stm_key]

        entries = [
            StateEntry(
                entry_id=e.entry_id,
                sequence_number=e.sequence_number,
                timestamp=e.timestamp,
                payload=decompress(e.payload),
            )
            for e in stm.entries
        ]

        return StateEntity(
            stm_key=stm.stm_key,
            status=stm.status,
            created_at=stm.created_at,
            last_updated_at=stm.last_updated_at,
            deleted_at=stm.deleted_at,
            entries=entries,
            expires_at=stm.expires_at,
        )

    async def delete(self, stm_key: str, *, timeout: float | None = None) -> datetime:
        """Soft-delete an STM.

        Args:
            stm_key: Identifier of the STM to delete.
            timeout: Ignored in mock (for protocol compatibility).

        Returns:
            Timestamp when the STM was marked as deleted.

        Raises:
            STMNotFoundError: If STM does not exist.
        """
        if stm_key not in self._stms:
            raise STMNotFoundError(f"STM with key '{stm_key}' not found")

        stm = self._stms[stm_key]
        now = datetime.now(UTC)
        stm.status = STMStatus.DELETED
        stm.deleted_at = now
        stm.expires_at = None

        return now

    async def extend_lifespan(
        self, stm_key: str, ttl: float, *, timeout: float | None = None
    ) -> datetime:
        """Extend an STM's expiry to now + ttl.

        Args:
            stm_key: Identifier of the STM.
            ttl: New time-to-live in seconds from now. Stored but not
                enforced by the mock (no background expiry).
            timeout: Ignored in mock (for protocol compatibility).

        Returns:
            The new expiry timestamp.

        Raises:
            STMNotFoundError: If STM does not exist.
        """
        if stm_key not in self._stms:
            raise STMNotFoundError(f"STM with key '{stm_key}' not found")

        stm = self._stms[stm_key]

        if stm.status == STMStatus.DELETED:
            raise STMDeletedError(f"Cannot extend lifespan of deleted STM '{stm_key}'")

        now = datetime.now(UTC)
        stm.expires_at = now + timedelta(seconds=ttl)
        # Note: ExtendLifespan does NOT update last_updated_at per the
        # STM service contract (it writes no entry, only adjusts expiry).
        return stm.expires_at

    # --- Test helpers ---

    def clear(self) -> None:
        """Clear all STMs. Useful for test cleanup."""
        self._stms.clear()

    def get_all_keys(self) -> list[str]:
        """Get all STM keys. Useful for test assertions."""
        return list(self._stms.keys())
