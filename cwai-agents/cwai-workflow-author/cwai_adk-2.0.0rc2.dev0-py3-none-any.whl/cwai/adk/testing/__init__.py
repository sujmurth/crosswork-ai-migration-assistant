"""Mock client implementations for testing.

These record calls and return pre-configured responses.
"""

from cwai.adk.testing.mock_agents import (
    MockAgentCatalogClient,
    MockAgentInstance,
    MockAgentsClient,
)
from cwai.adk.testing.mock_context import PartialResult
from cwai.adk.testing.mock_dra import MockDRAClient
from cwai.adk.testing.mock_grpc_server import (
    PIPELINE_RUNTIME_ID,
    RESERVED_RUNTIME_ID_RANGE,
    ROUTING_RUNTIME_ID,
    MockAgentRuntimeServicer,
    RuntimeState,
    run_mock_server,
)
from cwai.adk.testing.mock_kg import MockKGClient
from cwai.adk.testing.mock_llm import MockLLMClient, MockLLMResponse
from cwai.adk.testing.mock_mcp import MockMcpClient
from cwai.adk.testing.mock_platform import MockPlatform, SentMessage, TaskResult
from cwai.adk.testing.mock_rag import MockRAGClient
from cwai.adk.testing.mock_stm import MockSTMClient
from cwai.adk.testing.mock_tools import MockToolsClient, mock_tool

__all__ = [
    "MockAgentCatalogClient",
    "MockAgentInstance",
    "MockAgentRuntimeServicer",
    "MockAgentsClient",
    "MockDRAClient",
    "MockKGClient",
    "MockLLMClient",
    "MockLLMResponse",
    "MockMcpClient",
    "MockPlatform",
    "MockRAGClient",
    "MockSTMClient",
    "MockToolsClient",
    "PartialResult",
    "mock_tool",
    "PIPELINE_RUNTIME_ID",
    "RESERVED_RUNTIME_ID_RANGE",
    "ROUTING_RUNTIME_ID",
    "RuntimeState",
    "SentMessage",
    "TaskResult",
    "run_mock_server",
]
