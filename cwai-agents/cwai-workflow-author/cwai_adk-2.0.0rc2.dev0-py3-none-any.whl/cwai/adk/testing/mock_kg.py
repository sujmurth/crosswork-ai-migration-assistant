"""Mock Knowledge Graph client for testing."""

import json
from dataclasses import dataclass, field
from typing import Any

from cwai.adk.errors import KGError, KGQueryError
from cwai.adk.tools import Tool


@dataclass
class MockKGClient:
    """In-memory KG client for testing.

    Supports pattern-matching responses and error injection for testing
    agent handlers that use the Knowledge Graph.

    Args:
        schema: GraphQL schema string to return from get_schema().
        skill: Skill document string to return from get_skill().
        responses: Dict mapping query substrings to response data.
            When a query contains a key, the corresponding value is returned.
        errors: Dict mapping query substrings to error lists.
            When a query contains a key, KGQueryError is raised with those errors.

    Examples:
        mock_kg = MockKGClient(
            schema="type Node { nodeId: String! }",
            skill="# KG Skill\\nQuery patterns...",
            responses={
                "queryNode": {"queryNode": [{"nodeId": "r1", "name": "router-1"}]},
            },
            errors={
                "badQuery": [{"message": "Invalid field"}],
            },
        )

        # In test
        ctx = mock_context(kg_client=mock_kg)
        result = await my_handler(ctx, msg)

        # Assert on recorded queries
        assert len(mock_kg.queries) == 1
        assert "queryNode" in mock_kg.queries[0][0]
    """

    schema: str = ""
    """Schema string returned by get_schema()."""

    skill: str = ""
    """Text returned when the test calls get_skill()."""

    responses: dict[str, Any] = field(default_factory=dict)
    """Responses that the mock returns when a query contains a configured substring."""

    errors: dict[str, list[dict[str, Any]]] = field(default_factory=dict)
    """Errors that the mock raises when a query contains a configured substring."""

    queries: list[tuple[str, dict[str, Any] | None]] = field(default_factory=list)
    """Queries and variables recorded by query() for test assertions."""

    async def query(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Execute a mock GraphQL query.

        Records the query for later assertions, then returns a matching
        response or raises an error if configured.
        """
        self.queries.append((query, variables))

        # Check for configured errors first
        for pattern, errs in self.errors.items():
            if pattern in query:
                msg = "; ".join(e.get("message", str(e)) for e in errs)
                raise KGQueryError(f"GraphQL errors: {msg}", errs)

        # Return matching response
        for pattern, response in self.responses.items():
            if pattern in query:
                return response

        return {}

    async def get_schema(self, *, timeout: float | None = None) -> str:
        """Return the configured schema string."""
        return self.schema

    async def get_skill(self, *, timeout: float | None = None) -> str:
        """Return the configured skill document string."""
        return self.skill

    async def close(self) -> None:
        """No-op for mock client."""
        pass

    @property
    def tools(self) -> list[Tool]:
        """LLM tools for Knowledge Graph operations.

        Return the same tools as KGClient for testing consistency.
        """
        return [
            Tool(
                name="kg_query",
                description=(
                    "Execute a GraphQL query against the Knowledge Graph. "
                    "The KG contains network topology, devices, interfaces, "
                    "and relationships. Use kg_get_skill first to learn the "
                    "query syntax and available entity types."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "GraphQL query string",
                        },
                        "variables": {
                            "type": "object",
                            "description": "Optional GraphQL query variables",
                        },
                    },
                    "required": ["query"],
                },
                execute=self._tool_query,
            ),
            Tool(
                name="kg_get_skill",
                description=(
                    "Get the Knowledge Graph skill document describing "
                    "available entity types, query patterns, and filter "
                    "operators. Call this before writing KG queries to "
                    "learn the correct syntax."
                ),
                parameters={"type": "object", "properties": {}},
                execute=self._tool_get_skill,
            ),
            Tool(
                name="kg_get_schema",
                description=(
                    "Get the full Knowledge Graph GraphQL SDL schema for "
                    "exact type and field discovery. This can return a large "
                    "payload, often tens of KB or more; use kg_get_skill first "
                    "for LLM query construction unless exact schema details "
                    "are needed."
                ),
                parameters={"type": "object", "properties": {}},
                execute=self._tool_get_schema,
            ),
        ]

    async def _tool_query(
        self, query: str, variables: dict[str, Any] | None = None
    ) -> str:
        """Execute kg_query tool, returning JSON result or error."""
        try:
            result = await self.query(query, variables)
            return json.dumps(result)
        except KGError as e:
            return json.dumps({"error": str(e)})

    async def _tool_get_skill(self) -> str:
        """Execute kg_get_skill tool, returning skill content or error."""
        try:
            return await self.get_skill()
        except KGError as e:
            return json.dumps({"error": str(e)})

    async def _tool_get_schema(self) -> str:
        """Execute kg_get_schema tool, returning schema content or error."""
        try:
            return await self.get_schema()
        except KGError as e:
            return json.dumps({"error": str(e)})
