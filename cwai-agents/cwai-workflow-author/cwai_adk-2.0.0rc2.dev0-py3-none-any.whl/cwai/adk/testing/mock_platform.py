"""MockPlatform: in-process platform transport for integration testing.

Implements PlatformTransport so the real runner can dispatch tasks,
route messages, and collect results without gRPC.

Examples:
    from cwai.adk.testing import MockPlatform
    from cwai.adk._framework.runner import run_agent
    from cwai.adk.agent import AgentEntry, HandlerType

    platform = MockPlatform()
    platform.dispatch_task(agent_id="t-1", query={"input": "hello"})
    platform.shutdown()

    catalog = {"my-agent": AgentEntry(
        name="my-agent", handler=handler, handler_type=HandlerType.MESSAGE,
    )}
    await run_agent(
        transport=platform,
        shutdown_event=platform.shutdown_event,
        catalog=catalog,
    )

    results = platform.get_results("t-1")
    assert results[-1].final is True
"""

import asyncio
import json
from dataclasses import dataclass
from typing import Any

from cwai.adk._framework.transport import (
    LLMProxyInfo,
    PlatformMessage,
    TaskDispatch,
)
from cwai.adk.errors import TransportClosed
from cwai.adk.testing._selective_mailbox import SelectiveMailbox
from cwai.adk.testing.mock_stm import MockSTMClient
from cwai.adk.types import Message, MessageType, Result


@dataclass
class TaskResult:
    """A result reported by the framework for a task."""

    result: Result
    """Result reported for the task."""

    final: bool
    """Indicates whether this is the final result for the task."""


@dataclass
class SentMessage:
    """A message sent to another agent."""

    agent: str
    """Name of the target agent."""

    agent_id: int
    """Identifier of the target agent instance."""

    user_message: str
    """User message sent to the target agent."""


class MockPlatform:
    """In-process platform simulation for testing.

    Implements the PlatformTransport protocol. Enqueue tasks with
    dispatch_task(), then run the agent via run_agent(). Collected
    results and failures are available for assertions after the run.
    """

    def __init__(self) -> None:
        self._queue: asyncio.Queue[PlatformMessage] = asyncio.Queue()
        self._results: dict[str, list[TaskResult]] = {}
        self._failures: dict[str, str] = {}
        self._sent_messages: list[SentMessage] = []
        self._shutdown = asyncio.Event()
        self._counter = 0
        self._stm = MockSTMClient()
        self._result_events: dict[str, asyncio.Event] = {}
        # Tracks number of handler invocations per task (set by STM persist callback)
        self._handler_counts: dict[str, int] = {}
        self._handler_events: dict[str, asyncio.Event] = {}
        self._spawn_counter = 0
        self._spawn_calls: list[dict[str, Any]] = []
        # Per-agent mailbox for on-demand message fetching (ADR-0037)
        self._mailboxes: dict[str, SelectiveMailbox[Message | None]] = {}
        self._pending_inbound: dict[str, int] = {}
        self._removed_agents: set[str] = set()

    # -- Test-facing API --------------------------------------------------

    @property
    def shutdown_event(self) -> asyncio.Event:
        """Event that signals the runner to stop."""
        return self._shutdown

    @property
    def stm(self) -> MockSTMClient:
        """Shared STM client for inspecting persisted state in tests."""
        return self._stm

    def dispatch_task(
        self,
        *,
        agent_id: str | None = None,
        query: dict[str, Any] | None = None,
        settings: dict[str, Any] | None = None,
        agent_type: str = "test-agent",
        agent_instance_id: str | None = None,
        thread_id: str | None = None,
        auth_token: str | None = None,
        llm_base_url: str | None = None,
        llm_virtual_key: str | None = None,
        llm_models: list[str] | None = None,
        llm: Any = None,
        http: Any = None,
        stm: Any = None,
    ) -> str:
        """Enqueue a task dispatch and return the agent_id."""
        if agent_id is None:
            self._counter += 1
            agent_id = f"task-{self._counter}"
        if thread_id is None:
            thread_id = f"corr-{agent_id}"
        if agent_instance_id is None:
            agent_instance_id = f"inst-{agent_id}"

        # Default to platform's shared STM client
        stm_client = stm if stm is not None else self._stm

        # Build LLMProxyInfo if both base_url and virtual_key are provided
        llm_proxy_info: LLMProxyInfo | None = None
        if llm_base_url and llm_virtual_key:
            llm_proxy_info = LLMProxyInfo(
                base_url=llm_base_url,
                virtual_key=llm_virtual_key,
                models=llm_models or [],
            )

        self._queue.put_nowait(
            TaskDispatch(
                agent_id=agent_id,
                thread_id=thread_id,
                agent_type=agent_type,
                agent_instance_id=agent_instance_id,
                settings=settings or {},
                auth_token=auth_token,
                llm_proxy_info=llm_proxy_info,
                _llm_override=llm,
                _http_override=http,
                _stm_override=stm_client,
            )
        )

        # Initial message goes to the per-agent mailbox (on-demand fetch).
        # The handler pulls it via msg_queue.get() / recv_message().
        if agent_id not in self._mailboxes:
            self._mailboxes[agent_id] = SelectiveMailbox()
        self._mailboxes[agent_id].put_nowait(
            Message(
                type=MessageType.REQUEST,
                sender="user",
                user_message=json.dumps(query) if query is not None else "",
                query=query or {},
            )
        )
        self._pending_inbound.setdefault(agent_id, 0)
        self._pending_inbound[agent_id] += 1

        return agent_id

    def send_inbound(
        self,
        agent_id: str,
        *,
        sender: str = "user",
        sender_id: int = 0,
        user_message: str = "",
        query: dict[str, Any] | None = None,
    ) -> None:
        """Send an inbound message to a running task.

        Messages are placed in a per-agent mailbox and delivered only
        when the handler requests the next message (on-demand fetch).
        """
        msg = Message(
            type=MessageType.REQUEST,
            sender=sender,
            sender_id=sender_id,
            user_message=user_message,
            query=query or {},
        )
        if agent_id not in self._mailboxes:
            self._mailboxes[agent_id] = SelectiveMailbox()
        self._mailboxes[agent_id].put_nowait(msg)
        self._pending_inbound.setdefault(agent_id, 0)
        self._pending_inbound[agent_id] += 1

    def get_results(self, agent_id: str) -> list[TaskResult]:
        """Get all results reported for a task."""
        return self._results.get(agent_id, [])

    def get_failure(self, agent_id: str) -> str | None:
        """Get the failure message for a task, or None."""
        return self._failures.get(agent_id)

    def get_sent_messages(self) -> list[SentMessage]:
        """Get all messages sent to other agents."""
        return self._sent_messages

    def pending_inbound_count(self, agent_id: str) -> int:
        """Return the number of inbound messages not yet consumed by the handler.

        Used in tests to verify on-demand fetch behavior: messages should
        remain pending while the handler is busy processing.
        """
        return self._pending_inbound.get(agent_id, 0)

    def shutdown(self) -> None:
        """Signal the runner to shut down."""
        self._shutdown.set()

    def remove_agent(self, agent_id: str) -> None:
        """Signal agent removal and unblock any pending `recv_message()` call."""
        self._removed_agents.add(agent_id)
        if agent_id not in self._mailboxes:
            self._mailboxes[agent_id] = SelectiveMailbox()
        self._mailboxes[agent_id].put_nowait(None)

    async def wait_for_task(self, agent_id: str, *, timeout: float = 5.0) -> None:
        """Wait until a task completes (result or failure).

        Args:
            agent_id: The task to wait for.
            timeout: Maximum seconds to wait.

        Raises:
            asyncio.TimeoutError: If the task doesn't complete within timeout.
        """
        if agent_id not in self._result_events:
            self._result_events[agent_id] = asyncio.Event()

        # Check if already complete
        if self._is_task_complete(agent_id):
            return

        await asyncio.wait_for(
            self._result_events[agent_id].wait(),
            timeout=timeout,
        )

    def _is_task_complete(self, agent_id: str) -> bool:
        """Check if a task has a final result or failure."""
        if agent_id in self._failures:
            return True
        results = self._results.get(agent_id, [])
        return any(r.final for r in results)

    # -- PlatformTransport protocol ---------------------------------------

    async def connect(self) -> None:
        """Open the transport connection (no-op for mock)."""
        pass

    async def recv(self) -> PlatformMessage:
        """Block until the next control message is available in the queue."""
        return await self._queue.get()

    async def recv_message(
        self,
        agent_id: str,
        *,
        sender_id: int | None = None,
    ) -> Message:
        """Block until the next data message is available for a specific agent instance.

        Pulls from the per-agent mailbox (on-demand fetch). Only called
        when the handler is ready for the next message.
        Raises TransportClosed if the agent has been removed.
        """
        if agent_id in self._removed_agents:
            raise TransportClosed(f"agent {agent_id} removed")
        if agent_id not in self._mailboxes:
            self._mailboxes[agent_id] = SelectiveMailbox()
        msg = await self._mailboxes[agent_id].get(sender_id=sender_id)
        if msg is None:
            raise TransportClosed(f"agent {agent_id} removed")
        if agent_id in self._pending_inbound and self._pending_inbound[agent_id] > 0:
            self._pending_inbound[agent_id] -= 1
        return msg

    async def send_result(
        self,
        agent_id: str,
        result: Result,
        *,
        final: bool = False,
        to_agent: str = "",
        to_agent_id: int = 0,
    ) -> None:
        """Record a task result."""
        self._results.setdefault(agent_id, []).append(
            TaskResult(result=result, final=final)
        )
        if final:
            self._signal_task_complete(agent_id)

    async def send_message(
        self,
        agent: str,
        agent_id: int,
        *,
        user_message: str = "",
        system_message: str = "",
        type: MessageType = MessageType.REQUEST,
        reply_to: str = "",
        from_agent_id: int = 0,
    ) -> None:
        """Record a message sent to another agent."""
        self._sent_messages.append(
            SentMessage(agent=agent, agent_id=agent_id, user_message=user_message)
        )

    async def spawn_agent(
        self,
        agent_type: str,
        *,
        user_message: str = "",
        from_agent_id: int = 0,
        thread_id: str = "",
    ) -> int:
        """Simulate spawning a child agent. Returns a mock agent_id."""
        self._spawn_counter += 1
        self._spawn_calls.append(
            {
                "agent_type": agent_type,
                "user_message": user_message,
                "from_agent_id": from_agent_id,
                "thread_id": thread_id,
            }
        )
        return self._spawn_counter

    async def send_fail(self, agent_id: str, error: str) -> None:
        """Record a task failure."""
        self._failures[agent_id] = error
        self._signal_task_complete(agent_id)

    async def remove_instance(self, agent_name: str, agent_id: str) -> None:
        """Record an instance removal request."""
        if not hasattr(self, "_removed_instances"):
            self._removed_instances: list[tuple[str, str]] = []
        self._removed_instances.append((agent_name, agent_id))

    def get_removed_instances(self) -> list[tuple[str, str]]:
        """Return a list of (agent_name, agent_id) removal requests."""
        return getattr(self, "_removed_instances", [])

    def get_spawn_calls(self) -> list[dict[str, Any]]:
        """Return list of spawn_agent call records."""
        return list(self._spawn_calls)

    async def close(self) -> None:
        """Close the transport (no-op for mock)."""
        pass

    def remember_message_sender(self, agent_id: str, msg: Message) -> None:
        """No-op - mock does not track per-instance reply routing."""

    def _signal_task_complete(self, agent_id: str) -> None:
        """Signal that a task has completed."""
        if agent_id not in self._result_events:
            self._result_events[agent_id] = asyncio.Event()
        self._result_events[agent_id].set()
