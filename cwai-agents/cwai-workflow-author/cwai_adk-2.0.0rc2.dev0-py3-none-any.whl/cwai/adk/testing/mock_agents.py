"""Mock agent catalog and instance clients for testing."""

from dataclasses import dataclass, field
from typing import Any

from cwai.adk.client import AgentTypeInfo


@dataclass
class MockAgentCatalogClient:
    """Mock Agent Catalog client for testing.

    Returns pre-configured agent types and records calls.

    Examples:
        mock_agents = MockAgentCatalogClient(agents=[
            AgentTypeInfo(
                name="test-agent",
                full_name="Test Agent",
                description="A test agent",
                type="BUILTIN",
                version="1.0.0",
                capabilities=["llm"],
                metadata={},
            ),
        ])
        ctx = mock_context(agents=mock_agents)
        types = await ctx.agents.list_types()
        assert len(types) == 1
    """

    agents: list[AgentTypeInfo] = field(default_factory=list)
    """Agent types returned by list_types()."""

    calls: list[str] = field(default_factory=list)
    """Method calls recorded by the mock client."""

    async def list_types(self, *, timeout: float | None = None) -> list[AgentTypeInfo]:
        """Return the pre-configured agent types.

        Args:
            timeout: Ignored in mock (for protocol compatibility).
        """
        self.calls.append("list_types")
        return list(self.agents)

    async def close(self) -> None:
        """No-op for mock client."""
        pass


@dataclass
class MockAgentInstance:
    """Mock handle to an agent instance."""

    instance_id: str = "mock-instance"
    """Identifier for the mock agent instance."""

    agent_type: str = "mock-agent"
    """Agent type name for the mock instance."""

    status: str = "running"
    """Status for the mock agent instance."""

    sent_messages: list[dict[str, Any]] = field(default_factory=list)
    """Messages recorded by send_message()."""

    result: dict[str, Any] = field(default_factory=dict)
    """Result returned by get_result()."""

    async def send_message(
        self, content: str, format: str = "text", tag: str = ""
    ) -> None:
        """Record a sent message."""
        self.sent_messages.append({"content": content, "format": format, "tag": tag})

    async def get_result(self) -> dict[str, Any]:
        """Return the pre-configured result."""
        return self.result


@dataclass
class MockAgentsClient:
    """Mock agents client that records operations and returns pre-configured results."""

    _parent: MockAgentInstance | None = field(default=None, repr=False)

    async def list_types(self) -> list[Any]:
        """Return an empty list of agent types."""
        return []

    async def list_instances(self, agent_type: str | None = None) -> list[Any]:
        """Return an empty list of agent instances."""
        return []

    async def get_instance(self, instance_id: str) -> MockAgentInstance:
        """Return a mock agent instance with the given ID."""
        return MockAgentInstance(instance_id=instance_id)

    def get_parent(self) -> MockAgentInstance | None:
        """Return the configured parent instance, if any."""
        return self._parent
