"""Mock V2 AgentRuntime gRPC server for integration testing.

Provides an in-process gRPC server that implements the V2 AgentRuntime
service with in-memory mailboxes. Tests create runtimes, dispatch agents,
send messages, and collect results without any real platform.

Examples:
    async def test_basic_lifecycle(mock_grpc_server):
        server, port = mock_grpc_server
        server.create_runtime(runtime_id=1, settings={"key": "val"})

        transport = GrpcV2Transport(
            host="localhost", port=port, runtime_id=1, agent_name="test-agent",
        )
        await transport.connect()
        # ... test the transport ...
        await transport.close()
"""

from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

import grpc
import grpc.aio

from cwai.adk._proto.agent.v2 import agent_pb2, agent_pb2_grpc
from cwai.adk.testing._selective_mailbox import SelectiveMailbox

# Reserved runtime ID constants matching platform behavior
ROUTING_RUNTIME_ID = 0
PIPELINE_RUNTIME_ID = 1
RESERVED_RUNTIME_ID_RANGE = 1000  # IDs 0-999 are reserved for special runtimes


class RuntimeState(Enum):
    """Runtime lifecycle state matching the platform's RuntimeState.

    State transitions:
    - Initialized -> Idle (on handshake)
    - Idle -> Running (on first instance creation)
    - Running -> Idle (on last instance removal)
    - Any -> Stopped (on stop)
    - Any -> Failed (on failure)
    """

    INITIALIZED = "Initialized"  # Runtime created, waiting for handshake
    IDLE = "Idle"  # Handshaked, no active instances
    RUNNING = "Running"  # Has one or more active instances
    STOPPED = "Stopped"  # Runtime stopped
    FAILED = "Failed"  # Runtime failed

    def __str__(self) -> str:
        return self.value


@dataclass
class _InstanceState:
    """In-memory state for a single agent instance."""

    agent_id: int
    agent_name: str
    data_mailbox: SelectiveMailbox[agent_pb2.Message] = field(
        default_factory=SelectiveMailbox
    )
    # Messages sent FROM this instance (captured by SendAgentMessage)
    sent_messages: list[agent_pb2.Message] = field(default_factory=list)


@dataclass
class _RuntimeState:
    """In-memory state for a registered runtime."""

    runtime_id: int
    settings: str = ""
    llm_proxy_info: str = ""
    state: RuntimeState = RuntimeState.INITIALIZED
    last_state_change: datetime = field(default_factory=datetime.now)
    control_mailbox: asyncio.Queue[agent_pb2.ControlMessage] = field(
        default_factory=asyncio.Queue
    )
    instances: dict[int, _InstanceState] = field(default_factory=dict)
    # Virtual runtimes (Routing, Pipeline) skip state validation
    virtual: bool = False

    def set_state(self, new_state: RuntimeState) -> None:
        """Update state and record the transition time."""
        self.state = new_state
        self.last_state_change = datetime.now()


class MockAgentRuntimeServicer(agent_pb2_grpc.AgentRuntimeServicer):
    """In-memory V2 AgentRuntime service for testing.

    Maintains runtimes with control mailboxes and per-instance data
    mailboxes. All RPCs operate on in-memory queues, with no persistence
    and no networking beyond the gRPC server itself.

    Args:
        pre_create_virtual_runtimes: If True, pre-creates Routing (ID 0) and
            Pipeline (ID 1) virtual runtimes. Defaults to False.
    """

    def __init__(self, *, pre_create_virtual_runtimes: bool = False) -> None:
        self._runtimes: dict[int, _RuntimeState] = {}
        # Global instance index: agent_id → (runtime_id, instance)
        self._instances: dict[int, tuple[int, _InstanceState]] = {}
        # Archived messages from removed instances (for test inspection)
        self._archived_messages: dict[int, list[agent_pb2.Message]] = {}
        # Global counter ensures unique agent_ids across all runtimes
        self._next_global_agent_id = 1
        # Optional routing: agent_type_name → runtime_id for CreateAgent
        self._agent_type_routing: dict[str, int] = {}

        # Event-based synchronization for tests
        self._result_counts: dict[int, int] = {}
        self._result_events: dict[int, asyncio.Event] = {}
        self._recv_counts: dict[int, int] = {}
        self._recv_events: dict[int, asyncio.Event] = {}

        # Error injection for testing error handling paths
        self._create_agent_error: str | None = None
        self._send_message_error: str | None = None
        # Captured requests for test assertions
        self.create_agent_requests: list[agent_pb2.CreateAgentRequest] = []
        self.receive_agent_message_requests: list[
            agent_pb2.ReceiveAgentMessageRequest
        ] = []
        # Per-agent LLM model overrides for GetLLMs RPC
        self._agent_llm_models: dict[str, list[str]] = {}
        # Captured incoming gRPC metadata per RPC method for test assertions.
        # Key is method name (e.g. "CreateAgent"), value is list of metadata
        # dicts from each invocation.
        self.captured_metadata: dict[str, list[dict[str, str]]] = {}

        if pre_create_virtual_runtimes:
            self._create_virtual_runtimes()

    def _create_virtual_runtimes(self) -> None:
        """Pre-create Routing and Pipeline virtual runtimes."""
        # Routing runtime (ID 0) - always exists in platform
        self._runtimes[ROUTING_RUNTIME_ID] = _RuntimeState(
            runtime_id=ROUTING_RUNTIME_ID,
            virtual=True,
            state=RuntimeState.IDLE,  # Virtual runtimes start in Idle
        )
        # Pipeline runtime (ID 1) - always exists in platform
        self._runtimes[PIPELINE_RUNTIME_ID] = _RuntimeState(
            runtime_id=PIPELINE_RUNTIME_ID,
            virtual=True,
            state=RuntimeState.IDLE,  # Virtual runtimes start in Idle
        )

    # -- Test helper API --------------------------------------------------

    def _capture_metadata(self, method: str, context: grpc.aio.ServicerContext) -> None:
        """Extract and store incoming gRPC metadata for test inspection."""
        raw = context.invocation_metadata()
        metadata = dict(raw) if raw else {}
        self.captured_metadata.setdefault(method, []).append(metadata)

    def get_captured_metadata(self, method: str) -> list[dict[str, str]]:
        """Return list of captured metadata dicts for a given RPC method."""
        return self.captured_metadata.get(method, [])

    def set_create_agent_error(self, error: str | None) -> None:
        """Configure CreateAgent RPC to return an error.

        Args:
            error: Error message to return, or None to clear.
        """
        self._create_agent_error = error

    def set_send_message_error(self, error: str | None) -> None:
        """Configure SendAgentMessage RPC to return an error.

        Args:
            error: Error message to return, or None to clear.
        """
        self._send_message_error = error

    def set_agent_llm_models(self, agent_name: str, models: list[str]) -> None:
        """Set the LLM models returned by GetLLMs for a given agent name.

        Args:
            agent_name: The agent name used as the lookup key.
            models: List of model name strings to return.
        """
        self._agent_llm_models[agent_name] = models

    def register_agent_type(self, agent_type: str, runtime_id: int) -> None:
        """Route CreateAgent RPCs for *agent_type* to *runtime_id*.

        Without registration, CreateAgent falls back to the first runtime.
        """
        if runtime_id not in self._runtimes:
            raise ValueError(f"Runtime {runtime_id} not registered")
        self._agent_type_routing[agent_type] = runtime_id

    def create_runtime(
        self,
        runtime_id: int,
        settings: dict[str, Any] | None = None,
        llm_proxy_info: dict[str, Any] | None = None,
        *,
        virtual: bool = False,
    ) -> None:
        """Pre-register a runtime so AgentHandshake succeeds.

        Args:
            runtime_id: Unique runtime identifier.
            settings: Settings dict to return on handshake.
            llm_proxy_info: LLM proxy info dict to return on handshake.
            virtual: If True, marks runtime as virtual (Routing, Pipeline).
                     Virtual runtimes skip state validation.
        """
        self._runtimes[runtime_id] = _RuntimeState(
            runtime_id=runtime_id,
            settings=json.dumps(settings) if settings else "",
            llm_proxy_info=json.dumps(llm_proxy_info) if llm_proxy_info else "",
            virtual=virtual,
        )

    def create_agent(
        self,
        runtime_id: int,
        agent_name: str,
        *,
        thread_id: str = "",
        rbac_ctx: str = "",
    ) -> int:
        """Create an instance and enqueue a CREATE_AGENT control message.

        Returns the assigned agent_id.
        """
        rt = self._runtimes.get(runtime_id)
        if rt is None:
            raise ValueError(f"Runtime {runtime_id} not registered")

        agent_id = self._next_global_agent_id
        self._next_global_agent_id += 1

        instance = _InstanceState(agent_id=agent_id, agent_name=agent_name)
        rt.instances[agent_id] = instance
        self._instances[agent_id] = (runtime_id, instance)

        # Transition from Idle to Running on first instance creation
        if rt.state == RuntimeState.IDLE:
            rt.set_state(RuntimeState.RUNNING)

        ctrl = agent_pb2.ControlMessage(
            id=str(uuid.uuid4()),
            type=agent_pb2.CREATE_AGENT,
            runtime_id=runtime_id,
            agent_id=agent_id,
            thread_id=thread_id,
            rbac_ctx=rbac_ctx,
        )
        rt.control_mailbox.put_nowait(ctrl)

        return agent_id

    def remove_agent(
        self,
        runtime_id: int,
        agent_id: int,
    ) -> None:
        """Remove an instance and enqueue a REMOVE_AGENT control message."""
        rt = self._runtimes.get(runtime_id)
        if rt is None:
            raise ValueError(f"Runtime {runtime_id} not registered")

        # Archive sent messages before removing, so tests can still inspect them
        if agent_id in rt.instances:
            del rt.instances[agent_id]
        if agent_id in self._instances:
            _, instance = self._instances[agent_id]
            self._archived_messages[agent_id] = list(instance.sent_messages)
            del self._instances[agent_id]

        # Transition from Running to Idle when last instance is removed
        if rt.state == RuntimeState.RUNNING and len(rt.instances) == 0:
            rt.set_state(RuntimeState.IDLE)

        ctrl = agent_pb2.ControlMessage(
            id=str(uuid.uuid4()),
            type=agent_pb2.REMOVE_AGENT,
            runtime_id=runtime_id,
            agent_id=agent_id,
        )
        rt.control_mailbox.put_nowait(ctrl)

    def delete_all_instances(self, runtime_id: int) -> list[int]:
        """Remove all instances from a runtime and transition to Idle.

        Sends a REMOVE_AGENT control message for each deleted instance.

        Args:
            runtime_id: The runtime to clear instances from.

        Returns:
            List of deleted agent IDs.

        Raises:
            ValueError: If runtime is not registered.
        """
        rt = self._runtimes.get(runtime_id)
        if rt is None:
            raise ValueError(f"Runtime {runtime_id} not registered")

        deleted_ids = list(rt.instances.keys())

        # Send REMOVE_AGENT for each instance
        for agent_id in deleted_ids:
            ctrl = agent_pb2.ControlMessage(
                id=str(uuid.uuid4()),
                type=agent_pb2.REMOVE_AGENT,
                runtime_id=runtime_id,
                agent_id=agent_id,
            )
            rt.control_mailbox.put_nowait(ctrl)

            # Remove from global index
            if agent_id in self._instances:
                del self._instances[agent_id]

        # Clear runtime instances
        rt.instances.clear()

        # Transition to Idle if we were Running
        if rt.state == RuntimeState.RUNNING:
            rt.set_state(RuntimeState.IDLE)

        return deleted_ids

    def send_to_agent(
        self,
        agent_id: int,
        message: agent_pb2.Message,
    ) -> None:
        """Deliver a data message to an agent instance's mailbox."""
        entry = self._instances.get(agent_id)
        if entry is None:
            raise ValueError(f"Agent instance {agent_id} not found")
        _, instance = entry
        instance.data_mailbox.put_nowait(message)

    def get_messages_from_agent(self, agent_id: int) -> list[agent_pb2.Message]:
        """Return all messages sent by an agent instance."""
        entry = self._instances.get(agent_id)
        if entry is None:
            # Check archived messages from removed instances
            return list(self._archived_messages.get(agent_id, []))
        _, instance = entry
        return list(instance.sent_messages)

    def get_instance(self, agent_id: int) -> _InstanceState | None:
        """Get internal instance state (for assertions)."""
        entry = self._instances.get(agent_id)
        return entry[1] if entry else None

    def get_runtime_state(self, runtime_id: int) -> RuntimeState | None:
        """Get current runtime state (for test assertions)."""
        rt = self._runtimes.get(runtime_id)
        return rt.state if rt else None

    def get_runtime(self, runtime_id: int) -> _RuntimeState | None:
        """Get internal runtime state (for detailed assertions)."""
        return self._runtimes.get(runtime_id)

    async def wait_for_result(
        self, agent_id: int, *, count: int = 1, timeout: float = 5.0
    ) -> None:
        """Wait until *agent_id* has sent >= *count* RESULT messages.

        Uses an event signaled by ``SendAgentMessage`` — no polling.
        """
        ev = self._result_events.setdefault(agent_id, asyncio.Event())
        deadline = asyncio.get_event_loop().time() + timeout
        while True:
            if self._result_counts.get(agent_id, 0) >= count:
                return
            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                raise TimeoutError(
                    f"Agent {agent_id}: expected {count} RESULT(s), "
                    f"got {self._result_counts.get(agent_id, 0)} within {timeout}s"
                )
            ev.clear()
            # Re-check after clear to avoid TOCTOU race
            if self._result_counts.get(agent_id, 0) >= count:
                return
            await asyncio.wait_for(ev.wait(), timeout=remaining)

    async def wait_for_recv(self, agent_id: int, *, timeout: float = 5.0) -> None:
        """Wait until *agent_id* receives a new data message via RPC.

        Fires when ``ReceiveAgentMessage`` returns actual data (not a
        timeout/empty response). Waits for a *new* delivery relative
        to the count at call time, so repeated calls work correctly.
        """
        ev = self._recv_events.setdefault(agent_id, asyncio.Event())
        baseline = self._recv_counts.get(agent_id, 0)
        deadline = asyncio.get_event_loop().time() + timeout
        while True:
            if self._recv_counts.get(agent_id, 0) > baseline:
                return
            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                raise TimeoutError(
                    f"Agent {agent_id}: no new ReceiveAgentMessage "
                    f"data within {timeout}s"
                )
            ev.clear()
            if self._recv_counts.get(agent_id, 0) > baseline:
                return
            await asyncio.wait_for(ev.wait(), timeout=remaining)

    # -- RPC implementations ----------------------------------------------

    async def AgentHandshake(
        self,
        request: agent_pb2.AgentHandshakeRequest,
        context: grpc.aio.ServicerContext,
    ) -> agent_pb2.AgentHandshakeResponse:
        rt = self._runtimes.get(request.runtime_id)
        if rt is None:
            return agent_pb2.AgentHandshakeResponse(
                error=f"runtime {request.runtime_id} not found",
            )
        # Transition from Initialized to Idle on successful handshake
        if rt.state == RuntimeState.INITIALIZED:
            rt.set_state(RuntimeState.IDLE)
        return agent_pb2.AgentHandshakeResponse(
            settings=rt.settings.encode(),
            llm_proxy_info=rt.llm_proxy_info.encode(),
        )

    async def GetLLMs(
        self,
        request: agent_pb2.GetLLMsRequest,
        context: grpc.aio.ServicerContext,
    ) -> agent_pb2.GetLLMsResponse:
        model_names = self._agent_llm_models.get(request.agent_name, [])
        models = [agent_pb2.AgentLLMModelDetails(model=m) for m in model_names]
        return agent_pb2.GetLLMsResponse(models=models)

    async def CreateAgent(
        self,
        request: agent_pb2.CreateAgentRequest,
        context: grpc.aio.ServicerContext,
    ) -> agent_pb2.CreateAgentResponse:
        self._capture_metadata("CreateAgent", context)
        self.create_agent_requests.append(request)
        # Check for injected error
        if self._create_agent_error:
            return agent_pb2.CreateAgentResponse(error=self._create_agent_error)

        if not self._runtimes:
            return agent_pb2.CreateAgentResponse(error="no runtimes registered")

        # Route to a specific runtime if registered, else first available
        target_runtime_id = self._agent_type_routing.get(request.name)
        if target_runtime_id is not None:
            rt = self._runtimes.get(target_runtime_id)
            if rt is None:
                return agent_pb2.CreateAgentResponse(
                    error=f"routed runtime {target_runtime_id} not found",
                )
        else:
            rt = next(iter(self._runtimes.values()))
        agent_id = self._next_global_agent_id
        self._next_global_agent_id += 1

        instance = _InstanceState(agent_id=agent_id, agent_name=request.name)
        rt.instances[agent_id] = instance
        self._instances[agent_id] = (rt.runtime_id, instance)

        # Transition from Idle to Running on first instance creation
        if rt.state == RuntimeState.IDLE:
            rt.set_state(RuntimeState.RUNNING)

        # Enqueue CREATE_AGENT so the runtime's control loop picks it up
        ctrl = agent_pb2.ControlMessage(
            id=str(uuid.uuid4()),
            type=agent_pb2.CREATE_AGENT,
            runtime_id=rt.runtime_id,
            agent_id=agent_id,
            thread_id=request.thread_id,
        )
        rt.control_mailbox.put_nowait(ctrl)

        return agent_pb2.CreateAgentResponse(instance_id=agent_id)

    async def RemoveAgent(
        self,
        request: agent_pb2.RemoveAgentRequest,
        context: grpc.aio.ServicerContext,
    ) -> agent_pb2.RemoveAgentResponse:
        self._capture_metadata("RemoveAgent", context)
        entry = self._instances.get(request.instance_id)
        if entry is None:
            return agent_pb2.RemoveAgentResponse(
                error=f"instance {request.instance_id} not found",
            )

        runtime_id, _ = entry
        rt = self._runtimes[runtime_id]

        # Archive sent messages before removing, so tests can still inspect them
        if request.instance_id in rt.instances:
            del rt.instances[request.instance_id]
        if request.instance_id in self._instances:
            _, instance = self._instances[request.instance_id]
            self._archived_messages[request.instance_id] = list(instance.sent_messages)
            del self._instances[request.instance_id]

        # Transition from Running to Idle when last instance is removed
        if rt.state == RuntimeState.RUNNING and len(rt.instances) == 0:
            rt.set_state(RuntimeState.IDLE)

        ctrl = agent_pb2.ControlMessage(
            id=str(uuid.uuid4()),
            type=agent_pb2.REMOVE_AGENT,
            runtime_id=runtime_id,
            agent_id=request.instance_id,
        )
        rt.control_mailbox.put_nowait(ctrl)

        return agent_pb2.RemoveAgentResponse()

    async def SendAgentMessage(
        self,
        request: agent_pb2.SendAgentMessageRequest,
        context: grpc.aio.ServicerContext,
    ) -> agent_pb2.SendAgentMessageResponse:
        self._capture_metadata("SendAgentMessage", context)
        # Check for injected error
        if self._send_message_error:
            return agent_pb2.SendAgentMessageResponse(error=self._send_message_error)

        msg = request.message
        if not msg or not msg.id:
            return agent_pb2.SendAgentMessageResponse(error="empty message")

        target_id = msg.to_agent_id
        entry = self._instances.get(target_id)

        if entry is None:
            # No matching target — record on source instance instead
            # so tests can inspect what was sent.
            source_id = msg.from_agent_id
            source_entry = self._instances.get(source_id)
            if source_entry is not None:
                source_entry[1].sent_messages.append(msg)
                if msg.type == agent_pb2.RESULT:
                    self._result_counts[source_id] = (
                        self._result_counts.get(source_id, 0) + 1
                    )
                    self._result_events.setdefault(source_id, asyncio.Event()).set()
            return agent_pb2.SendAgentMessageResponse()

        _, target_instance = entry

        # Record on the source too, for test inspection
        source_id = msg.from_agent_id
        source_entry = self._instances.get(source_id)
        if source_entry is not None:
            source_entry[1].sent_messages.append(msg)
            if msg.type == agent_pb2.RESULT:
                self._result_counts[source_id] = (
                    self._result_counts.get(source_id, 0) + 1
                )
                self._result_events.setdefault(source_id, asyncio.Event()).set()

        # Deliver to target's data mailbox
        target_instance.data_mailbox.put_nowait(msg)
        return agent_pb2.SendAgentMessageResponse()

    async def SendControlMessage(
        self,
        request: agent_pb2.SendControlMessageRequest,
        context: grpc.aio.ServicerContext,
    ) -> agent_pb2.SendControlMessageResponse:
        ctrl = request.message
        if not ctrl:
            return agent_pb2.SendControlMessageResponse(error="empty message")

        rt = self._runtimes.get(ctrl.runtime_id)
        if rt is None:
            return agent_pb2.SendControlMessageResponse(
                error=f"runtime {ctrl.runtime_id} not found",
            )

        rt.control_mailbox.put_nowait(ctrl)
        return agent_pb2.SendControlMessageResponse()

    async def ReceiveAgentMessage(
        self,
        request: agent_pb2.ReceiveAgentMessageRequest,
        context: grpc.aio.ServicerContext,
    ) -> agent_pb2.ReceiveAgentMessageResponse:
        self._capture_metadata("ReceiveAgentMessage", context)
        self.receive_agent_message_requests.append(
            agent_pb2.ReceiveAgentMessageRequest(
                agent_name=request.agent_name,
                agent_id=request.agent_id,
                timeout_ms=request.timeout_ms,
            )
        )
        if request.HasField("from_agent_id"):
            self.receive_agent_message_requests[
                -1
            ].from_agent_id = request.from_agent_id
        entry = self._instances.get(request.agent_id)
        if entry is None:
            return agent_pb2.ReceiveAgentMessageResponse(
                error=f"instance {request.agent_id} not found",
            )

        _, instance = entry
        timeout_s = (request.timeout_ms or 30_000) / 1000.0

        try:
            if request.HasField("from_agent_id"):
                msg = await asyncio.wait_for(
                    instance.data_mailbox.get(sender_id=request.from_agent_id),
                    timeout=timeout_s,
                )
            else:
                msg = await asyncio.wait_for(
                    instance.data_mailbox.get(), timeout=timeout_s
                )
            # Signal that this agent received actual data
            self._recv_counts[request.agent_id] = (
                self._recv_counts.get(request.agent_id, 0) + 1
            )
            self._recv_events.setdefault(request.agent_id, asyncio.Event()).set()
            return agent_pb2.ReceiveAgentMessageResponse(data_message=msg)
        except TimeoutError:
            # Timeout is normal — return empty response like the real server
            return agent_pb2.ReceiveAgentMessageResponse()

    async def ReceiveControlMessage(
        self,
        request: agent_pb2.ReceiveControlMessageRequest,
        context: grpc.aio.ServicerContext,
    ) -> agent_pb2.ReceiveControlMessageResponse:
        rt = self._runtimes.get(request.runtime_id)
        if rt is None:
            return agent_pb2.ReceiveControlMessageResponse(
                error=f"runtime {request.runtime_id} not found",
            )

        timeout_s = (request.timeout_ms or 30_000) / 1000.0

        try:
            ctrl = await asyncio.wait_for(rt.control_mailbox.get(), timeout=timeout_s)
            return agent_pb2.ReceiveControlMessageResponse(control_message=ctrl)
        except TimeoutError:
            return agent_pb2.ReceiveControlMessageResponse()


@asynccontextmanager
async def run_mock_server(
    servicer: MockAgentRuntimeServicer | None = None,
) -> AsyncIterator[tuple[MockAgentRuntimeServicer, int]]:
    """Start a mock gRPC server on a random port.

    Yields (servicer, port). The server is stopped on exit.

    Examples:
        async with run_mock_server() as (server, port):
            server.create_runtime(runtime_id=1)
            # ... connect transport to localhost:port ...
    """
    if servicer is None:
        servicer = MockAgentRuntimeServicer()

    grpc_server = grpc.aio.server()
    agent_pb2_grpc.add_AgentRuntimeServicer_to_server(servicer, grpc_server)
    port = grpc_server.add_insecure_port("[::]:0")
    await grpc_server.start()

    try:
        yield servicer, port
    finally:
        await grpc_server.stop(grace=1)
