"""GrpcTransport: bridge from v1 unary AgentComm protocol to PlatformTransport.

Adapts the current platform protocol (4 unary RPCs: Register, Handshake,
Heartbeat, Result) to the ADK 2.0 PlatformTransport interface. One task per
process, no partial results, no streaming.

The platform launches agents as K8s Jobs with FORESIGHT_TASK_ID and
FORESIGHT_CORR_ID as environment variables. The agent calls Handshake to
get task data, does work, then calls Result to report completion.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import time
from dataclasses import asdict
from typing import Any

import grpc
import grpc.aio
from opentelemetry import context, propagate

from cwai.adk._framework.transport import (
    InboundMessage,
    LLMProxyInfo,
    PlatformMessage,
    TaskDispatch,
)
from cwai.adk._proto.agent.v1 import agent_pb2, agent_pb2_grpc
from cwai.adk.config import TLSConfig
from cwai.adk.errors import TransportClosed
from cwai.adk.observability.metrics import record_grpc_call
from cwai.adk.types import Message, MessageType, Result

logger = logging.getLogger("cwai.adk.client.grpc_transport")

# Safety-net timeout for gRPC transport operations. See ADR-0023.
DEFAULT_TIMEOUT: float = 300.0


class GrpcTransport:
    """PlatformTransport backed by the v1 unary AgentComm gRPC protocol.

    Performs a single Handshake on connect(), delivers one TaskDispatch via
    recv(), and sends a single Result on send_result(final=True) or
    send_fail(). After the result is sent, subsequent recv() raises
    TransportClosed so the runner shuts down.

    Partial results (send_result with final=False) are not supported by the
    v1 protocol and raise NotImplementedError.
    """

    def __init__(
        self,
        host: str,
        port: int,
        task_id: str,
        corr_id: str,
        *,
        agent_type: str = "",
        agent_instance_id: str = "",
        timeout: float = DEFAULT_TIMEOUT,
        tls_config: TLSConfig | None = None,
        _stm_override: Any = None,
        _channel_override: grpc.aio.Channel | None = None,
    ) -> None:
        self._host = host
        self._port = port
        self._task_id = task_id
        self._corr_id = corr_id
        self._agent_type = agent_type
        self._agent_instance_id = agent_instance_id
        self._timeout = timeout
        self._tls_config = tls_config or TLSConfig()
        self._stm_override = _stm_override
        self._channel_override = _channel_override

        self._channel: grpc.aio.Channel | None = None
        self._stub: agent_pb2_grpc.AgentCommStub | None = None
        self._dispatch: TaskDispatch | None = None
        self._initial_message: InboundMessage | None = None
        self._phase = 0  # 0=dispatch, 1=initial_message, 2=done
        self._done = asyncio.Event()
        self.llm_proxy_info: LLMProxyInfo | None = None

    @classmethod
    def from_env(cls) -> GrpcTransport:
        """Construct from standard platform environment variables.

        Raises ValueError if required env vars (FORESIGHT_TASK_ID,
        FORESIGHT_CORR_ID) are missing or empty.
        """
        task_id = os.environ.get("FORESIGHT_TASK_ID", "")
        corr_id = os.environ.get("FORESIGHT_CORR_ID", "")

        missing = []
        if not task_id:
            missing.append("FORESIGHT_TASK_ID")
        if not corr_id:
            missing.append("FORESIGHT_CORR_ID")
        if missing:
            raise ValueError(
                f"Required environment variables not set: "
                f"{', '.join(missing)}. These are normally set by "
                f"the platform when launching an agent job."
            )

        host = os.environ.get("FORESIGHT_SERVICE_HOST", "foresight")
        port = int(os.environ.get("FORESIGHT_GRPC_PORT", "50051"))
        agent_type = os.environ.get("FORESIGHT_AGENT_NAME", "unknown-agent")

        return cls(
            host=host,
            port=port,
            task_id=task_id,
            corr_id=corr_id,
            agent_type=agent_type,
            tls_config=TLSConfig.from_env(),
        )

    async def connect(self) -> None:
        """Open gRPC channel and perform Handshake to get task data."""
        # Restore parent trace context from the platform env var so all
        # spans and outbound RPCs are children of the platform's trace.
        _attach_parent_span_context()

        address = f"{self._host}:{self._port}"

        if self._channel_override is not None:
            self._channel = self._channel_override
        else:
            creds = self._tls_config.load_grpc_credentials()
            self._channel = grpc.aio.secure_channel(
                address, creds, options=self._tls_config.grpc_channel_options()
            )

        self._stub = agent_pb2_grpc.AgentCommStub(self._channel)

        # Proto uses int64 task IDs.
        request = agent_pb2.HandshakeRequest(
            taskID=int(self._task_id),
            correlationID=int(self._corr_id),
        )

        logger.info(
            "Performing handshake",
            extra={"task_id": self._task_id, "address": address},
        )

        start_time = time.monotonic()
        try:
            response = await self._stub.Handshake(
                request, metadata=_otel_metadata(), timeout=self._timeout
            )
            duration_ms = (time.monotonic() - start_time) * 1000

            if response.status == agent_pb2.StatusType.ERROR:
                record_grpc_call(
                    "Handshake",
                    duration_ms,
                    success=False,
                    grpc_code="application_error",
                )
                raise RuntimeError(f"Handshake failed: {response.msg}")

            record_grpc_call("Handshake", duration_ms, success=True)
        except grpc.aio.AioRpcError as e:
            duration_ms = (time.monotonic() - start_time) * 1000
            record_grpc_call(
                "Handshake", duration_ms, success=False, grpc_code=e.code().name
            )
            raise

        query = _parse_json_bytes(response.query, "query")
        settings = _parse_json_bytes(response.settings, "settings")
        self.llm_proxy_info = _parse_llm_proxy_info(response.llm_proxy_info)

        self._dispatch = TaskDispatch(
            agent_id=self._task_id,
            thread_id=self._corr_id,
            agent_type=self._agent_type,
            agent_instance_id=self._agent_instance_id,
            settings=settings,
            auth_token=os.environ.get("FORESIGHT_RBAC_CONTEXT") or None,
            llm_proxy_info=self.llm_proxy_info,
            ca_cert_path=self._tls_config.ca_cert_path,
            _stm_override=self._stm_override,
        )

        # V2: query is delivered as the first InboundMessage, not in TaskDispatch
        import json as _json

        self._initial_message = InboundMessage(
            agent_id=self._task_id,
            message=Message(
                type=MessageType.REQUEST,
                sender="user",
                user_message=_json.dumps(query) if query else "",
                query=query,
            ),
        )

        logger.info(
            "Handshake complete",
            extra={"task_id": self._task_id},
        )

    async def recv(self) -> PlatformMessage:
        """Return TaskDispatch, then block until done."""
        if self._phase == 0:
            self._phase = 1
            if self._dispatch is None:
                raise RuntimeError("connect() must be called before recv()")
            return self._dispatch

        # Block until the task result has been sent, then signal shutdown.
        await self._done.wait()
        raise TransportClosed("Single task completed")

    async def recv_message(
        self,
        agent_id: str,
        *,
        sender_id: int | None = None,
    ) -> Message:
        """Return the initial message (V1 supports only one).

        V1 agents receive exactly one message per instance. The handler
        must return a Result on the first call; a second call means the
        handler didn't produce a result and is treated as an error.
        """
        if sender_id is not None:
            raise NotImplementedError("selective receive requires the V2 transport")
        if self._initial_message is None:
            raise RuntimeError("V1 transport supports only one message per instance")
        msg = self._initial_message
        self._initial_message = None
        return msg.message

    async def send_result(
        self,
        agent_id: str,
        result: Result,
        *,
        final: bool = False,
        to_agent: str = "",
        to_agent_id: int = 0,
    ) -> None:
        """Send task result via the Result RPC. Only final results supported."""
        if not final:
            raise NotImplementedError(
                "Partial results not supported by the v1 gRPC protocol"
            )

        payload_dict: dict[str, Any] = {
            "status": result.status.value,
        }

        # Include message fields if present
        if result.message is not None:
            message_dict = asdict(result.message)
            # V1 historically emitted message.type; keep it as an alias so older
            # platform or CLI consumers continue to work while newer code uses format.
            message_dict["type"] = message_dict["format"]
            payload_dict["message"] = message_dict

        # Include structured data if present
        if result.data is not None:
            payload_dict["data"] = result.data

        payload = json.dumps(payload_dict).encode()
        await self._send_result_rpc(agent_id, payload)

    async def send_fail(self, agent_id: str, error: str) -> None:
        """Send error result via the Result RPC."""
        # V1 error results also keep message.type for the same compatibility
        # reason as send_result().
        payload = json.dumps(
            {
                "status": "error",
                "message": {
                    "content": error,
                    "format": "text",
                    "type": "text",
                },
            }
        ).encode()

        await self._send_result_rpc(agent_id, payload, is_error=True)

    async def send_message(
        self,
        agent: str,
        agent_id: int,
        *,
        user_message: str = "",
        system_message: str = "",
        type: MessageType = MessageType.REQUEST,
        reply_to: str = "",
        from_agent_id: int = 0,
    ) -> None:
        """Send a message to another agent. Not supported by the v1 protocol."""
        raise NotImplementedError(
            "Agent-to-agent messaging not supported by the v1 gRPC protocol"
        )

    async def spawn_agent(
        self,
        agent_type: str,
        *,
        user_message: str = "",
        from_agent_id: int = 0,
        thread_id: str = "",
    ) -> int:
        """Spawn a child agent. Not supported by the v1 protocol."""
        raise NotImplementedError(
            "Agent spawning not supported by the v1 gRPC protocol"
        )

    async def remove_instance(self, agent_name: str, agent_id: str) -> None:
        """No-op - v1 proto does not support RemoveAgent."""
        pass

    def remember_message_sender(self, agent_id: str, msg: Message) -> None:
        """No-op - v1 proto does not track per-instance reply routing."""

    async def close(self) -> None:
        """Close the gRPC channel."""
        if self._channel is not None:
            await self._channel.close()
            self._channel = None
            self._stub = None

    async def _send_result_rpc(
        self, task_id: str, payload: bytes, *, is_error: bool = False
    ) -> None:
        """Call the Result RPC and signal done."""
        if self._stub is None:
            raise RuntimeError("Transport not connected")

        request = agent_pb2.ResultRequest(
            taskID=int(task_id),
            correlationID=int(self._corr_id),
            result=payload,
            status=(
                agent_pb2.StatusType.ERROR if is_error else agent_pb2.StatusType.OK
            ),
        )

        logger.info(
            "Sending result",
            extra={"task_id": task_id, "is_error": is_error},
        )

        start_time = time.monotonic()
        try:
            response = await self._stub.Result(
                request, metadata=_otel_metadata(), timeout=self._timeout
            )
            duration_ms = (time.monotonic() - start_time) * 1000

            if response.status == agent_pb2.StatusType.ERROR:
                logger.error(
                    "Result RPC returned error",
                    extra={"task_id": task_id, "error_msg": response.msg},
                )
                # RPC transport succeeded but the platform reported an
                # application-level error. Record as a logical failure so
                # success-rate metrics reflect actual outcome.
                record_grpc_call(
                    "Result",
                    duration_ms,
                    success=False,
                    grpc_code="application_error",
                )
            else:
                record_grpc_call("Result", duration_ms, success=True)
        except grpc.aio.AioRpcError as e:
            duration_ms = (time.monotonic() - start_time) * 1000
            record_grpc_call(
                "Result", duration_ms, success=False, grpc_code=e.code().name
            )
            raise

        self._done.set()


def _otel_metadata() -> tuple[tuple[str, str], ...]:
    """Inject current OTEL context into gRPC metadata."""
    carrier: dict[str, str] = {}
    propagate.inject(carrier)
    return tuple((k.lower(), v) for k, v in carrier.items())


def _attach_parent_span_context() -> None:
    """Read FORESIGHT_SPAN_CONTEXT env var and attach as the current context.

    The platform serializes the OTEL context as a base64-encoded,
    semicolon-delimited string of key=value pairs (W3C traceparent format).
    For example, the decoded string looks like:
        traceparent=00-<trace_id>-<span_id>-<flags>;

    After attaching, all subsequent spans and propagate.inject() calls
    will be children of the platform's trace.
    """
    raw = os.environ.get("FORESIGHT_SPAN_CONTEXT")
    if not raw:
        return

    try:
        decoded = base64.b64decode(raw).decode("utf-8")
    except Exception:
        logger.warning("Failed to decode FORESIGHT_SPAN_CONTEXT")
        return

    # Parse "key=value;key2=value2;" into a carrier dict.
    carrier: dict[str, str] = {}
    for pair in decoded.split(";"):
        pair = pair.strip()
        if not pair:
            continue
        # Split on first '=' only — values may contain '='.
        key, _, value = pair.partition("=")
        if key and value:
            carrier[key] = value

    if not carrier:
        return

    parent_ctx = propagate.extract(carrier=carrier)
    context.attach(parent_ctx)


def _parse_json_bytes(data: bytes, label: str) -> dict[str, Any]:
    """Decode JSON bytes from handshake, returning empty dict on empty input."""
    if not data:
        return {}
    try:
        parsed = json.loads(data)
    except (json.JSONDecodeError, UnicodeDecodeError):
        logger.warning("Failed to parse bytes as JSON", extra={"label": label})
        return {}
    if isinstance(parsed, dict):
        return parsed
    # Server may send a bare string query; wrap it.
    return {"query": parsed}


def _parse_llm_proxy_info(data: bytes) -> LLMProxyInfo | None:
    """Parse llm_proxy_info JSON bytes from handshake response."""
    if not data:
        return None
    try:
        info = json.loads(data)
    except (json.JSONDecodeError, UnicodeDecodeError):
        logger.warning("Failed to parse llm_proxy_info bytes")
        return None
    base_url = info.get("base_url", "")
    virtual_key = info.get("virtual_key", "")
    if not base_url or not virtual_key:
        return None
    models_raw = info.get("models", [])
    models = [m for m in models_raw if isinstance(m, str)]
    logger.info(
        "Parsed LLM proxy info",
        extra={"base_url": base_url, "models": models},
    )
    return LLMProxyInfo(base_url=base_url, virtual_key=virtual_key, models=models)
