"""LLM client for Crosswork AI llm-proxy requests (LiteLLM-compatible).

Calls the OpenAI-compatible /v1/chat/completions endpoint through the
Crosswork AI llm-proxy. Authentication uses the virtual_key from the
platform handshake rather than the RBAC token. RequestContext headers
are included for OpenTelemetry trace propagation.

Includes retry logic with exponential backoff for transient errors.
"""

import json
import logging
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol

import httpx
from opentelemetry import trace

from cwai.adk._retry import (
    DEFAULT_RETRIES,
    http_call_with_retry,
)
from cwai.adk.auth import parse_jwt
from cwai.adk.errors import LLMError, LLMUnavailableError
from cwai.adk.observability._labels import _resolve_agent_type
from cwai.adk.observability.metrics import (
    record_llm_error,
    record_llm_fallback,
    record_llm_request,
    record_llm_retry,
    record_llm_tokens,
)
from cwai.adk.request_context import RequestContext

# LLM operations can take significant time, especially for complex prompts
# or when generating many tokens. 5 minutes is a reasonable default that
# accommodates most use cases while still failing on truly stuck requests.
DEFAULT_TIMEOUT: float = 300.0
"""Default request timeout, in seconds."""

# Default logger used when no task-scoped logger is provided
_default_logger = logging.getLogger("cwai.adk.client.llm")
tracer = trace.get_tracer("cwai.adk.client.llm")
"""OpenTelemetry tracer used for LLM client spans."""


@dataclass
class LLMResponse:
    """Parsed response from an LLM completion request.

    ``message`` contains the raw ``choices[0].message`` dict from the
    OpenAI-format response.  This gives access to tool_calls, refusal,
    and any future fields without requiring ADK changes.

    ``content`` is a convenience alias for ``message["content"]`` and
    is None when the model returns only tool calls.
    """

    content: str | None
    """Text returned by the model, or None when the response contains only tool calls."""
    model: str
    """Model that generated the response."""
    message: dict[str, Any] = field(default_factory=dict)
    """Raw assistant message from the response."""
    usage: dict[str, Any] = field(default_factory=dict)
    """Token usage returned in the response."""
    finish_reason: str | None = None
    """Finish reason for the response."""


@dataclass
class Model:
    """An available LLM model."""

    id: str
    """Model identifier used in requests."""
    name: str
    """Human-readable model name."""


class LLMResponseProtocol(Protocol):
    """Structural shape of an LLM completion response.

    Both the concrete ``LLMResponse`` dataclass and ``MockLLMResponse``
    satisfy this interface.
    """

    content: str | None
    model: str
    message: dict[str, Any]
    usage: dict[str, Any]


@dataclass
class LLMStreamEvent:
    """Event emitted during streaming LLM completion.

    Event types:
        token: A text token from the response. ``token`` is set.
        tool_call_delta: A fragment of a tool call. ``tool_call_delta``
            contains the incremental piece (index, id, name, or
            arguments fragment).
        done: Stream complete. ``response`` contains the assembled
            ``LLMResponse`` with full content and tool calls.
    """

    type: Literal["token", "tool_call_delta", "done"]
    """Type of stream event."""
    token: str | None = None
    """Text token for this event, when the event type is token."""
    tool_call_delta: dict[str, Any] = field(default_factory=dict)
    """Incremental tool-call data for tool_call_delta events."""
    response: Any | None = None  # LLMResponse when type="done"
    """Final assembled response for the done event."""


class LLMClientProtocol(Protocol):
    """Protocol for LLM client implementations."""

    @property
    def total_usage(self) -> dict[str, int]:
        """Accumulated token usage across all requests in this session."""
        ...

    @property
    def models(self) -> list[str]:
        """Models configured by the platform for this agent."""
        ...

    async def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        timeout: float = ...,
        **kwargs: Any,
    ) -> LLMResponseProtocol:
        """Send a chat completion request.

        Args:
            messages: OpenAI-format message list.
            timeout: Request timeout in seconds. Defaults to client timeout.
            **kwargs: Additional arguments (model, temperature, max_tokens, etc.).

        Returns:
            LLM response object.

        Raises:
            LLMError: On request failure (including timeout).
        """
        ...

    def complete_stream(
        self,
        messages: list[dict[str, Any]],
        *,
        timeout: float = ...,
        **kwargs: Any,
    ) -> AsyncIterator[LLMStreamEvent]:
        """Stream a chat completion request.

        Args:
            messages: OpenAI-format message list.
            timeout: Request timeout in seconds. Defaults to client timeout.
            **kwargs: Additional arguments (model, temperature, max_tokens, etc.).

        Yields:
            LLMStreamEvent with type "token", "tool_call_delta", or "done".

        Raises:
            LLMError: On request failure (including timeout).
        """
        ...

    async def close(self) -> None:
        """Close the client and release resources."""
        ...


class LLMClient:
    """Async client for the llm-proxy /v1/chat/completions endpoint.

    Args:
        base_url: LLM proxy base URL, such as "http://llm-proxy:8000".
        virtual_key: Bearer token for llm-proxy auth (from handshake).
        request_context: Optional context for trace propagation and task identity headers.
        http_client: Optional httpx.AsyncClient for testing (DI).
        timeout: Default timeout in seconds for requests. Per-request
            timeout can override this. Defaults to DEFAULT_TIMEOUT (300s).
        retries: Default number of retry attempts for transient errors.
            Per-request retries can override this. Defaults to 5.
            Set to 0 to disable retries.
        log: Optional logger for task-scoped logging. If not provided,
            uses the module-level default logger.
        models: Platform-configured models for this agent. If no model
            is specified in complete() or complete_stream(), the client
            uses this list for fallback. Explicit model parameters are
            validated against this list.
    """

    def __init__(
        self,
        base_url: str,
        virtual_key: str,
        request_context: RequestContext | None = None,
        *,
        http_client: httpx.AsyncClient | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
        log: logging.Logger | logging.LoggerAdapter | None = None,
        models: list[str] | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._virtual_key = virtual_key
        self._request_context = request_context
        self._client = http_client or httpx.AsyncClient()
        self._timeout = timeout
        self._retries = retries
        self._log = log or _default_logger
        self._models = list(models) if models else []
        self._total_usage: dict[str, int] = {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        }

    @property
    def models(self) -> list[str]:
        """Models configured by the platform for this agent."""
        return list(self._models)

    @property
    def _agent_type(self) -> str | None:
        """Agent type for metric labeling, or None if no request context."""
        return _resolve_agent_type(self)

    @property
    def _user_name(self) -> str:
        """Username for metric/span labeling, from JWT.

        Returns "unknown" instead of None so that dashboard queries can
        filter on a concrete value rather than dealing with missing
        attributes. This is intentionally different from _agent_type and
        _agent_instance_id which return None when absent.
        """
        if self._request_context is None or not self._request_context.auth_token:
            return "unknown"
        if not hasattr(self, "_cached_caller"):
            self._cached_caller = parse_jwt(self._request_context.auth_token)
        if self._cached_caller is None or not self._cached_caller.username:
            return "unknown"
        return self._cached_caller.username

    @property
    def _agent_instance_id(self) -> str | None:
        """Agent instance ID for metric labeling, or None if no request context."""
        if self._request_context is None:
            return None
        return self._request_context.agent_instance_id or None

    @property
    def total_usage(self) -> dict[str, int]:
        """Accumulated token usage across all requests in this session."""
        return dict(self._total_usage)

    def _accumulate_usage(self, usage: dict[str, Any]) -> None:
        """Add per-request token counts to session totals."""
        for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
            if key in usage:
                self._total_usage[key] += usage[key]

    def _build_headers(self) -> dict[str, str]:
        """Merge auth header with optional RequestContext headers."""
        headers: dict[str, str] = {}
        if self._request_context:
            headers.update(self._request_context.get_headers())
        # Virtual key always takes precedence over RequestContext auth
        headers["Authorization"] = f"Bearer {self._virtual_key}"
        return headers

    def _enrich_llm_span(
        self,
        span: trace.Span,
        messages: list[dict[str, Any]],
        response_message: dict[str, Any],
    ) -> None:
        """Add Crosswork AI context attributes and prompt/response events to an LLM span."""
        span.set_attribute("user.name", self._user_name)
        if self._agent_type:
            span.set_attribute("cwai.agent.type", self._agent_type)
        if self._agent_instance_id:
            span.set_attribute("cwai.agent.instance_id", self._agent_instance_id)
        self._record_prompt_response_events(span, messages, response_message)

    @staticmethod
    def _record_prompt_response_events(
        span: trace.Span,
        messages: list[dict[str, Any]],
        response_message: dict[str, Any],
    ) -> None:
        """Record prompt and response as span events if logging is enabled.

        Controlled by CWAI_TRACE_CONTENT_MAX_LENGTH. When set to a
        value > 0, captures message content up to that length.
        Records response content and tool_calls as separate attributes.
        """
        from cwai.adk.features import get_trace_content_max_length
        from cwai.adk.observability.trace_events import record_content_event

        max_len = get_trace_content_max_length()
        if max_len <= 0:
            return

        prompt_text = json.dumps(messages, ensure_ascii=False)
        record_content_event(span, "cwai.agent.llm.prompt", prompt_text)

        # Record response - content and tool_calls as separate attributes
        content = response_message.get("content")
        tool_calls = response_message.get("tool_calls")
        if content is not None or tool_calls:
            attrs: dict[str, str] = {}
            if content is not None:
                attrs["cwai.agent.llm.response.content"] = content
            if tool_calls:
                attrs["cwai.agent.llm.response.tool_calls"] = json.dumps(
                    tool_calls, ensure_ascii=False
                )
            # Apply truncation to each attribute
            truncated = False
            for key, value in attrs.items():
                if len(value) > max_len:
                    attrs[key] = value[:max_len]
                    truncated = True
            span.add_event(
                "cwai.agent.llm.response",
                attributes={**attrs, "cwai.agent.llm.response.truncated": truncated},
            )

    def _log_llm_content(
        self,
        messages: list[dict[str, Any]],
        response_message: dict[str, Any],
    ) -> None:
        """Log LLM prompt and response content at INFO level.

        Gated by CWAI_TRACE_CONTENT_MAX_LENGTH (same knob as span events).
        """
        from cwai.adk.features import get_trace_content_max_length

        max_len = get_trace_content_max_length()
        if max_len <= 0:
            return

        prompt_text = json.dumps(messages, ensure_ascii=False)
        if len(prompt_text) > max_len:
            prompt_text = prompt_text[:max_len]
        self._log.info("LLM prompt", extra={"llm.prompt": prompt_text})

        extra: dict[str, str] = {}
        content = response_message.get("content")
        tool_calls = response_message.get("tool_calls")
        if content is not None:
            extra["llm.response.content"] = (
                content[:max_len] if len(content) > max_len else content
            )
        if tool_calls:
            tc_text = json.dumps(tool_calls, ensure_ascii=False)
            extra["llm.response.tool_calls"] = (
                tc_text[:max_len] if len(tc_text) > max_len else tc_text
            )
        if extra:
            self._log.info("LLM response", extra=extra)

    async def complete(
        self,
        messages: list[dict[str, Any]],
        *,
        model: str | list[str] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        retries: int | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Send a chat completion request.

        Args:
            messages: OpenAI-format message list.
            model: Model name, ordered fallback list, or None to use
                platform-configured models (with fallback behavior).
            temperature: Sampling temperature.
            max_tokens: Maximum tokens in response.
            timeout: Request timeout in seconds. Overrides client default.
            retries: Number of retry attempts for transient errors.
                None uses client default, 0 disables retries.
            **kwargs: Extra OpenAI-compatible request options to include in
                the request body, such as tools and tool_choice.

        Returns:
            Parsed response from the completion request.

        Raises:
            LLMUnavailableError: All models in fallback list failed.
            LLMError: Non-model-specific request failure (including timeout),
                or if an explicit model is not in the configured models list.
        """
        effective_retries = retries if retries is not None else self._retries
        models = self._normalize_models(model)

        # If explicit model(s) provided, validate against configured list
        if models:
            self._validate_models(models)
        elif self._models:
            # No model specified, use platform-configured models
            models = self._models

        if not models:
            # No model specified and no configured models: proxy default
            return await self._do_complete(
                messages,
                None,
                temperature,
                max_tokens,
                timeout,
                effective_retries,
                **kwargs,
            )

        # Try each model in order; collect errors for the final exception
        errors: list[tuple[str, Exception]] = []
        for i, m in enumerate(models):
            try:
                return await self._do_complete(
                    messages,
                    m,
                    temperature,
                    max_tokens,
                    timeout,
                    effective_retries,
                    **kwargs,
                )
            except LLMError as e:
                self._log.warning(
                    "Model failed, trying next",
                    extra={"model": m, "error": str(e)},
                )
                errors.append((m, e))
                # Record fallback if there's a next model to try
                if i + 1 < len(models):
                    record_llm_fallback(m, models[i + 1], agent_type=self._agent_type)

        msg = "; ".join(f"{m}: {e}" for m, e in errors)
        raise LLMUnavailableError(f"All models failed: {msg}")

    async def complete_stream(
        self,
        messages: list[dict[str, Any]],
        *,
        model: str | list[str] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[LLMStreamEvent]:
        """Stream a chat completion request.

        Yields ``LLMStreamEvent`` objects as the LLM generates tokens.
        The final event has ``type="done"`` with the assembled response.

        Note:
            Use ``complete()`` when retry behavior is required.

        Args:
            messages: OpenAI-format message list.
            model: Model name, ordered fallback list, or None to use
                platform-configured models (with fallback behavior).
            temperature: Sampling temperature.
            max_tokens: Maximum tokens in response.
            timeout: Request timeout in seconds. Overrides client default.
            **kwargs: Extra OpenAI-compatible request options to include in
                the request body, such as tools and tool_choice.

        Yields:
            LLMStreamEvent with type "token", "tool_call_delta", or "done".

        Raises:
            LLMUnavailableError: All models in fallback list failed.
            LLMError: Non-model-specific request failure (including timeout),
                or if an explicit model is not in the configured models list.
        """
        models = self._normalize_models(model)

        # If explicit model(s) provided, validate against configured list
        if models:
            self._validate_models(models)
        elif self._models:
            # No model specified, use platform-configured models
            models = self._models

        if not models:
            # No model specified and no configured models: proxy default
            async for event in self._do_complete_stream(
                messages, None, temperature, max_tokens, timeout, **kwargs
            ):
                yield event
            return

        errors: list[tuple[str, Exception]] = []
        for i, m in enumerate(models):
            try:
                async for event in self._do_complete_stream(
                    messages, m, temperature, max_tokens, timeout, **kwargs
                ):
                    yield event
                return
            except LLMError as e:
                self._log.warning(
                    "Model stream failed, trying next",
                    extra={"model": m, "error": str(e)},
                )
                errors.append((m, e))
                # Record fallback if there's a next model to try
                if i + 1 < len(models):
                    record_llm_fallback(m, models[i + 1], agent_type=self._agent_type)

        msg = "; ".join(f"{m}: {e}" for m, e in errors)
        raise LLMUnavailableError(f"All models failed: {msg}")

    async def list_models(self, *, timeout: float | None = None) -> list[Model]:
        """List available models via GET /v1/models.

        Args:
            timeout: Request timeout in seconds. Overrides client default.
        """
        with tracer.start_as_current_span("llm.list_models") as span:
            try:
                resp = await self._client.get(
                    f"{self._base_url}/v1/models",
                    headers=self._build_headers(),
                    timeout=timeout if timeout is not None else self._timeout,
                )
            except httpx.RequestError as e:
                err = f"list_models failed: {type(e).__name__}({e!r})"
                span.set_status(trace.StatusCode.ERROR, err)
                self._log.error(
                    "list_models failed",
                    extra={"error": str(e), "error_type": type(e).__name__},
                )
                raise LLMError(err) from e

            if resp.status_code != 200:
                body_text = resp.text
                excerpt = body_text[:500] if body_text else ""
                err = f"list_models failed: HTTP {resp.status_code}"
                if excerpt:
                    err += f" - {excerpt}"
                span.set_status(trace.StatusCode.ERROR, err)
                self._log.error(
                    "list_models failed",
                    extra={
                        "status_code": resp.status_code,
                        "response_body": body_text,
                    },
                )
                raise LLMError(err)

            body = resp.json()
            models = [
                Model(id=m["id"], name=m.get("name", m["id"]))
                for m in body.get("data", [])
            ]
            span.set_attribute("llm.models.count", len(models))
            self._log.debug("Listed models", extra={"count": len(models)})
            return models

    async def close(self) -> None:
        """Close the underlying HTTP client and log session token totals."""
        usage = self._total_usage
        if usage["total_tokens"] > 0:
            with tracer.start_as_current_span("llm.session_usage") as span:
                for key, value in usage.items():
                    span.set_attribute(f"llm.session.{key}", value)
            self._log.info(
                "LLM session closed",
                extra={
                    "session_prompt_tokens": usage["prompt_tokens"],
                    "session_completion_tokens": usage["completion_tokens"],
                    "session_total_tokens": usage["total_tokens"],
                },
            )
        await self._client.aclose()

    @staticmethod
    def _normalize_models(model: str | list[str] | None) -> list[str]:
        if model is None:
            return []
        if isinstance(model, str):
            return [model]
        return list(model)

    def _validate_models(self, models: list[str]) -> None:
        """Validate that requested models are in the configured list.

        Raises LLMError if any model is not in self._models.
        Skips validation if self._models is empty (no platform config).
        """
        if not self._models or not models:
            return
        invalid = [m for m in models if m not in self._models]
        if invalid:
            raise LLMError(
                f"Model(s) {invalid} not in configured models: {self._models}"
            )

    async def _do_complete(
        self,
        messages: list[dict[str, Any]],
        model: str | None,
        temperature: float | None,
        max_tokens: int | None,
        timeout: float | None,
        retries: int,
        **kwargs: Any,
    ) -> LLMResponse:
        """Send a single completion request for one model with retry."""
        with tracer.start_as_current_span("llm.complete") as span:
            if model is not None:
                span.set_attribute("llm.model", model)
            span.set_attribute("llm.message_count", len(messages))

            self._log.debug(
                "LLM completion request",
                extra={"model": model, "message_count": len(messages)},
            )

            body: dict[str, Any] = {"messages": messages, **kwargs}
            if model is not None:
                body["model"] = model
            if temperature is not None:
                body["temperature"] = temperature
            if max_tokens is not None:
                body["max_tokens"] = max_tokens

            effective_timeout = timeout if timeout is not None else self._timeout

            # Callback for recording retry metrics
            def on_retry(attempt: int, delay: float, reason: str) -> None:
                record_llm_retry(
                    model or "", reason, attempt, agent_type=self._agent_type
                )

            t0 = time.monotonic()
            try:
                resp = await http_call_with_retry(
                    lambda: self._client.post(
                        f"{self._base_url}/v1/chat/completions",
                        json=body,
                        headers=self._build_headers(),
                        timeout=effective_timeout,
                    ),
                    retries=retries,
                    log=self._log,
                    on_retry=on_retry,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err = f"LLM complete() failed: {type(e).__name__}({e!r})"
                span.set_status(trace.StatusCode.ERROR, err)
                self._log.error(
                    "LLM request failed",
                    extra={
                        "model": model,
                        "error": str(e),
                        "error_type": type(e).__name__,
                        "duration_ms": round(duration_ms, 1),
                    },
                )
                record_llm_request(
                    model or "",
                    duration_ms,
                    success=False,
                    stream=False,
                    agent_type=self._agent_type,
                    user_name=self._user_name,
                )
                record_llm_error(
                    model or "",
                    type(e).__name__.lower(),
                    agent_type=self._agent_type,
                )
                raise LLMError(err) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("llm.duration_ms", duration_ms)

            # Check for non-retryable errors or exhausted retries
            if resp.status_code != 200:
                body_text = resp.text
                excerpt = body_text[:500] if body_text else ""
                err = f"LLM request failed: HTTP {resp.status_code}"
                if excerpt:
                    err += f" - {excerpt}"
                span.set_status(trace.StatusCode.ERROR, err)
                self._log.error(
                    "LLM request failed",
                    extra={
                        "model": model,
                        "status_code": resp.status_code,
                        "duration_ms": round(duration_ms, 1),
                        "response_body": body_text,
                    },
                )
                record_llm_request(
                    model or "",
                    duration_ms,
                    success=False,
                    stream=False,
                    agent_type=self._agent_type,
                    user_name=self._user_name,
                )
                record_llm_error(model or "", "http_error", agent_type=self._agent_type)
                raise LLMError(err)

            data = resp.json()
            result = self._parse_response(data)

            span.set_attribute("llm.response_model", result.model)
            usage = result.usage
            if usage:
                for key in (
                    "prompt_tokens",
                    "completion_tokens",
                    "total_tokens",
                ):
                    if key in usage:
                        span.set_attribute(f"llm.usage.{key}", usage[key])

            # Enriched span attributes and prompt/response events
            self._enrich_llm_span(span, messages, result.message)
            self._log_llm_content(messages, result.message)

            self._log.debug(
                "LLM completion done",
                extra={
                    "model": result.model,
                    "prompt_tokens": usage.get("prompt_tokens"),
                    "completion_tokens": usage.get("completion_tokens"),
                    "duration_ms": round(duration_ms, 1),
                },
            )

            self._accumulate_usage(usage)

            # Record metrics
            record_llm_request(
                result.model or model or "",
                duration_ms,
                success=True,
                stream=False,
                agent_type=self._agent_type,
                user_name=self._user_name,
            )
            record_llm_tokens(
                result.model or model or "",
                usage.get("prompt_tokens", 0),
                usage.get("completion_tokens", 0),
                agent_type=self._agent_type,
                user_name=self._user_name,
            )

            return result

    async def _do_complete_stream(
        self,
        messages: list[dict[str, Any]],
        model: str | None,
        temperature: float | None,
        max_tokens: int | None,
        timeout: float | None,
        **kwargs: Any,
    ) -> AsyncIterator[LLMStreamEvent]:
        """Stream a single completion request for one model.

        Sends a request with ``stream=true`` and parses the SSE response.
        Each SSE ``data:`` line contains a JSON chunk with a delta object.
        Tool calls arrive as fragments across multiple chunks and are
        accumulated into complete tool call dicts.
        """
        with tracer.start_as_current_span("llm.complete_stream") as span:
            if model is not None:
                span.set_attribute("llm.model", model)
            span.set_attribute("llm.message_count", len(messages))

            body: dict[str, Any] = {
                "messages": messages,
                "stream": True,
                **kwargs,
            }
            if model is not None:
                body["model"] = model
            if temperature is not None:
                body["temperature"] = temperature
            if max_tokens is not None:
                body["max_tokens"] = max_tokens

            t0 = time.monotonic()

            try:
                async with self._client.stream(
                    "POST",
                    f"{self._base_url}/v1/chat/completions",
                    json=body,
                    headers=self._build_headers(),
                    timeout=timeout if timeout is not None else self._timeout,
                ) as resp:
                    if resp.status_code != 200:
                        # Must read the body to release the connection
                        await resp.aread()
                        body_text = resp.text
                        excerpt = body_text[:500] if body_text else ""
                        duration_ms = (time.monotonic() - t0) * 1000
                        err = f"LLM stream request failed: HTTP {resp.status_code}"
                        if excerpt:
                            err += f" - {excerpt}"
                        span.set_status(trace.StatusCode.ERROR, err)
                        self._log.error(
                            "LLM stream request failed",
                            extra={
                                "model": model,
                                "status_code": resp.status_code,
                                "duration_ms": round(duration_ms, 1),
                                "response_body": body_text,
                            },
                        )
                        record_llm_request(
                            model or "",
                            duration_ms,
                            success=False,
                            stream=True,
                            agent_type=self._agent_type,
                            user_name=self._user_name,
                        )
                        record_llm_error(
                            model or "", "http_error", agent_type=self._agent_type
                        )
                        raise LLMError(err)

                    content_parts: list[str] = []
                    # Keyed by tool call index; accumulates fragments
                    tool_calls_acc: dict[int, dict[str, Any]] = {}
                    response_model = ""
                    usage: dict[str, Any] = {}
                    finish_reason: str | None = None

                    async for event in self._parse_sse(resp):
                        delta = event.get("delta", {})

                        # Track model name from first chunk
                        if not response_model and event.get("model"):
                            response_model = event["model"]

                        # Usage may appear in the final chunk
                        if event.get("usage"):
                            usage = event["usage"]

                        # Track finish_reason from final chunk
                        if event.get("finish_reason"):
                            finish_reason = event["finish_reason"]

                        # Content token
                        if delta.get("content"):
                            content_parts.append(delta["content"])
                            yield LLMStreamEvent(
                                type="token",
                                token=delta["content"],
                            )

                        # Tool call fragments
                        if delta.get("tool_calls"):
                            for tc_delta in delta["tool_calls"]:
                                idx = tc_delta.get("index", 0)
                                if idx not in tool_calls_acc:
                                    tool_calls_acc[idx] = {
                                        "id": "",
                                        "type": "function",
                                        "function": {
                                            "name": "",
                                            "arguments": "",
                                        },
                                    }
                                acc = tool_calls_acc[idx]
                                if tc_delta.get("id"):
                                    acc["id"] = tc_delta["id"]
                                fn = tc_delta.get("function", {})
                                if fn.get("name"):
                                    acc["function"]["name"] = fn["name"]
                                if fn.get("arguments"):
                                    acc["function"]["arguments"] += fn["arguments"]
                                yield LLMStreamEvent(
                                    type="tool_call_delta",
                                    tool_call_delta=tc_delta,
                                )

                    # Assemble final response
                    full_content = "".join(content_parts) or None
                    message: dict[str, Any] = {
                        "role": "assistant",
                        "content": full_content,
                    }
                    if tool_calls_acc:
                        message["tool_calls"] = [
                            tool_calls_acc[i] for i in sorted(tool_calls_acc)
                        ]

                    duration_ms = (time.monotonic() - t0) * 1000
                    span.set_attribute("llm.duration_ms", duration_ms)
                    span.set_attribute("llm.response_model", response_model)
                    if usage:
                        for key in (
                            "prompt_tokens",
                            "completion_tokens",
                            "total_tokens",
                        ):
                            if key in usage:
                                span.set_attribute(f"llm.usage.{key}", usage[key])

                    # Enriched span attributes and prompt/response events
                    self._enrich_llm_span(span, messages, message)
                    self._log_llm_content(messages, message)

                    result = LLMResponse(
                        content=full_content,
                        model=response_model,
                        message=message,
                        usage=usage,
                        finish_reason=finish_reason,
                    )

                    self._accumulate_usage(usage)

                    # Record metrics
                    effective_model = response_model or model or ""
                    record_llm_request(
                        effective_model,
                        duration_ms,
                        success=True,
                        stream=True,
                        agent_type=self._agent_type,
                        user_name=self._user_name,
                    )
                    record_llm_tokens(
                        effective_model,
                        usage.get("prompt_tokens", 0),
                        usage.get("completion_tokens", 0),
                        agent_type=self._agent_type,
                        user_name=self._user_name,
                    )

                    yield LLMStreamEvent(type="done", response=result)
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err = f"LLM complete_stream() failed: {type(e).__name__}({e!r})"
                span.set_status(trace.StatusCode.ERROR, err)
                self._log.error(
                    "LLM stream request failed",
                    extra={
                        "model": model,
                        "error": str(e),
                        "error_type": type(e).__name__,
                        "duration_ms": round(duration_ms, 1),
                    },
                )
                record_llm_request(
                    model or "",
                    duration_ms,
                    success=False,
                    stream=True,
                    agent_type=self._agent_type,
                    user_name=self._user_name,
                )
                record_llm_error(
                    model or "",
                    type(e).__name__.lower(),
                    agent_type=self._agent_type,
                )
                raise LLMError(err) from e

    async def _parse_sse(
        self,
        resp: httpx.Response,
    ) -> AsyncIterator[dict[str, Any]]:
        """Parse SSE lines from an httpx streaming response.

        Yields the parsed JSON from each ``data:`` line, skipping
        blank lines, comments, and the ``[DONE]`` sentinel.
        Each yielded dict is the chunk object with ``model`` and
        ``choices[0].delta`` extracted to top level for convenience.
        """
        async for line in resp.aiter_lines():
            line = line.strip()
            if not line or line.startswith(":"):
                continue
            if not line.startswith("data:"):
                continue
            payload = line[len("data:") :].strip()
            if payload == "[DONE]":
                return
            try:
                chunk = json.loads(payload)
            except json.JSONDecodeError:
                self._log.warning(
                    "Skipping malformed SSE chunk",
                    extra={"payload": payload[:200]},
                )
                continue

            # Flatten: pull delta and model to top level
            result: dict[str, Any] = {
                "model": chunk.get("model", ""),
            }
            choices = chunk.get("choices", [])
            if choices:
                result["delta"] = choices[0].get("delta", {})
                result["finish_reason"] = choices[0].get("finish_reason")
            # Usage appears in some providers' final chunk
            if chunk.get("usage"):
                result["usage"] = chunk["usage"]
            yield result

    @staticmethod
    def _parse_response(data: dict[str, Any]) -> LLMResponse:
        """Extract message, model, usage, finish_reason from response."""
        try:
            choice = data["choices"][0]
            message = choice["message"]
        except (KeyError, IndexError) as e:
            raise LLMError(f"Unexpected response format: {e}") from e

        return LLMResponse(
            content=message.get("content"),
            model=data.get("model", ""),
            message=message,
            usage=data.get("usage", {}),
            finish_reason=choice.get("finish_reason"),
        )
