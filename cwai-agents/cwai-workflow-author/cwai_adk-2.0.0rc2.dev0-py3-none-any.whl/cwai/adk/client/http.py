"""HTTP client factory with OpenTelemetry (OTEL) instrumentation and context propagation.

Creates a configured httpx.AsyncClient that automatically injects
RequestContext headers and creates OTEL spans for each request.
"""

import time

import httpx
from opentelemetry import trace

from cwai.adk.observability.metrics import record_http_error, record_http_request
from cwai.adk.request_context import RequestContext

tracer = trace.get_tracer("cwai.adk.client.http")
"""OpenTelemetry tracer used for HTTP request spans."""

# Alias for shorter type annotations
_UseDefault = httpx._client.UseClientDefault
_USE_DEFAULT = httpx._client.USE_CLIENT_DEFAULT


class _InstrumentedAsyncClient(httpx.AsyncClient):
    """AsyncClient wrapper that records error metrics for transport failures."""

    async def send(
        self,
        request: httpx.Request,
        *,
        stream: bool = False,
        auth: httpx._types.AuthTypes | _UseDefault | None = _USE_DEFAULT,
        follow_redirects: bool | _UseDefault = _USE_DEFAULT,
    ) -> httpx.Response:
        """Send request, recording error metrics on transport failures."""
        try:
            return await super().send(
                request,
                stream=stream,
                auth=auth,
                follow_redirects=follow_redirects,
            )
        except httpx.TimeoutException:
            self._record_error(request, "timeout")
            raise
        except httpx.ConnectError:
            self._record_error(request, "connect_error")
            raise
        except httpx.ReadError:
            self._record_error(request, "read_error")
            raise
        except httpx.WriteError:
            self._record_error(request, "write_error")
            raise
        except httpx.HTTPStatusError:
            # This is raised by raise_for_status(), not transport errors
            raise
        except httpx.HTTPError:
            # Catch-all for other httpx errors
            self._record_error(request, "http_error")
            raise

    def _record_error(self, request: httpx.Request, error_type: str) -> None:
        """Record error metric and end span if present."""
        host = request.url.host or "unknown"
        record_http_error(
            method=request.method,
            host=host,
            error_type=error_type,
        )
        # End span with error status if present
        span = request.extensions.get("otel_span")
        if span:
            span.set_status(trace.StatusCode.ERROR, error_type)
            span.end()


def create_http_client(
    request_context: RequestContext | None = None,
    *,
    timeout: float = 30.0,
    transport: httpx.AsyncBaseTransport | None = None,
) -> httpx.AsyncClient:
    """Create an HTTP client with OTEL instrumentation and context propagation.

    The returned client automatically:
    - Injects RequestContext headers (task_id, corr_id, agent identity, OTEL trace)
    - Creates OTEL spans for each request with method, url, status_code attributes
    - Records metrics for request count, duration, and errors

    Args:
        request_context: Context for header injection. If None, only OTEL
            trace context is propagated.
        timeout: Default request timeout in seconds.
        transport: Optional transport for testing, such as ``httpx.MockTransport``.

    Returns:
        Configured httpx.AsyncClient.

    Examples:
        client = create_http_client(request_context)
        resp = await client.get("https://api.example.com/data")
        data = resp.json()
    """

    async def on_request(request: httpx.Request) -> None:
        """Inject context headers before each request."""
        if request_context:
            for key, value in request_context.get_headers().items():
                # Don't override if already set
                if key not in request.headers:
                    request.headers[key] = value

    # Store span and start time on request.extensions so response hook can access them
    async def on_request_with_span(request: httpx.Request) -> None:
        """Start OTEL span, record start time, and inject headers."""
        span = tracer.start_span(
            "http.request",
            attributes={
                "http.method": request.method,
                "http.url": str(request.url),
            },
        )
        request.extensions["otel_span"] = span
        request.extensions["start_time"] = time.perf_counter()
        await on_request(request)

    async def on_response(response: httpx.Response) -> None:
        """Complete OTEL span and record metrics."""
        request = response.request
        span = request.extensions.get("otel_span")
        start_time = request.extensions.get("start_time")

        # Record metrics
        if start_time is not None:
            duration_ms = (time.perf_counter() - start_time) * 1000
            host = request.url.host or "unknown"
            record_http_request(
                method=request.method,
                host=host,
                status_code=response.status_code,
                duration_ms=duration_ms,
            )

        # Complete span
        if span:
            span.set_attribute("http.status_code", response.status_code)
            if response.status_code >= 400:
                span.set_status(
                    trace.StatusCode.ERROR,
                    f"HTTP {response.status_code}",
                )
            span.end()

    return _InstrumentedAsyncClient(
        timeout=timeout,
        transport=transport,
        event_hooks={
            "request": [on_request_with_span],
            "response": [on_response],
        },
    )
