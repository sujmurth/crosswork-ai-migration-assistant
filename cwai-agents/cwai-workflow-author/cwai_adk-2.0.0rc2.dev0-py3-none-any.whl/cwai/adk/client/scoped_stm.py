"""Scoped STM client that automatically prefixes keys.

Wraps an STMClientProtocol and automatically prefixes all keys with the
task scope ({agent_type}:{agent_id}:). The client also prevents use of
reserved labels ('state', 'recovery') which are managed by the framework.

Examples:
    # Framework creates this and exposes via ctx.stm
    scoped = ScopedSTMClient(stm_client, "my-agent", "agent-123")

    # Developer uses simple labels
    await scoped.create("my-data")  # Creates "my-agent:agent-123:my-data"
    await scoped.add("my-data", payload)
    entity = await scoped.get("my-data")
    await scoped.extend_lifespan("my-data", 3600.0)
    await scoped.delete("my-data")
"""

from datetime import datetime

from cwai.adk.client.stm import STMClientProtocol
from cwai.adk.types.stm import StateEntity

# Reserved labels managed by the framework (not available to user code)
_RESERVED_LABELS: frozenset[str] = frozenset({"state", "recovery"})

# Default timeout for STM operations (seconds)
DEFAULT_TIMEOUT: float = 300.0
"""Default request timeout, in seconds."""


class ScopedSTMClient:
    """STM client that automatically prefixes keys with the task scope.

    Args:
        client: Underlying STM client.
        agent_type: Agent type for key prefix.
        agent_id: Agent ID for key prefix.
    """

    def __init__(
        self,
        client: STMClientProtocol,
        agent_type: str,
        agent_id: str,
    ) -> None:
        self._client = client
        self._prefix = f"{agent_type}:{agent_id}:"

    def _full_key(self, label: str) -> str:
        """Build full STM key from label, validating it's not reserved."""
        if label in _RESERVED_LABELS:
            raise ValueError(
                f"'{label}' is a reserved STM label managed by the "
                "framework. Use ctx.state for task state persistence."
            )
        return f"{self._prefix}{label}"

    async def create(
        self, label: str, *, ttl: float | None = None, timeout: float = DEFAULT_TIMEOUT
    ) -> datetime:
        """Create a new STM with the given label.

        Args:
            label: Short identifier for this STM (for example, "my-data").
                The client prefixes the label with the task scope.
            ttl: Optional time-to-live in seconds.
            timeout: Request timeout in seconds.

        Returns:
            Timestamp when the STM was created.

        Raises:
            ValueError: If label is reserved (managed by the framework).
            STMAlreadyExistsError: If STM with this label already exists.
            STMTTLOutOfRangeError: If TTL is invalid or exceeds server limit.
            STMError: On other failures (including timeout).
        """
        return await self._client.create(
            self._full_key(label), ttl=ttl, timeout=timeout
        )

    async def add(
        self,
        label: str,
        payload: bytes,
        *,
        ttl: float | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> tuple[str, int]:
        """Append a state entry to an existing STM.

        Args:
            label: STM label to append to.
            payload: Data to store (max 1MB).
            ttl: Optional TTL update in seconds. Resets the STM expiry.
            timeout: Request timeout in seconds.

        Returns:
            Entry ID and sequence number for the new entry.

        Raises:
            ValueError: If label is reserved (managed by the framework).
            STMNotFoundError: If STM does not exist.
            STMDeletedError: If STM has been deleted.
            STMPayloadTooLargeError: If payload exceeds 1MB.
            STMSizeExceededError: If total STM size would exceed 100MB.
            STMMaxEntriesError: If STM has reached 10,000 entries.
            STMTTLOutOfRangeError: If TTL is invalid or exceeds server limit.
            STMError: On other failures (including timeout).
        """
        return await self._client.add(
            self._full_key(label), payload, ttl=ttl, timeout=timeout
        )

    async def get(
        self, label: str, *, timeout: float = DEFAULT_TIMEOUT
    ) -> StateEntity | None:
        """Retrieve all entries from an STM.

        Args:
            label: STM label to retrieve.
            timeout: Request timeout in seconds.

        Returns:
            State entity with all entries, or None if the STM is not found.

        Raises:
            ValueError: If label is reserved (managed by the framework).
            STMError: On failures other than not found (including timeout).
        """
        return await self._client.get(self._full_key(label), timeout=timeout)

    async def delete(self, label: str, *, timeout: float = DEFAULT_TIMEOUT) -> datetime:
        """Mark an STM as deleted.

        Args:
            label: STM label to delete.
            timeout: Request timeout in seconds.

        Returns:
            Timestamp when the STM was marked as deleted.

        Raises:
            ValueError: If label is reserved (managed by the framework).
            STMNotFoundError: If STM does not exist.
            STMError: On other failures (including timeout).
        """
        return await self._client.delete(self._full_key(label), timeout=timeout)

    async def extend_lifespan(
        self, label: str, ttl: float, *, timeout: float = DEFAULT_TIMEOUT
    ) -> datetime:
        """Extend an STM's expiry to now + ttl.

        Args:
            label: STM label to extend.
            ttl: New time-to-live in seconds from now.
            timeout: Request timeout in seconds.

        Returns:
            The new expiry timestamp.

        Raises:
            ValueError: If label is reserved (managed by the framework).
            STMNotFoundError: If STM does not exist.
            STMTTLOutOfRangeError: If TTL is invalid or exceeds server limit.
            STMError: On other failures (including timeout).
        """
        return await self._client.extend_lifespan(
            self._full_key(label), ttl, timeout=timeout
        )
