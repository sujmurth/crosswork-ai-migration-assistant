# RAG Client

The RAG client (`ctx.rag`) provides semantic search and document management
via the Kontext service. Documents are stored as embedding vectors in
PostgreSQL/pgvector and retrieved by similarity search.

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `CWAI_RAG_URL` | `https://kontext:8000/api/v1/context` | Kontext service base URL |
| `CWAI_TLS_SKIP_VERIFY` | `false` | Skip TLS certificate verification |
| `CWAI_CA_CERT_PATH` | (none) | Path to CA certificate for TLS |

The client is created lazily on first access to `ctx.rag`.

## Timeout

All operations have a default timeout of 300 seconds (5 minutes) per
ADR-0023. This prevents indefinite hangs while accommodating slow operations.

Override the timeout per-request by passing a `timeout` parameter:

```python
# Short timeout for quick operations
results = await ctx.rag.search("docs", "query", timeout=10.0)

# Longer timeout for large uploads
result = await ctx.rag.upload("docs", many_sections, timeout=600.0)
```

When creating a client directly (outside of `ctx.rag`), you can set a
client-wide default:

```python
from cwai.adk.client.rag import RAGClient

client = RAGClient(base_url, timeout=60.0)  # 60s default for all operations
```

## Collections

Documents are organized into collections. Collection names must be
alphanumeric with hyphens and underscores (regex: `^[a-zA-Z0-9_-]+$`).
Invalid names are rejected by the service with a 422 validation error.

## Document Sections

Each document consists of one or more sections. A section has:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `search_column` | `str` | Yes | Text that gets embedded for similarity search |
| `content` | `dict[str, Any]` | Yes | Structured data stored alongside the embedding |
| `date_created` | `date` | Yes | Creation date |
| `date_valid_until` | `date` | Yes | Expiration date for validity filtering |
| `tags` | `list[str] \| None` | No | Tags for filtering (AND logic on search) |

## Operations

### Search

Search embeds the query text and finds similar document sections using
vector similarity. Results include a similarity `score` between 0 and 1
(higher is more similar).

```python
results = await ctx.rag.search(
    "network-docs",
    "How do I configure BGP?",
    tags=["networking", "cisco"],  # AND filter
    limit=5,
    date_valid=True,  # exclude expired documents
)

for r in results:
    print(f"[{r.score:.2f}] {r.search_column}")
    print(f"  tags={r.tags}, id={r.section_id}")
    print(f"  content={r.content}")
```

Parameters:

- `tags` -- Only return sections matching all specified tags (AND logic).
- `limit` -- Maximum number of results. Defaults to the service setting (5).
- `date_valid` -- If `True`, exclude sections where `date_valid_until` is
  in the past.

### Upload Sections

Upload pre-chunked document sections as structured data:

```python
from datetime import date
from cwai.adk.types import RAGDocumentSection

sections = [
    RAGDocumentSection(
        search_column="Configure BGP on IOS-XR",
        content={
            "cli": "router bgp 65000\n neighbor 10.0.0.1",
            "platform": "ios-xr",
        },
        date_created=date(2026, 3, 1),
        date_valid_until=date(2027, 3, 1),
        tags=["networking", "bgp", "ios-xr"],
    ),
    RAGDocumentSection(
        search_column="Configure OSPF on IOS-XR",
        content={
            "cli": "router ospf 1\n area 0",
            "platform": "ios-xr",
        },
        date_created=date(2026, 3, 1),
        date_valid_until=date(2027, 3, 1),
        tags=["networking", "ospf", "ios-xr"],
    ),
]

result = await ctx.rag.upload("network-docs", sections)
print(f"Inserted {result.inserted} sections")
print(f"Section IDs: {result.section_ids}")
```

The `search_column` text is what gets embedded for similarity search.
Choose it carefully -- it determines how well the section matches queries.
The `content` dict stores arbitrary structured data returned with search
results.

### Upload Markdown

Upload a markdown document with YAML frontmatter. The service parses the
frontmatter for metadata and stores the markdown body in `content.body`.

```python
markdown = """\
---
search_column: "Configure BGP neighbor on IOS-XR"
date_created: 2026-03-01
date_valid_until: 2027-03-01
tags:
  - networking
  - bgp
content:
  platform: ios-xr
  author: network-team
---

# BGP Neighbor Configuration

To configure a BGP neighbor on IOS-XR:

```
router bgp 65000
 neighbor 10.0.0.1
  remote-as 65001
  address-family ipv4 unicast
```
"""

result = await ctx.rag.upload_markdown("network-docs", markdown)
```

Required frontmatter fields:

| Field | Description |
|-------|-------------|
| `search_column` | Text to embed for similarity search |
| `date_created` | Creation date (YYYY-MM-DD) |
| `date_valid_until` | Expiration date (YYYY-MM-DD) |

Optional frontmatter fields:

| Field | Description |
|-------|-------------|
| `tags` | List of strings for filtering |
| `content` | Dict of structured metadata (merged with markdown body) |

The markdown body (everything after the frontmatter) is stored in
`content.body`. Any unknown frontmatter fields are also added to
`content`.

### Get Document

Retrieve a document section by its UUID:

```python
doc = await ctx.rag.get_document("network-docs", "abc-123-def-456")
print(doc.search_column)
print(doc.content)
print(doc.tags)
```

Raises `RAGNotFoundError` if the section does not exist.

### Delete Document

Delete a single document section:

```python
await ctx.rag.delete_document("network-docs", "abc-123-def-456")
```

Raises `RAGNotFoundError` if the section does not exist.

### List Collections

List all collections with their document counts:

```python
collections = await ctx.rag.list_collections()
for c in collections:
    print(f"{c.name}: {c.document_count} sections")
```

### Delete Collection

Delete an entire collection and all its documents:

```python
deleted_count = await ctx.rag.delete_collection("old-docs")
print(f"Removed {deleted_count} sections")
```

Raises `RAGNotFoundError` if the collection does not exist or is empty.

## Error Handling

The client maps HTTP status codes to typed exceptions:

| HTTP Status | Exception | When |
|-------------|-----------|------|
| 404 | `RAGNotFoundError` | Section or collection does not exist |
| 413 | `RAGPayloadTooLargeError` | Request body exceeds size limit |
| 422 | `RAGValidationError` | Invalid input (bad collection name, missing fields) |
| 5xx / transport | `RAGConnectionError` | Server error or network failure |

```python
from cwai.adk.errors import (
    RAGConnectionError,
    RAGNotFoundError,
    RAGPayloadTooLargeError,
    RAGValidationError,
)

try:
    results = await ctx.rag.search("docs", "query")
except RAGValidationError as e:
    # e.detail contains the validation error message from the service
    ctx.log.error("Validation failed", extra={"detail": e.detail})
except RAGNotFoundError:
    ctx.log.warning("Resource not found")
except RAGPayloadTooLargeError:
    ctx.log.error("Payload too large, reduce section count or content size")
except RAGConnectionError:
    ctx.log.error("Cannot reach Kontext service")
```

All RAG exceptions inherit from `RAGError`, which inherits from `ADKError`.

## Testing

Use `MockRAGClient` to test handlers that use `ctx.rag`:

```python
from datetime import date

from cwai.adk.types import RAGSearchResult
from cwai.adk.testing import MockRAGClient
from cwai.adk.testing.mock_context import mock_context
from cwai.adk.types import Message, MessageType

async def test_my_handler():
    mock_rag = MockRAGClient(
        search_results=[
            RAGSearchResult(
                id=1,
                section_id="abc-123",
                search_column="BGP guide",
                score=0.95,
                tags=["networking"],
                date_created=date(2026, 3, 1),
                date_valid_until=date(2027, 3, 1),
                content={"body": "Configure BGP..."},
            ),
        ],
    )
    ctx = mock_context(rag_client=mock_rag)
    msg = Message(type=MessageType.REQUEST, sender="user", query={"question": "BGP config"})

    result = await my_handler(ctx, msg)

    # Assert on recorded operations
    assert len(mock_rag.calls) == 1
    assert mock_rag.calls[0][0] == "search"
    assert mock_rag.calls[0][1]["query"] == "BGP config"
```

`MockRAGClient` records all operations in the `calls` list as
`(operation_name, args_dict)` tuples. Configure responses via constructor
fields:

| Field | Type | Default | Used by |
|-------|------|---------|---------|
| `search_results` | `list[RAGSearchResult]` | `[]` | `search()` |
| `upload_result` | `RAGUploadResult \| None` | `None` | `upload()`, `upload_markdown()` |
| `documents` | `dict[str, RAGDocument]` | `{}` | `get_document()` (key: `"collection/section_id"`) |
| `collections` | `list[RAGCollectionInfo]` | `[]` | `list_collections()` |
| `delete_collection_count` | `int` | `0` | `delete_collection()` |

When `upload_result` is `None`, `upload()` returns a default result with
`inserted` set to the number of sections passed.

`get_document()` and `delete_document()` raise `RAGNotFoundError` when the
key `"collection/section_id"` is not in the `documents` dict.

## Observability

The client emits OpenTelemetry spans and metrics for all operations:

**Spans:** Each operation creates a span named `rag.<operation>` with
attributes for collection, section ID, and HTTP status code.

**Metrics:**

| Metric | Type | Description |
|--------|------|-------------|
| `cwai.agent.rag.request.count` | Counter | Requests by operation and status |
| `cwai.agent.rag.request.duration` | Histogram | Request duration in ms |
| `cwai.agent.rag.error.count` | Counter | Errors by operation and type |
