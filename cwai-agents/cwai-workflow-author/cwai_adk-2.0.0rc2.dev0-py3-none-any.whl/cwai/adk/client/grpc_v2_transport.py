"""GrpcV2Transport: persistent multi-instance AgentRuntime transport.

Implements the V2 AgentRuntime gRPC protocol. Unlike V1 (one task per
process), V2 maintains a persistent connection with a control loop that
receives CREATE_AGENT / REMOVE_AGENT commands, and per-instance data
polling loops for agent messages.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any

import grpc
import grpc.aio
from opentelemetry import propagate

from cwai.adk._framework.transport import (
    LLMProxyInfo,
    PlatformMessage,
    TaskDispatch,
    TaskRemoval,
)
from cwai.adk._proto.agent.v2 import agent_pb2, agent_pb2_grpc
from cwai.adk.config import TLSConfig
from cwai.adk.errors import TransportClosed
from cwai.adk.observability.metrics import record_grpc_call
from cwai.adk.request_context import RequestContext
from cwai.adk.types import Message, MessageType, Result

logger = logging.getLogger("cwai.adk.client.grpc_v2_transport")

# Polling timeout for long-poll RPCs (server returns empty after this)
_POLL_TIMEOUT_MS = 30_000

# Client-side gRPC deadline for ReceiveControlMessage. Must be longer
# than the server-side long-poll timeout (_POLL_TIMEOUT_MS) to avoid
# false positives. If this fires, the TCP connection is likely dead and
# the control loop will retry with a fresh call. Without this, a
# silently broken connection hangs forever (CSCwu52058).
_CONTROL_POLL_DEADLINE_S = _POLL_TIMEOUT_MS // 1000 + 30  # 60s

# Retry backoff parameters (shared between recv_message and control loop)
_MAX_BACKOFF_S = 60
_MAX_RECV_RETRIES = 10


def _backoff_delay(attempt: int) -> float:
    """Exponential backoff capped at _MAX_BACKOFF_S."""
    return min(2 ** (attempt - 1), _MAX_BACKOFF_S)


def _recv_log_extra(agent_id: str, sender_id: int | None = None) -> dict[str, Any]:
    """Build receive log fields without implying a filter when none was set."""
    extra: dict[str, Any] = {"agent_id": agent_id}
    if sender_id is not None:
        extra["from_agent_id"] = sender_id
    return extra


# Map proto MessageType enum values to ADK MessageType
_PROTO_TO_ADK_MESSAGE_TYPE: dict[agent_pb2.MessageType, MessageType] = {
    agent_pb2.REQUEST: MessageType.REQUEST,
    agent_pb2.RESULT: MessageType.RESULT,
    agent_pb2.PARTIAL_RESULT: MessageType.PARTIAL_RESULT,
    agent_pb2.MORE_INFO: MessageType.MORE_INFO,
    agent_pb2.NOTIFICATION: MessageType.NOTIFICATION,
}

# Reverse map: ADK MessageType to proto enum
_ADK_TO_PROTO_MESSAGE_TYPE: dict[MessageType, agent_pb2.MessageType] = {
    v: k for k, v in _PROTO_TO_ADK_MESSAGE_TYPE.items()
}


@dataclass
class _InstanceState:
    """Internal state for a single agent instance."""

    agent_id: int
    thread_id: str = ""
    rbac_ctx: str = ""
    # Sender info from the first REQUEST, used as default reply target
    first_sender: str = ""
    first_sender_id: int = 0


@dataclass(frozen=True)
class _HandshakeResult:
    """Parsed handshake response."""

    settings: dict[str, Any] = field(default_factory=dict)
    llm_proxy_info: LLMProxyInfo | None = None


class GrpcV2Transport:
    """PlatformTransport backed by the V2 AgentRuntime gRPC protocol.

    Maintains a persistent connection, polls for control messages
    (CREATE_AGENT / REMOVE_AGENT), and runs per-instance data polling
    loops for agent messages.
    """

    def __init__(
        self,
        host: str,
        port: int,
        runtime_id: int,
        agent_name: str,
        *,
        tls_config: TLSConfig | None = None,
        _stm_override: Any = None,
        _channel_override: grpc.aio.Channel | None = None,
        _sync_channel_override: grpc.Channel | None = None,
        _disable_control_thread: bool = False,  # Testing only
    ) -> None:
        self._host = host
        self._port = port
        self._runtime_id = runtime_id
        self._agent_name = agent_name
        self._tls_config = tls_config or TLSConfig()
        self._stm_override = _stm_override
        self._channel_override = _channel_override
        self._sync_channel_override = _sync_channel_override
        self._disable_control_thread = _disable_control_thread

        self._channel: grpc.aio.Channel | None = None
        self._stub: agent_pb2_grpc.AgentRuntimeStub | None = None
        self._recv_queue: asyncio.Queue[PlatformMessage] = asyncio.Queue()
        # Accessed from both the control thread (writes in _handle_create_agent)
        # and the asyncio thread (reads in recv_message/send_result/etc.).
        # Safe on CPython due to GIL; revisit if targeting free-threaded Python.
        self._instances: dict[int, _InstanceState] = {}
        self._control_thread: threading.Thread | None = None
        self._control_channel: grpc.Channel | None = None
        self._close_event = threading.Event()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._closing = False
        self._handshake: _HandshakeResult | None = None

    @classmethod
    def from_env(cls) -> GrpcV2Transport:
        """Construct from standard V2 platform environment variables.

        Raises ValueError if FORESIGHT_RUNTIME_ID is missing.
        """
        runtime_id_str = os.environ.get("FORESIGHT_RUNTIME_ID", "")
        if not runtime_id_str:
            raise ValueError(
                "FORESIGHT_RUNTIME_ID not set. This is required for the V2 transport."
            )

        host = os.environ.get("FORESIGHT_SERVICE_HOST", "foresight")
        port = int(os.environ.get("FORESIGHT_GRPC_PORT", "50051"))
        agent_name = os.environ.get("FORESIGHT_AGENT_NAME", "")

        return cls(
            host=host,
            port=port,
            runtime_id=int(runtime_id_str),
            agent_name=agent_name,
            tls_config=TLSConfig.from_env(),
        )

    async def connect(self) -> None:
        """Open gRPC channel, perform handshake, start control polling."""
        address = f"{self._host}:{self._port}"

        if self._channel_override is not None:
            self._channel = self._channel_override
        else:
            creds = self._tls_config.load_grpc_credentials()
            self._channel = grpc.aio.secure_channel(
                address, creds, options=self._tls_config.grpc_channel_options()
            )

        self._stub = agent_pb2_grpc.AgentRuntimeStub(self._channel)

        # Perform handshake
        logger.info(
            "Performing V2 handshake",
            extra={"runtime_id": self._runtime_id, "address": address},
        )

        request = agent_pb2.AgentHandshakeRequest(runtime_id=self._runtime_id)
        t0 = time.monotonic()
        try:
            response = await self._stub.AgentHandshake(
                request, metadata=_otel_metadata()
            )
        except grpc.aio.AioRpcError as e:
            duration_ms = (time.monotonic() - t0) * 1000
            record_grpc_call(
                "AgentHandshake",
                duration_ms,
                success=False,
                grpc_code=e.code().name,
            )
            raise
        duration_ms = (time.monotonic() - t0) * 1000
        record_grpc_call(
            "AgentHandshake",
            duration_ms,
            success=not bool(response.error),
            grpc_code="OK" if not response.error else "application_error",
        )
        if response.error:
            raise RuntimeError(f"V2 handshake failed: {response.error}")

        self._handshake = _parse_handshake(response)

        logger.info(
            "V2 handshake complete",
            extra={"runtime_id": self._runtime_id},
        )

        # Start control polling loop in a dedicated thread so it remains
        # responsive even if the asyncio event loop is blocked by a handler.
        if not self._disable_control_thread:
            self._loop = asyncio.get_running_loop()
            self._control_thread = threading.Thread(
                target=self._control_loop_threaded,
                name="grpc-control-loop",
                daemon=True,
            )
            self._control_thread.start()

    def _metadata_for_instance(self, agent_id: int) -> tuple[tuple[str, str], ...]:
        """Build gRPC metadata with auth for the given instance."""
        instance = self._instances.get(agent_id)
        if not instance:
            return _otel_metadata()
        return RequestContext(
            agent_id=str(agent_id),
            thread_id=instance.thread_id,
            agent_type=self._agent_name,
            agent_instance_id=str(agent_id),
            auth_token=instance.rbac_ctx or None,
        ).get_grpc_metadata()

    async def recv(self) -> PlatformMessage:
        """Block until the next platform message."""
        if self._closing and self._recv_queue.empty():
            raise TransportClosed("Transport is closing")
        msg = await self._recv_queue.get()
        if isinstance(msg, _Sentinel):
            raise TransportClosed("Transport closed")
        return msg

    async def recv_message(
        self,
        agent_id: str,
        *,
        sender_id: int | None = None,
    ) -> Message:
        """On-demand fetch: issue a single ReceiveAgentMessage RPC.

        Blocks until a message is available on the server-side mailbox.
        This keeps messages in the server until the handler is ready.
        When provided, ``sender_id`` restricts delivery to that sender ID.
        """
        if self._closing:
            raise TransportClosed("Transport closed")
        int_agent_id = int(agent_id)
        consecutive_errors = 0
        max_error_retries = _MAX_RECV_RETRIES
        poll_attempts = 0
        t_start = time.monotonic()
        while not self._closing:
            if self._stub is None:
                raise RuntimeError("Transport closed")

            request = agent_pb2.ReceiveAgentMessageRequest(
                agent_name=self._agent_name,
                agent_id=int_agent_id,
                timeout_ms=_POLL_TIMEOUT_MS,
            )
            if sender_id is not None:
                request.from_agent_id = sender_id
            t0 = time.monotonic()
            try:
                response = await self._stub.ReceiveAgentMessage(
                    request, metadata=self._metadata_for_instance(int_agent_id)
                )
            except grpc.aio.AioRpcError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                record_grpc_call(
                    "ReceiveAgentMessage",
                    duration_ms,
                    success=False,
                    grpc_code=e.code().name,
                )
                if self._closing:
                    break
                consecutive_errors += 1
                if consecutive_errors >= max_error_retries:
                    raise RuntimeError(
                        f"recv_message RPC failed after {max_error_retries} "
                        f"consecutive errors: {e}"
                    ) from e
                backoff = _backoff_delay(consecutive_errors)
                log_extra = _recv_log_extra(agent_id, sender_id)
                log_extra.update(
                    {
                        "error": str(e),
                        "attempt": consecutive_errors,
                        "backoff_s": backoff,
                    }
                )
                logger.error(
                    "recv_message RPC error, retrying",
                    extra=log_extra,
                )
                await asyncio.sleep(backoff)
                continue

            if response.error:
                consecutive_errors += 1
                if consecutive_errors >= max_error_retries:
                    raise RuntimeError(
                        f"recv_message failed after {max_error_retries} "
                        f"consecutive errors: {response.error}"
                    )
                backoff = _backoff_delay(consecutive_errors)
                log_extra = _recv_log_extra(agent_id, sender_id)
                log_extra.update(
                    {
                        "error": response.error,
                        "attempt": consecutive_errors,
                        "backoff_s": backoff,
                    }
                )
                logger.warning(
                    "recv_message server returned error, retrying",
                    extra=log_extra,
                )
                await asyncio.sleep(backoff)
                continue

            proto_msg = response.data_message
            if not proto_msg or not proto_msg.id:
                # Empty response (server-side poll timeout), loop again
                poll_attempts += 1
                consecutive_errors = 0
                continue

            duration_ms = (time.monotonic() - t0) * 1000
            total_wait_ms = (time.monotonic() - t_start) * 1000
            record_grpc_call(
                "ReceiveAgentMessage",
                duration_ms,
                success=True,
                grpc_code="OK",
            )

            if poll_attempts > 0 or consecutive_errors > 0:
                log_extra = _recv_log_extra(agent_id, sender_id)
                log_extra.update(
                    {
                        "poll_attempts": poll_attempts,
                        "errors_encountered": consecutive_errors,
                        "total_wait_ms": round(total_wait_ms, 1),
                    }
                )
                logger.info(
                    "recv_message received after retries",
                    extra=log_extra,
                )

            # Extract OTEL context from message (not attached globally)
            parent_ctx = _extract_otel_context(proto_msg.observability_ctx)

            adk_msg = _proto_to_adk_message(proto_msg)
            adk_msg._otel_parent_ctx = parent_ctx

            # Capture sender info and thread_id from first REQUEST
            instance = self._instances.get(int_agent_id)
            if (
                instance is not None
                and not instance.first_sender
                and adk_msg.type == MessageType.REQUEST
            ):
                instance.first_sender = proto_msg.from_agent
                instance.first_sender_id = proto_msg.from_agent_id
                if not instance.thread_id and proto_msg.thread_id:
                    instance.thread_id = proto_msg.thread_id
                if not instance.rbac_ctx and proto_msg.rbac_ctx:
                    instance.rbac_ctx = proto_msg.rbac_ctx

            return adk_msg

        raise TransportClosed("Transport closing, no message available")

    def remember_message_sender(self, agent_id: str, msg: Message) -> None:
        """Record reply routing metadata from a replayed request message."""
        int_agent_id = int(agent_id)
        instance = self._instances.get(int_agent_id)
        if instance is None or msg.type != MessageType.REQUEST:
            return
        if not instance.first_sender:
            instance.first_sender = msg.sender
            instance.first_sender_id = msg.sender_id
        if not instance.thread_id and msg.thread_id:
            instance.thread_id = msg.thread_id

    async def send_result(
        self,
        agent_id: str,
        result: Result,
        *,
        final: bool = False,
        to_agent: str = "",
        to_agent_id: int = 0,
    ) -> None:
        """Send a result message to the platform."""
        int_agent_id = int(agent_id)
        instance = self._instances.get(int_agent_id)

        # Default reply target: sender of first REQUEST for this instance
        thread_id = ""
        rbac_ctx = ""
        if instance is not None:
            thread_id = instance.thread_id
            rbac_ctx = instance.rbac_ctx
            if not to_agent:
                to_agent = instance.first_sender
                to_agent_id = instance.first_sender_id

        msg_type = agent_pb2.RESULT if final else agent_pb2.PARTIAL_RESULT
        payload = _serialize_result(result)
        logger.info(
            "Sending result",
            extra={
                "agent_id": agent_id,
                "to_agent": to_agent,
                "to_agent_id": to_agent_id,
                "thread_id": thread_id,
                "result_status": result.status.value,
                "payload": payload,
            },
        )

        proto_msg = agent_pb2.Message(
            id=str(uuid.uuid4()),
            type=msg_type,
            from_agent=self._agent_name,
            from_agent_id=int_agent_id,
            to_agent=to_agent,
            to_agent_id=to_agent_id,
            user_message=payload,
            thread_id=thread_id,
            rbac_ctx=rbac_ctx,
        )

        await self._send_agent_message(proto_msg)

        if final:
            self._instances.pop(int_agent_id, None)

    async def send_message(
        self,
        agent: str,
        agent_id: int,
        *,
        user_message: str = "",
        system_message: str = "",
        type: MessageType = MessageType.REQUEST,
        reply_to: str = "",
        from_agent_id: int = 0,
    ) -> None:
        """Send a message to another agent instance."""
        # Get rbac_ctx and thread_id from the sending instance
        rbac_ctx = ""
        thread_id = ""
        instance = self._instances.get(from_agent_id)
        if instance is not None:
            rbac_ctx = instance.rbac_ctx
            thread_id = instance.thread_id

        logger.info(
            "Sending message",
            extra={
                "to_agent": agent,
                "to_agent_id": agent_id,
                "from_agent_id": from_agent_id,
                "type": type.value,
                "thread_id": thread_id,
                "instance_found": instance is not None,
                "instances_keys": list(self._instances.keys()),
            },
        )

        proto_msg = agent_pb2.Message(
            id=str(uuid.uuid4()),
            type=_ADK_TO_PROTO_MESSAGE_TYPE[type],
            from_agent=self._agent_name,
            from_agent_id=from_agent_id,
            to_agent=agent,
            to_agent_id=agent_id,
            user_message=user_message,
            system_message=system_message,
            reply_to=reply_to,
            rbac_ctx=rbac_ctx,
            thread_id=thread_id,
            observability_ctx=_serialize_otel_context(),
        )

        await self._send_agent_message(proto_msg)

    async def spawn_agent(
        self,
        agent_type: str,
        *,
        user_message: str = "",
        from_agent_id: int = 0,
        thread_id: str = "",
    ) -> int:
        """Create a new agent instance via the platform. Returns instance_id."""
        if self._stub is None:
            raise RuntimeError("Transport not connected")

        request = agent_pb2.CreateAgentRequest(
            name=agent_type,
            parent_id=from_agent_id,
            thread_id=thread_id,
        )

        t0 = time.monotonic()
        try:
            response = await self._stub.CreateAgent(
                request, metadata=self._metadata_for_instance(from_agent_id)
            )
        except grpc.aio.AioRpcError as e:
            duration_ms = (time.monotonic() - t0) * 1000
            record_grpc_call(
                "CreateAgent", duration_ms, success=False, grpc_code=e.code().name
            )
            raise
        duration_ms = (time.monotonic() - t0) * 1000
        record_grpc_call(
            "CreateAgent",
            duration_ms,
            success=not bool(response.error),
            grpc_code="OK" if not response.error else "application_error",
        )
        if response.error:
            raise RuntimeError(f"CreateAgent failed: {response.error}")

        instance_id = response.instance_id

        # Send initial message if provided
        if user_message:
            # Get rbac_ctx from the sending instance
            rbac_ctx = ""
            instance = self._instances.get(from_agent_id)
            if instance is not None:
                rbac_ctx = instance.rbac_ctx

            proto_msg = agent_pb2.Message(
                id=str(uuid.uuid4()),
                type=agent_pb2.REQUEST,
                from_agent=self._agent_name,
                from_agent_id=from_agent_id,
                to_agent=agent_type,
                to_agent_id=instance_id,
                user_message=user_message,
                rbac_ctx=rbac_ctx,
                thread_id=thread_id,
                observability_ctx=_serialize_otel_context(),
            )
            await self._send_agent_message(proto_msg)

        return instance_id

    async def remove_instance(self, agent_name: str, agent_id: str) -> None:
        """Tell the platform to remove this agent instance."""
        if self._stub is None:
            raise RuntimeError("Transport not connected")

        request = agent_pb2.RemoveAgentRequest(
            name=agent_name,
            instance_id=int(agent_id),
        )

        t0 = time.monotonic()
        try:
            response = await self._stub.RemoveAgent(
                request, metadata=self._metadata_for_instance(int(agent_id))
            )
        except grpc.aio.AioRpcError as e:
            duration_ms = (time.monotonic() - t0) * 1000
            record_grpc_call(
                "RemoveAgent", duration_ms, success=False, grpc_code=e.code().name
            )
            logger.warning(
                "RemoveAgent RPC failed",
                extra={"agent_name": agent_name, "agent_id": agent_id, "error": str(e)},
            )
            return
        duration_ms = (time.monotonic() - t0) * 1000
        record_grpc_call(
            "RemoveAgent",
            duration_ms,
            success=not bool(response.error),
            grpc_code="OK" if not response.error else "application_error",
        )
        if response.error:
            logger.warning(
                "RemoveAgent failed",
                extra={
                    "agent_name": agent_name,
                    "agent_id": agent_id,
                    "error": response.error,
                },
            )

    async def send_fail(self, agent_id: str, error: str) -> None:
        """Send an error result to the platform."""
        int_agent_id = int(agent_id)
        instance = self._instances.get(int_agent_id)

        to_agent = ""
        to_agent_id = 0
        thread_id = ""
        rbac_ctx = ""
        if instance is not None:
            to_agent = instance.first_sender
            to_agent_id = instance.first_sender_id
            thread_id = instance.thread_id
            rbac_ctx = instance.rbac_ctx

        error_payload = json.dumps(
            {
                "status": "error",
                "message": {"content": error, "type": "text"},
            }
        )

        proto_msg = agent_pb2.Message(
            id=str(uuid.uuid4()),
            type=agent_pb2.RESULT,
            from_agent=self._agent_name,
            from_agent_id=int_agent_id,
            to_agent=to_agent,
            to_agent_id=to_agent_id,
            user_message=error_payload,
            thread_id=thread_id,
            rbac_ctx=rbac_ctx,
        )

        await self._send_agent_message(proto_msg)

        # Task is done, clean up instance state to prevent memory leak
        self._instances.pop(int_agent_id, None)

    async def close(self) -> None:
        """Stop all polling loops and close the gRPC channel."""
        self._closing = True
        self._close_event.set()

        # Close control channel to unblock the thread's RPC call
        if self._control_channel is not None:
            self._control_channel.close()

        # Wait for control thread to exit
        if self._control_thread is not None and self._control_thread.is_alive():
            self._control_thread.join(timeout=5)
            if self._control_thread.is_alive():
                logger.warning("Control thread did not exit within 5s")

        # Signal any blocked recv() calls
        await self._recv_queue.put(_Sentinel())  # type: ignore[arg-type]

        if self._channel is not None:
            await self._channel.close()
            self._channel = None
            self._stub = None

    # -- Internal loops ---------------------------------------------------

    def _control_loop_threaded(self) -> None:
        """Poll for control messages in a dedicated thread.

        Uses a synchronous gRPC channel so the control loop remains
        responsive even if the main asyncio event loop is blocked.
        """
        address = f"{self._host}:{self._port}"
        if self._sync_channel_override is not None:
            channel = self._sync_channel_override
        else:
            creds = self._tls_config.load_grpc_credentials()
            channel = grpc.secure_channel(
                address, creds, options=self._tls_config.grpc_channel_options()
            )
        self._control_channel = channel
        stub = agent_pb2_grpc.AgentRuntimeStub(channel)

        logger.info(
            "Control loop thread started",
            extra={"runtime_id": self._runtime_id, "address": address},
        )

        try:
            consecutive_errors = 0
            while not self._closing:
                t0 = time.monotonic()
                try:
                    request = agent_pb2.ReceiveControlMessageRequest(
                        runtime_id=self._runtime_id,
                        timeout_ms=_POLL_TIMEOUT_MS,
                    )
                    response = stub.ReceiveControlMessage(
                        request,
                        metadata=_otel_metadata(),
                        timeout=_CONTROL_POLL_DEADLINE_S,
                    )

                    if response.error:
                        consecutive_errors += 1
                        backoff = _backoff_delay(consecutive_errors)
                        logger.debug(
                            "Control poll returned error, retrying",
                            extra={
                                "error": response.error,
                                "attempt": consecutive_errors,
                                "backoff_s": backoff,
                            },
                        )
                        self._close_event.wait(backoff)
                        continue

                    ctrl = response.control_message
                    if not ctrl.ByteSize():
                        # Empty response (server timeout), loop again
                        consecutive_errors = 0
                        continue

                    # Record metric for non-empty deliveries only
                    duration_ms = (time.monotonic() - t0) * 1000
                    record_grpc_call(
                        "ReceiveControlMessage",
                        duration_ms,
                        success=True,
                        grpc_code="OK",
                    )
                    consecutive_errors = 0

                    if ctrl.type == agent_pb2.CREATE_AGENT:
                        self._handle_create_agent(ctrl)
                    elif ctrl.type == agent_pb2.REMOVE_AGENT:
                        self._handle_remove_agent(ctrl)

                except grpc.RpcError as e:
                    if self._closing:
                        break
                    consecutive_errors += 1
                    duration_ms = (time.monotonic() - t0) * 1000
                    record_grpc_call(
                        "ReceiveControlMessage",
                        duration_ms,
                        success=False,
                        grpc_code=e.code().name,  # type: ignore[attr-defined]
                    )
                    backoff = _backoff_delay(consecutive_errors)
                    logger.error(
                        "Control loop RPC error, retrying",
                        extra={
                            "error": str(e),
                            "attempt": consecutive_errors,
                            "backoff_s": backoff,
                        },
                    )
                    self._close_event.wait(backoff)
                except Exception as e:
                    if self._closing:
                        break
                    consecutive_errors += 1
                    backoff = _backoff_delay(consecutive_errors)
                    logger.error(
                        "Control loop unexpected error, retrying",
                        extra={
                            "error": str(e),
                            "attempt": consecutive_errors,
                            "backoff_s": backoff,
                        },
                    )
                    self._close_event.wait(backoff)
        finally:
            channel.close()
            logger.info("Control loop thread exiting")

    def _handle_create_agent(self, ctrl: Any) -> None:
        """Process a CREATE_AGENT control message."""
        agent_id = ctrl.agent_id

        # Reject duplicate CREATE_AGENT for the same agent_id
        if agent_id in self._instances:
            logger.warning(
                "Duplicate CREATE_AGENT received, ignoring",
                extra={"agent_id": agent_id, "thread_id": ctrl.thread_id},
            )
            return

        logger.info(
            "CREATE_AGENT received",
            extra={
                "agent_id": agent_id,
                "thread_id": ctrl.thread_id,
                "rbac_ctx_present": bool(ctrl.rbac_ctx),
            },
        )

        instance = _InstanceState(
            agent_id=agent_id,
            thread_id=ctrl.thread_id,
            rbac_ctx=ctrl.rbac_ctx,
        )
        self._instances[agent_id] = instance

        # Build dispatch with handshake settings
        hs = self._handshake or _HandshakeResult()
        dispatch = TaskDispatch(
            agent_id=str(agent_id),
            thread_id=ctrl.thread_id,
            agent_type=self._agent_name,
            agent_instance_id=str(agent_id),
            settings=hs.settings,
            auth_token=instance.rbac_ctx or None,
            llm_proxy_info=hs.llm_proxy_info,
            ca_cert_path=self._tls_config.ca_cert_path,
            _stm_override=self._stm_override,
        )

        if self._loop is None:
            logger.error("Event loop not set, cannot dispatch CREATE_AGENT")
            return
        self._loop.call_soon_threadsafe(self._recv_queue.put_nowait, dispatch)

    def _handle_remove_agent(self, ctrl: Any) -> None:
        """Process a REMOVE_AGENT control message."""
        agent_id = ctrl.agent_id

        logger.info(
            "REMOVE_AGENT received",
            extra={"agent_id": agent_id},
        )

        if self._loop is None:
            logger.error("Event loop not set, cannot dispatch REMOVE_AGENT")
            return
        self._loop.call_soon_threadsafe(
            self._recv_queue.put_nowait, TaskRemoval(agent_id=str(agent_id))
        )

    async def _send_agent_message(self, proto_msg: Any) -> None:
        """Send a message via SendAgentMessage RPC."""
        if self._stub is None:
            raise RuntimeError("Transport not connected")

        request = agent_pb2.SendAgentMessageRequest(message=proto_msg)
        t0 = time.monotonic()
        try:
            response = await self._stub.SendAgentMessage(
                request, metadata=self._metadata_for_instance(proto_msg.from_agent_id)
            )
        except grpc.aio.AioRpcError as e:
            duration_ms = (time.monotonic() - t0) * 1000
            record_grpc_call(
                "SendAgentMessage",
                duration_ms,
                success=False,
                grpc_code=e.code().name,
            )
            raise
        duration_ms = (time.monotonic() - t0) * 1000
        record_grpc_call(
            "SendAgentMessage",
            duration_ms,
            success=not bool(response.error),
            grpc_code="OK" if not response.error else "application_error",
        )
        if response.error:
            raise RuntimeError(f"SendAgentMessage failed: {response.error}")


class _Sentinel:
    """Sentinel value to signal transport shutdown in the recv queue."""


# -- Helper functions -----------------------------------------------------


def _otel_metadata() -> tuple[tuple[str, str], ...]:
    """Inject current OTEL context into gRPC metadata."""
    carrier: dict[str, str] = {}
    propagate.inject(carrier)
    return tuple((k.lower(), v) for k, v in carrier.items())


def _extract_otel_context(observability_ctx: str) -> Any:
    """Extract OTEL context from observability_ctx field without attaching globally.

    Returns an OpenTelemetry Context or None.
    """
    if not observability_ctx:
        return None
    try:
        carrier = json.loads(observability_ctx)
        if isinstance(carrier, dict):
            return propagate.extract(carrier=carrier)
    except (json.JSONDecodeError, TypeError):
        logger.debug("Failed to parse observability_ctx")
    return None


def _serialize_otel_context() -> str:
    """Serialize current OTEL context to JSON string for message observability_ctx."""
    carrier: dict[str, str] = {}
    propagate.inject(carrier)
    return json.dumps(carrier) if carrier else ""


def _proto_to_adk_message(proto_msg: Any) -> Message:
    """Convert a proto Message to an ADK Message."""
    msg_type = _PROTO_TO_ADK_MESSAGE_TYPE.get(proto_msg.type, MessageType.REQUEST)

    # Attempt JSON decode of user_message into query (default to empty dict)
    query: dict[str, Any] = {}
    if proto_msg.user_message:
        try:
            parsed = json.loads(proto_msg.user_message)
            if isinstance(parsed, dict):
                query = parsed
        except (json.JSONDecodeError, TypeError):
            pass

    return Message(
        type=msg_type,
        sender=proto_msg.from_agent,
        sender_id=proto_msg.from_agent_id,
        user_message=proto_msg.user_message,
        system_message=proto_msg.system_message,
        query=query,
        id=proto_msg.id,
        reply_to=proto_msg.reply_to,
        thread_id=proto_msg.thread_id,
    )


def _serialize_result(result: Result) -> str:
    """Serialize a Result to JSON string for the user_message field."""
    payload: dict[str, Any] = {"status": result.status.value}
    if result.message is not None:
        payload["message"] = asdict(result.message)
    if result.data is not None:
        payload["data"] = result.data
    return json.dumps(payload)


def _parse_handshake(response: Any) -> _HandshakeResult:
    """Parse AgentHandshakeResponse into settings and LLM proxy info."""
    settings: dict[str, Any] = {}
    if response.settings:
        try:
            parsed = json.loads(response.settings)
            if isinstance(parsed, dict):
                settings = parsed
        except (json.JSONDecodeError, UnicodeDecodeError):
            logger.warning("Failed to parse handshake settings")

    llm_proxy_info: LLMProxyInfo | None = None
    if response.llm_proxy_info:
        try:
            info = json.loads(response.llm_proxy_info)
            base_url = info.get("base_url", "")
            virtual_key = info.get("virtual_key", "")
            if base_url and virtual_key:
                models_raw = info.get("models", [])
                models = [m for m in models_raw if isinstance(m, str)]
                llm_proxy_info = LLMProxyInfo(
                    base_url=base_url,
                    virtual_key=virtual_key,
                    models=models,
                )
                logger.info(
                    "Parsed LLM proxy info",
                    extra={"base_url": base_url, "models": models},
                )
        except (json.JSONDecodeError, UnicodeDecodeError):
            logger.warning("Failed to parse llm_proxy_info")

    return _HandshakeResult(
        settings=settings,
        llm_proxy_info=llm_proxy_info,
    )
