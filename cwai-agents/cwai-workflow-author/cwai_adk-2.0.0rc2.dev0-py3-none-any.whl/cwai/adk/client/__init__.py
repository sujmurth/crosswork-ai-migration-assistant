"""Client interfaces and implementations for Crosswork AI platform services.

Protocols and concrete client classes live in their respective impl
modules (``cwai.adk.client.llm``, ``cwai.adk.client.kg``, etc.). This
package re-exports them for backwards compatibility and convenience.
"""

from cwai.adk.client.agents import (
    AgentCatalogClient,
    AgentCatalogClientProtocol,
    AgentInstance,
    AgentsClientProtocol,
    AgentType,
    AgentTypeInfo,
)
from cwai.adk.client.dra import (
    DRAClient,
    DRAClientProtocol,
    DRAResponse,
)
from cwai.adk.client.kg import (
    KGClient,
    KnowledgeGraphClientProtocol,
)
from cwai.adk.client.llm import (
    LLMClient,
    LLMClientProtocol,
    LLMResponse,
    LLMResponseProtocol,
    LLMStreamEvent,
)
from cwai.adk.client.mcp import (
    McpClient,
    McpClientProtocol,
)
from cwai.adk.client.rag import (
    RAGClient,
    RAGClientProtocol,
)
from cwai.adk.client.stm import (
    STMClient,
    STMClientProtocol,
)
from cwai.adk.client.tools import (
    ToolsClient,
    ToolsClientProtocol,
)

__all__ = [
    # agents
    "AgentCatalogClient",
    "AgentCatalogClientProtocol",
    "AgentInstance",
    "AgentsClientProtocol",
    "AgentType",
    "AgentTypeInfo",
    # dra
    "DRAClient",
    "DRAClientProtocol",
    "DRAResponse",
    # kg
    "KGClient",
    "KnowledgeGraphClientProtocol",
    # llm
    "LLMClient",
    "LLMClientProtocol",
    "LLMResponse",
    "LLMResponseProtocol",
    "LLMStreamEvent",
    # mcp
    "McpClient",
    "McpClientProtocol",
    # rag
    "RAGClient",
    "RAGClientProtocol",
    # stm
    "STMClient",
    "STMClientProtocol",
    # tools
    "ToolsClient",
    "ToolsClientProtocol",
]
