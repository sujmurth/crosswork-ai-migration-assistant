"""Agent Catalog client for discovering agent types.

Provides async methods for listing agent types available on Crosswork AI.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol

import grpc
import grpc.aio
from google.protobuf.json_format import MessageToDict

from cwai.adk._proto.agent.v2 import agent_pb2, agent_pb2_grpc
from cwai.adk.errors import AgentCatalogConnectionError
from cwai.adk.request_context import RequestContext

if TYPE_CHECKING:
    from cwai.adk.config import TLSConfig

# Safety-net timeout for agent catalog operations. See ADR-0023.
DEFAULT_TIMEOUT: float = 300.0
"""Default request timeout, in seconds."""

DEFAULT_GRPC_PORT = 50051
"""Default Agent Catalog service gRPC port."""

_default_logger = logging.getLogger("cwai.adk.client.agents")


class AgentInstance(Protocol):
    """Handle to a running or completed agent instance."""

    instance_id: str
    """Unique identifier for this agent instance."""
    agent_type: str
    """Agent type name for this instance."""
    status: str
    """Current instance status."""

    async def send_message(
        self,
        content: str,
        format: str = "text",
        tag: str = "",
    ) -> None:
        """Sends a message to the agent instance."""
        ...

    async def get_result(self) -> dict[str, Any]:
        """Returns the final result for the agent instance."""
        ...


class AgentType(Protocol):
    """Agent type from the catalog."""

    name: str
    """Unique agent identifier, such as config-drift."""

    full_name: str
    """Human-readable name, such as Config Drift Detection Agent."""

    type: str
    """Agent category, such as BUILTIN or CUSTOM."""

    description: str
    """Description of what the agent does."""

    version: str
    """Agent version string."""

    capabilities: list[str]
    """List of agent capabilities, such as config-drift, llm, or dra."""

    metadata: dict[str, Any]
    """Additional metadata about the agent, such as tags or resource limits."""

    source: str
    """Source of the agent type, such as Cisco CWAI."""

    tags: list[str]
    """List of tags for filtering and discovery, such as network or security."""

    status: str
    """Status of the agent type, such as ACTIVE or INACTIVE."""


@dataclass(frozen=True)
class AgentTypeInfo:
    """Agent type information returned by catalog discovery."""

    name: str
    """Unique agent identifier, such as config-drift."""

    full_name: str
    """Human-readable name, such as Config Drift Detection Agent."""

    type: str
    """Agent category, such as BUILTIN or CUSTOM."""

    description: str
    """Description of what the agent does."""

    version: str
    """Agent version string."""

    capabilities: list[str]
    """List of agent capabilities, such as config-drift, llm, or dra."""

    metadata: dict[str, Any]
    """Additional metadata about the agent, such as tags or resource limits."""

    tags: list[str]
    """List of tags for filtering and discovery, such as network or security."""

    source: str
    """Source of the agent type, such as Cisco CWAI."""

    status: str
    """Status of the agent type, such as ACTIVE or INACTIVE."""


class AgentCatalogClientProtocol(Protocol):
    """Protocol for Agent Catalog client implementations.

    The Agent Catalog provides discovery of available agent types
    registered with the Crosswork AI platform.
    """

    async def list_types(self, *, timeout: float = ...) -> list[AgentTypeInfo]:
        """Lists available agent types from the catalog.

        Args:
            timeout: Request timeout in seconds. If omitted, the client default is used.

        Returns:
            Registered agent types.

        Raises:
            AgentCatalogConnectionError: The catalog request failed.
        """
        ...

    async def close(self) -> None:
        """Closes the client and releases resources."""
        ...


class AgentsClientProtocol(Protocol):
    """Protocol for agent catalog and instance management."""

    async def list_types(self) -> list[AgentType]:
        """Lists available agent types from the catalog."""
        ...

    async def list_instances(
        self, agent_type: str | None = None
    ) -> list[AgentInstance]:
        """Lists running agent instances, optionally filtered by type."""
        ...

    async def get_instance(self, instance_id: str) -> AgentInstance:
        """Gets a specific agent instance by ID."""
        ...

    def get_parent(self) -> AgentInstance | None:
        """Gets the parent agent instance, if any."""
        ...


class AgentCatalogClient:
    """Async client for Crosswork AI agent catalog discovery.

    Args:
        host: Agent Catalog service host name.
        port: Agent Catalog service gRPC port.
        request_context: Optional context for trace propagation and task identity headers.
        tls_config: Optional TLS configuration for gRPC certificate handling.
        timeout: Default request timeout in seconds. Per-request timeouts override this value.
        log: Optional logger for task-scoped logging.

    Examples:
        client = AgentCatalogClient("foresight")
        agents = await client.list_types()
        for agent in agents:
            print(f"{agent.name}: {agent.description}")
    """

    def __init__(
        self,
        host: str,
        request_context: RequestContext | None = None,
        *,
        port: int = DEFAULT_GRPC_PORT,
        tls_config: TLSConfig | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        log: logging.Logger | logging.LoggerAdapter[Any] | None = None,
        _channel: grpc.aio.Channel | None = None,
        _stub: Any | None = None,
    ) -> None:
        self._host = host
        self._port = port
        self._request_context = request_context
        self._timeout = timeout
        self._tls_config = tls_config
        self._log = log or _default_logger
        self._channel = _channel
        self._stub = _stub
        self._owns_channel = _channel is None and _stub is None

    def _metadata(self) -> tuple[tuple[str, str], ...]:
        """Build gRPC metadata with auth context."""
        if self._request_context is None:
            return ()
        return self._request_context.get_grpc_metadata()

    def _ensure_stub(self) -> Any:
        """Creates the gRPC stub when first needed."""
        if self._stub is not None:
            return self._stub

        if self._channel is None:
            tls_config = self._tls_config
            if tls_config is None:
                from cwai.adk.config import TLSConfig

                tls_config = TLSConfig.from_env()
            address = f"{self._host}:{self._port}"
            creds = tls_config.load_grpc_credentials()
            self._channel = grpc.aio.secure_channel(
                address,
                creds,
                options=tls_config.grpc_channel_options(),
            )

        self._stub = agent_pb2_grpc.AgentCatalogStub(self._channel)
        return self._stub

    async def list_types(self, *, timeout: float | None = None) -> list[AgentTypeInfo]:
        """Lists available agent types from the platform catalog.

        Args:
            timeout: Request timeout in seconds. If omitted, the client default is used.

        Returns:
            Registered agent types.

        Raises:
            AgentCatalogConnectionError: The catalog request failed.

        Examples:
            agents = await ctx.agents.list_types()
            llm_agents = [a for a in agents if "llm-proxy" in a.capabilities]
        """
        self._log.info("Listing agent types")

        try:
            stub = self._ensure_stub()
            response = await stub.ListAgents(
                agent_pb2.ListAgentsRequest(),
                metadata=self._metadata(),
                timeout=timeout if timeout is not None else self._timeout,
            )
        except (OSError, ValueError, grpc.aio.AioRpcError) as e:
            err_msg = f"Agent catalog request failed: {e}"
            self._log.error("Agent catalog request failed", extra={"error": str(e)})
            raise AgentCatalogConnectionError(err_msg) from e

        agents = [self._parse_agent(a) for a in response.agents]

        self._log.info("Listed agent types", extra={"count": len(agents)})
        return agents

    def _parse_agent(self, data: agent_pb2.Agent) -> AgentTypeInfo:
        """Parse agent data from gRPC response into AgentTypeInfo."""
        metadata = MessageToDict(data.metadata) if data.HasField("metadata") else {}
        return AgentTypeInfo(
            name=data.name,
            full_name=data.full_name,
            type=data.type,
            description=data.description,
            version=data.version,
            capabilities=list(data.capabilities),
            metadata=metadata,
            tags=list(data.tags),
            source=data.source,
            status=data.status,
        )

    async def close(self) -> None:
        """Close the underlying gRPC channel if this client created it."""
        if self._owns_channel and self._channel is not None:
            await self._channel.close()
