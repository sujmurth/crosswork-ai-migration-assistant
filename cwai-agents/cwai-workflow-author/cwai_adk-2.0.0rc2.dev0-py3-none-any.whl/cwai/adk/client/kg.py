"""Knowledge Graph (KG) client for GraphQL queries.

Calls the Knowledge Graph service GraphQL endpoint.
"""

from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING, Any, Protocol

import httpx
from opentelemetry import trace

from cwai.adk.errors import KGConnectionError, KGError, KGQueryError
from cwai.adk.observability.metrics import record_kg_error, record_kg_request
from cwai.adk.request_context import RequestContext
from cwai.adk.tools import Tool

if TYPE_CHECKING:
    from cwai.adk.config import TLSConfig

# Safety-net timeout for KG operations. Long enough to accommodate slow queries
# while preventing indefinite hangs. See ADR-0023.
DEFAULT_TIMEOUT: float = 300.0
"""Default request timeout, in seconds."""

_default_logger = logging.getLogger("cwai.adk.client.kg")
tracer = trace.get_tracer("cwai.adk.client.kg")
"""OpenTelemetry tracer used for Knowledge Graph client spans."""


class KnowledgeGraphClientProtocol(Protocol):
    """Protocol for Knowledge Graph client implementations.

    The KG service provides a GraphQL API for querying network topology,
    device state, and relationships. The schema is dynamic: DRAs can
    register new entity types at runtime.
    """

    async def query(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        *,
        timeout: float = ...,
    ) -> dict[str, Any]:
        """Execute a GraphQL query or mutation.

        Args:
            query: GraphQL query or mutation string.
            variables: Optional query variables.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            The 'data' field from the GraphQL response.

        Raises:
            KGQueryError: On GraphQL errors.
            KGConnectionError: On transport failures (including timeout).
        """
        ...

    async def get_schema(self, *, timeout: float = ...) -> str:
        """Retrieve the GraphQL SDL schema.

        The schema is useful for programmatic field discovery and when
        agents need exact field names for DRA extension types. For LLM
        context, prefer ``get_skill()`` which is smaller and includes
        usage examples.

        Args:
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            GraphQL schema in SDL format.

        Raises:
            KGConnectionError: On transport failures (including timeout).
        """
        ...

    async def get_skill(self, *, timeout: float = ...) -> str:
        """Retrieve the KG skill document.

        The skill document is a concise, LLM-readable reference that covers
        entity types, query patterns, filter operators, and temporal queries.
        **For LLM-assisted query construction, use this document** instead of
        ``get_schema()`` because:

        - Smaller and more focused than the full SDL schema
        - Includes usage examples and filter operator semantics
        - Stable across DRA extension registrations

        Args:
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            Skill document in Markdown format.

        Raises:
            KGConnectionError: On transport failures (including timeout).
        """
        ...

    @property
    def tools(self) -> list[Tool]:
        """LLM tools for Knowledge Graph operations.

        Returns a list of Tool objects that can be passed to ToolExecutor
        for LLM-driven KG queries.

        Returns:
            List containing kg_query, kg_get_skill, and kg_get_schema tools.
        """
        ...


class KGClient:
    """Async client for the Knowledge Graph GraphQL API.

    Args:
        base_url: KG service base URL (such as "https://knowledgegraph:8443").
        request_context: Optional context for OpenTelemetry trace propagation and task identity headers.
        tls_config: Optional TLS configuration for certificate verification.
        http_client: Optional httpx.AsyncClient for testing (DI).
        timeout: Default timeout in seconds for requests. Per-request timeout
            can override this. Defaults to DEFAULT_TIMEOUT (300s).
        log: Optional logger for task-scoped logging.
    """

    def __init__(
        self,
        base_url: str,
        request_context: RequestContext | None = None,
        *,
        tls_config: TLSConfig | None = None,
        http_client: httpx.AsyncClient | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        log: logging.Logger | logging.LoggerAdapter | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._request_context = request_context
        self._timeout = timeout
        self._log = log or _default_logger

        if http_client is not None:
            self._client = http_client
        elif tls_config is not None:
            self._client = httpx.AsyncClient(verify=tls_config.httpx_verify())
        else:
            self._client = httpx.AsyncClient()

    def _build_headers(self) -> dict[str, str]:
        """Build request headers with OTEL context, auth token, and source."""
        headers: dict[str, str] = {}
        if self._request_context:
            headers.update(self._request_context.get_headers())
            # X-Source identifies the agent for KG lineage tracking. The KG
            # uses this to record who wrote data on mutations. Harmless on
            # queries (ignored), so we send it unconditionally.
            if self._request_context.agent_type:
                headers["X-Source"] = self._request_context.agent_type
        return headers

    async def query(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Execute a GraphQL query or mutation.

        Args:
            query: GraphQL query or mutation string.
            variables: Optional query variables.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            The 'data' field from the GraphQL response.

        Raises:
            KGQueryError: On GraphQL errors.
            KGConnectionError: On transport failures (including timeout).

        Examples:
            result = await ctx.kg.query(
                '''
                query GetNodes($limit: Int!) {
                    queryNode(first: $limit) { nodeId name }
                }
                ''',
                variables={"limit": 10},
                timeout=30.0,
            )
            nodes = result["queryNode"]
        """
        with tracer.start_as_current_span("kg.query") as span:
            body: dict[str, Any] = {"query": query}
            if variables:
                body["variables"] = variables

            self._log.info("KG query started")
            self._log.debug(
                "KG query request", extra={"query": query, "variables": variables}
            )

            t0 = time.monotonic()
            try:
                resp = await self._client.post(
                    f"{self._base_url}/api/v1/knowledge-graph/graphql",
                    json=body,
                    headers=self._build_headers(),
                    timeout=timeout if timeout is not None else self._timeout,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err_msg = f"KG request failed: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("KG request failed", extra={"error": str(e)})
                record_kg_request("query", duration_ms, success=False)
                record_kg_error("query", "connection_error")
                raise KGConnectionError(err_msg) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("http.status_code", resp.status_code)

            if resp.status_code != 200:
                err_msg = f"KG request failed: HTTP {resp.status_code}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error(
                    "KG request failed",
                    extra={"status_code": resp.status_code},
                )
                record_kg_request("query", duration_ms, success=False)
                record_kg_error("query", "connection_error")
                raise KGConnectionError(err_msg)

            data = resp.json()

            if "errors" in data:
                errors = data["errors"]
                msg = "; ".join(e.get("message", str(e)) for e in errors)
                span.set_status(trace.StatusCode.ERROR, f"GraphQL errors: {msg}")
                self._log.warning("KG query errors", extra={"errors": errors})
                record_kg_request("query", duration_ms, success=False)
                record_kg_error("query", "query_error")
                raise KGQueryError(f"GraphQL errors: {msg}", errors)

            self._log.info("KG query completed", extra={"status": "success"})
            self._log.debug("KG query response", extra={"data": data.get("data", {})})
            record_kg_request("query", duration_ms, success=True)
            return data.get("data", {})

    async def get_schema(self, *, timeout: float | None = None) -> str:
        """Retrieve the GraphQL SDL schema.

        The schema is useful for programmatic field discovery and when
        agents need exact field names for DRA extension types. For LLM
        context, prefer ``get_skill()`` which is smaller and includes
        usage examples.

        Args:
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            GraphQL schema in SDL format.

        Raises:
            KGConnectionError: On transport failures (including timeout).

        Examples:
            schema = await ctx.kg.get_schema(timeout=10.0)
        """
        with tracer.start_as_current_span("kg.get_schema") as span:
            self._log.info("KG get_schema started")

            t0 = time.monotonic()
            try:
                resp = await self._client.get(
                    f"{self._base_url}/api/v1/knowledge-graph/schema/graphql",
                    headers=self._build_headers(),
                    timeout=timeout if timeout is not None else self._timeout,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err_msg = f"Schema request failed: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("KG schema request failed", extra={"error": str(e)})
                record_kg_request("get_schema", duration_ms, success=False)
                record_kg_error("get_schema", "connection_error")
                raise KGConnectionError(err_msg) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("http.status_code", resp.status_code)

            if resp.status_code != 200:
                err_msg = f"Schema request failed: HTTP {resp.status_code}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error(
                    "KG schema request failed",
                    extra={"status_code": resp.status_code},
                )
                record_kg_request("get_schema", duration_ms, success=False)
                record_kg_error("get_schema", "connection_error")
                raise KGConnectionError(err_msg)

            schema = resp.text
            self._log.info("KG get_schema completed", extra={"status": "success"})
            self._log.debug("KG schema response", extra={"schema": schema})
            record_kg_request("get_schema", duration_ms, success=True)
            return schema

    async def get_skill(self, *, timeout: float | None = None) -> str:
        """Retrieve the KG skill document.

        The skill document is a concise, LLM-readable reference that covers
        entity types, query patterns, filter operators, and temporal queries.
        **For LLM-assisted query construction, use this document** instead of
        ``get_schema()`` because:

        - Smaller and more focused than the full SDL schema
        - Includes usage examples and filter operator semantics
        - Stable across DRA extension registrations

        Args:
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            Skill document in Markdown format.

        Raises:
            KGConnectionError: On transport failures (including timeout).

        Examples:
            skill = await ctx.kg.get_skill(timeout=10.0)
            # Pass skill doc to LLM for query construction
            response = await ctx.llm.complete([
                {"role": "system", "content": f"You query the KG.\\n\\n{skill}"},
                {"role": "user", "content": user_question},
            ])
        """
        with tracer.start_as_current_span("kg.get_skill") as span:
            self._log.info("KG get_skill started")

            t0 = time.monotonic()
            try:
                resp = await self._client.get(
                    f"{self._base_url}/api/v1/knowledge-graph/SKILL.md",
                    headers=self._build_headers(),
                    timeout=timeout if timeout is not None else self._timeout,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err_msg = f"Skill request failed: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("KG skill request failed", extra={"error": str(e)})
                record_kg_request("get_skill", duration_ms, success=False)
                record_kg_error("get_skill", "connection_error")
                raise KGConnectionError(err_msg) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("http.status_code", resp.status_code)

            if resp.status_code != 200:
                err_msg = f"Skill request failed: HTTP {resp.status_code}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error(
                    "KG skill request failed",
                    extra={"status_code": resp.status_code},
                )
                record_kg_request("get_skill", duration_ms, success=False)
                record_kg_error("get_skill", "connection_error")
                raise KGConnectionError(err_msg)

            skill = resp.text
            self._log.info("KG get_skill completed", extra={"status": "success"})
            self._log.debug("KG skill response", extra={"skill_length": len(skill)})
            record_kg_request("get_skill", duration_ms, success=True)
            return skill

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    @property
    def tools(self) -> list[Tool]:
        """LLM tools for Knowledge Graph operations.

        Returns a list of Tool objects that can be passed to ToolExecutor
        for LLM-driven KG queries.

        Returns:
            List containing kg_query, kg_get_skill, and kg_get_schema tools.

        Examples:
            from cwai.adk import ToolExecutor

            executor = ToolExecutor(ctx.kg.tools)
            response = await ctx.llm.complete(
                messages=messages,
                tools=executor.schemas,
            )
        """
        return [
            Tool(
                name="kg_query",
                description=(
                    "Execute a GraphQL query against the Knowledge Graph. "
                    "The KG contains network topology, devices, interfaces, "
                    "and relationships. Use kg_get_skill first to learn the "
                    "query syntax and available entity types."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "GraphQL query string",
                        },
                        "variables": {
                            "type": "object",
                            "description": "Optional GraphQL query variables",
                        },
                    },
                    "required": ["query"],
                },
                execute=self._tool_query,
            ),
            Tool(
                name="kg_get_skill",
                description=(
                    "Get the Knowledge Graph skill document describing "
                    "available entity types, query patterns, and filter "
                    "operators. Call this before writing KG queries to "
                    "learn the correct syntax."
                ),
                parameters={"type": "object", "properties": {}},
                execute=self._tool_get_skill,
            ),
            Tool(
                name="kg_get_schema",
                description=(
                    "Get the full Knowledge Graph GraphQL SDL schema for "
                    "exact type and field discovery. This can return a large "
                    "payload, often tens of KB or more; use kg_get_skill first "
                    "for LLM query construction unless exact schema details "
                    "are needed."
                ),
                parameters={"type": "object", "properties": {}},
                execute=self._tool_get_schema,
            ),
        ]

    async def _tool_query(
        self, query: str, variables: dict[str, Any] | None = None
    ) -> str:
        """Execute kg_query tool, returning JSON result or error."""
        try:
            result = await self.query(query, variables)
            return json.dumps(result)
        except KGError as e:
            return json.dumps({"error": str(e)})

    async def _tool_get_skill(self) -> str:
        """Execute kg_get_skill tool, returning skill content or error."""
        try:
            return await self.get_skill()
        except KGError as e:
            return json.dumps({"error": str(e)})

    async def _tool_get_schema(self) -> str:
        """Execute kg_get_schema tool, returning schema content or error."""
        try:
            return await self.get_schema()
        except KGError as e:
            return json.dumps({"error": str(e)})
