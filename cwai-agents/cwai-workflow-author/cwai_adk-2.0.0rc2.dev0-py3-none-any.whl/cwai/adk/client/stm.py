"""STM gRPC client implementation.

Provides async access to the STM service for persisting agent task state.
Includes retry logic for transient errors and error translation to typed exceptions.
"""

import asyncio
import logging
import time
from datetime import UTC, datetime, timedelta
from typing import Protocol

import grpc
import grpc.aio
from google.rpc import status_pb2
from opentelemetry import trace

from cwai.adk._framework._compression import compress, decompress
from cwai.adk._proto.stm.v1 import stm_pb2, stm_pb2_grpc
from cwai.adk.config import TLSConfig
from cwai.adk.errors import (
    STMAlreadyExistsError,
    STMConnectionError,
    STMDeletedError,
    STMError,
    STMMaxEntriesError,
    STMNotFoundError,
    STMPayloadTooLargeError,
    STMSizeExceededError,
    STMTTLOutOfRangeError,
)
from cwai.adk.observability.metrics import (
    record_stm_entries_retrieved,
    record_stm_operation,
    record_stm_payload_size,
    record_stm_retry,
)
from cwai.adk.request_context import RequestContext
from cwai.adk.types.stm import StateEntity, StateEntry, STMStatus

_default_logger = logging.getLogger("cwai.adk.client.stm")
tracer = trace.get_tracer("cwai.adk.client.stm")
"""Tracer used for STM client spans."""

# Safety-net timeout for STM operations. Applied per-retry attempt.
# See ADR-0023.
DEFAULT_TIMEOUT: float = 300.0
"""Default request timeout, in seconds."""

# Retry configuration for transient errors
_MAX_RETRIES = 3
_RETRY_DELAYS = [0.1, 0.2, 0.4]  # Exponential backoff: 100ms, 200ms, 400ms

# gRPC status codes that should trigger retry
_RETRYABLE_CODES = {
    grpc.StatusCode.UNAVAILABLE,
    grpc.StatusCode.INTERNAL,
    grpc.StatusCode.UNKNOWN,
}


class STMClientProtocol(Protocol):
    """Protocol for STM (Short-Term Memory) client.

    The STM service provides persistent state storage for agent tasks,
    enabling crash recovery and observability.
    """

    async def connect(self) -> None:
        """Open connection to STM service.

        Raises:
            STMConnectionError: If connection fails.
        """
        ...

    async def close(self) -> None:
        """Close connection to STM service."""
        ...

    async def create(
        self, stm_key: str, *, ttl: float | None = ..., timeout: float = ...
    ) -> datetime:
        """Create a new STM.

        Args:
            stm_key: Unique identifier for the STM.
            ttl: Optional time-to-live in seconds. If > 0, sets expiry to
                now + ttl (must be within server's MaxTTL). If 0 or None,
                no per-key expiry is set (server's default cleanup applies).
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            Timestamp when the STM was created.

        Raises:
            STMConnectionError: If client is not connected.
            STMAlreadyExistsError: If STM with this key already exists.
            STMTTLOutOfRangeError: If TTL is invalid or exceeds server limit.
            STMError: On other failures (including timeout).
        """
        ...

    async def add(
        self,
        stm_key: str,
        payload: bytes,
        *,
        ttl: float | None = ...,
        timeout: float = ...,
    ) -> tuple[str, int]:
        """Append a state entry to an existing STM.

        Args:
            stm_key: Identifier of the STM to append to.
            payload: State data to store (max 1MB).
            ttl: Optional TTL update in seconds. If > 0, resets expiry to
                now + ttl (must be within server's MaxTTL). If 0 or None,
                expiry is left unchanged.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            Entry ID and sequence number for the new entry.

        Raises:
            STMConnectionError: If client is not connected.
            STMNotFoundError: If STM does not exist.
            STMDeletedError: If STM has been deleted.
            STMPayloadTooLargeError: If payload exceeds 1MB.
            STMSizeExceededError: If total STM size would exceed 100MB.
            STMMaxEntriesError: If STM has reached 10,000 entries.
            STMTTLOutOfRangeError: If TTL is invalid or exceeds server limit.
            STMError: On other failures (including timeout).
        """
        ...

    async def get(self, stm_key: str, *, timeout: float = ...) -> StateEntity | None:
        """Retrieve all entries from an STM.

        Args:
            stm_key: Identifier of the STM to retrieve.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            State entity with all entries, or None if the STM is not found.

        Raises:
            STMConnectionError: If client is not connected.
            STMError: On failures other than not found (including timeout).
        """
        ...

    async def delete(self, stm_key: str, *, timeout: float = ...) -> datetime:
        """Mark an STM as deleted.

        Args:
            stm_key: Identifier of the STM to delete.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            Timestamp when the STM was marked as deleted.

        Raises:
            STMConnectionError: If client is not connected.
            STMNotFoundError: If STM does not exist.
            STMError: On other failures (including timeout).
        """
        ...

    async def extend_lifespan(
        self, stm_key: str, ttl: float, *, timeout: float = ...
    ) -> datetime:
        """Extend an STM's expiry to now + ttl.

        Useful for long-running tasks (for example, paused on human input) that need
        to keep their STM alive beyond the original TTL.

        Args:
            stm_key: Identifier of the STM.
            ttl: New time-to-live in seconds from now. Must be > 0 and
                within server's MaxTTL.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            The new expiry timestamp.

        Raises:
            STMConnectionError: If client is not connected.
            STMNotFoundError: If STM does not exist.
            STMTTLOutOfRangeError: If TTL is invalid or exceeds server limit.
            STMError: On other failures (including timeout).
        """
        ...


class STMClient:
    """Async gRPC client for the STM service.

    Manages its own gRPC channel and propagates trace context and identity
    headers via RequestContext.

    Args:
        stm_url: STM service address (such as "stm:50051").
        request_context: Optional context for OTEL trace propagation and
            app-level identity headers.
        timeout: Default timeout in seconds for requests (per-retry).
            Defaults to DEFAULT_TIMEOUT (300s).
        log: Optional logger for task-scoped logging.
        tls_config: TLS configuration. When set to None, the client creates
            one from environment variables by using ``TLSConfig.from_env()``.

    Examples:
        async with STMClient("stm:50051", request_context) as client:
            await client.create("my-key", ttl=3600.0)
            await client.add("my-key", b"some data")
            entity = await client.get("my-key")
            await client.extend_lifespan("my-key", 7200.0)

        # With explicit TLS configuration
        from cwai.adk.config import TLSConfig
        config = TLSConfig(
            ca_cert_path="/path/to/ca.crt",
            client_cert_path="/path/to/tls.crt",
            client_key_path="/path/to/tls.key",
        )
        async with STMClient("stm:50051", tls_config=config) as client:
            await client.create("my-key")

        # Connecting via IP with hostname override for SSL verification
        config = TLSConfig(
            ca_cert_path="/path/to/ca.crt",
            client_cert_path="/path/to/tls.crt",
            client_key_path="/path/to/tls.key",
            ssl_target_name_override="stm",
        )
        async with STMClient("10.0.0.1:30051", tls_config=config) as client:
            await client.create("my-key")
    """

    def __init__(
        self,
        stm_url: str,
        request_context: RequestContext | None = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        log: logging.Logger | logging.LoggerAdapter | None = None,
        tls_config: TLSConfig | None = None,
        _channel_override: grpc.aio.Channel | None = None,
    ) -> None:
        self._stm_url = stm_url
        self._request_context = request_context
        self._timeout = timeout
        self._log = log or _default_logger
        self._channel: grpc.aio.Channel | None = None
        self._stub: stm_pb2_grpc.STMServiceStub | None = None
        self._channel_override = _channel_override

        self._tls_config = tls_config or TLSConfig.from_env()

    def _build_metadata(self) -> tuple[tuple[str, str], ...] | None:
        """Build gRPC metadata with trace context and identity."""
        if self._request_context is None:
            return None
        return self._request_context.get_grpc_metadata()

    async def connect(self) -> None:
        """Open the gRPC channel to the STM service.

        Uses mTLS with certificates from ``TLSConfig``. Certificate
        paths default to standard K8s mount locations.

        Raises:
            STMConnectionError: If connection fails or certificates cannot be loaded.
        """
        with tracer.start_as_current_span("stm.connect") as span:
            span.set_attribute("stm.url", self._stm_url)
            self._log.info(
                "Connecting to STM service",
                extra={"stm_url": self._stm_url},
            )
            try:
                if self._channel_override is not None:
                    self._channel = self._channel_override
                else:
                    creds = self._tls_config.load_grpc_credentials()
                    self._channel = grpc.aio.secure_channel(
                        self._stm_url,
                        creds,
                        options=self._tls_config.grpc_channel_options(),
                    )
                self._stub = stm_pb2_grpc.STMServiceStub(self._channel)
            except FileNotFoundError as e:
                err_msg = f"Failed to load TLS certificates: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error(
                    "STM connection failed - certificate not found",
                    extra={"error": str(e)},
                )
                raise STMConnectionError(err_msg) from e
            except Exception as e:
                err_msg = f"Failed to create STM channel: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("STM connection failed", extra={"error": str(e)})
                raise STMConnectionError(err_msg) from e

    async def close(self) -> None:
        """Close the gRPC channel."""
        if self._channel:
            self._log.debug("Closing STM connection")
            await self._channel.close()
            self._channel = None
            self._stub = None

    async def __aenter__(self) -> "STMClient":
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        await self.close()

    async def create(
        self, stm_key: str, *, ttl: float | None = None, timeout: float | None = None
    ) -> datetime:
        """Create a new STM.

        Args:
            stm_key: Unique identifier for the STM.
            ttl: Optional time-to-live in seconds. If > 0, sets expiry to
                now + ttl (must be within server's MaxTTL). If 0 or None,
                no per-key expiry is set (server's default cleanup applies).
            timeout: Request timeout in seconds (per-retry). Defaults to
                client timeout.

        Returns:
            Timestamp when the STM was created.

        Raises:
            STMConnectionError: If client is not connected.
            STMAlreadyExistsError: If STM with this key already exists.
            STMTTLOutOfRangeError: If TTL is invalid or exceeds server limit.
            STMError: On other failures (including timeout).
        """
        if not self._stub:
            raise STMConnectionError("Client not connected. Call connect() first.")

        if ttl is not None:
            _validate_ttl(ttl)

        request = stm_pb2.CreateSTMRequest(
            stm_key=stm_key,
            ttl=_optional_ttl_duration(ttl),
        )
        effective_timeout = timeout if timeout is not None else self._timeout

        with tracer.start_as_current_span("stm.create") as span:
            span.set_attribute("stm.key", stm_key)
            if ttl is not None:
                span.set_attribute("stm.ttl_seconds", ttl)
            start_time = time.perf_counter()

            try:
                response = await self._call_with_retry(
                    "create", self._stub.Create, request, effective_timeout
                )
                duration_ms = (time.perf_counter() - start_time) * 1000
                record_stm_operation("create", duration_ms, success=True)

                created_at = _timestamp_to_datetime(response.created_at)
                self._log.debug(
                    "STM created", extra={"stm_key": stm_key, "created_at": created_at}
                )
                return created_at

            except grpc.aio.AioRpcError as e:
                duration_ms = (time.perf_counter() - start_time) * 1000
                error_code = self._error_code_name(_extract_error_code(e))
                record_stm_operation(
                    "create", duration_ms, success=False, error_code=error_code
                )
                self._handle_grpc_error(e, "create", stm_key, span)
                raise  # pragma: no cover - _handle_grpc_error always raises

    async def add(
        self,
        stm_key: str,
        payload: bytes,
        *,
        ttl: float | None = None,
        timeout: float | None = None,
    ) -> tuple[str, int]:
        """Append a state entry to an existing STM.

        Args:
            stm_key: Identifier of the STM to append to.
            payload: State data to store (max 1MB).
            ttl: Optional TTL update in seconds. If > 0, resets expiry to
                now + ttl (must be within server's MaxTTL). If 0 or None,
                expiry is left unchanged.
            timeout: Request timeout in seconds (per-retry). Defaults to
                client timeout.

        Returns:
            Entry ID and sequence number for the new entry.

        Raises:
            STMConnectionError: If client is not connected.
            STMNotFoundError: If STM does not exist.
            STMDeletedError: If STM has been deleted.
            STMPayloadTooLargeError: If payload exceeds 1MB.
            STMSizeExceededError: If total STM size would exceed 100MB.
            STMMaxEntriesError: If STM has reached 10,000 entries.
            STMTTLOutOfRangeError: If TTL is invalid or exceeds server limit.
            STMError: On other failures (including timeout).
        """
        if not self._stub:
            raise STMConnectionError("Client not connected. Call connect() first.")

        if ttl is not None:
            _validate_ttl(ttl)

        request = stm_pb2.AddStateRequest(
            stm_key=stm_key,
            payload=compress(payload),
            ttl=_optional_ttl_duration(ttl),
        )
        effective_timeout = timeout if timeout is not None else self._timeout

        with tracer.start_as_current_span("stm.add") as span:
            span.set_attribute("stm.key", stm_key)
            span.set_attribute("stm.payload_size", len(payload))
            if ttl is not None:
                span.set_attribute("stm.ttl_seconds", ttl)
            start_time = time.perf_counter()

            try:
                response = await self._call_with_retry(
                    "add", self._stub.Add, request, effective_timeout
                )
                duration_ms = (time.perf_counter() - start_time) * 1000
                record_stm_operation("add", duration_ms, success=True)
                record_stm_payload_size(len(payload))

                self._log.debug(
                    "STM entry added",
                    extra={
                        "stm_key": stm_key,
                        "entry_id": response.entry_id,
                        "sequence_number": response.sequence_number,
                    },
                )
                return response.entry_id, response.sequence_number

            except grpc.aio.AioRpcError as e:
                duration_ms = (time.perf_counter() - start_time) * 1000
                error_code = self._error_code_name(_extract_error_code(e))
                record_stm_operation(
                    "add", duration_ms, success=False, error_code=error_code
                )
                self._handle_grpc_error(e, "add", stm_key, span)
                raise  # pragma: no cover - _handle_grpc_error always raises

    async def get(
        self, stm_key: str, *, timeout: float | None = None
    ) -> StateEntity | None:
        """Retrieve all entries from an STM.

        Args:
            stm_key: Identifier of the STM to retrieve.
            timeout: Request timeout in seconds (per-retry). Defaults to
                client timeout.

        Returns:
            State entity with all entries, or None if the STM is not found.

        Raises:
            STMConnectionError: If client is not connected.
            STMError: On failures other than not found (including timeout).
        """
        if not self._stub:
            raise STMConnectionError("Client not connected. Call connect() first.")

        request = stm_pb2.GetSTMRequest(stm_key=stm_key)
        effective_timeout = timeout if timeout is not None else self._timeout

        with tracer.start_as_current_span("stm.get") as span:
            span.set_attribute("stm.key", stm_key)
            start_time = time.perf_counter()

            try:
                entity = await self._consume_get_stream_with_retry(
                    request, effective_timeout
                )
                duration_ms = (time.perf_counter() - start_time) * 1000

                record_stm_operation("get", duration_ms, success=True)
                record_stm_entries_retrieved(len(entity.entries))

                span.set_attribute("stm.entry_count", len(entity.entries))
                self._log.debug(
                    "STM retrieved",
                    extra={"stm_key": stm_key, "entry_count": len(entity.entries)},
                )
                return entity

            except grpc.aio.AioRpcError as e:
                duration_ms = (time.perf_counter() - start_time) * 1000
                # NOT_FOUND is not an error for get — return None
                error_code = _extract_error_code(e)
                if error_code == stm_pb2.STM_ERROR_NOT_FOUND:
                    # Record as success with 0 entries (not found is expected),
                    # but tag with error_code="not_found" so dashboards can
                    # distinguish hit vs. miss.
                    record_stm_operation(
                        "get", duration_ms, success=True, error_code="not_found"
                    )
                    record_stm_entries_retrieved(0)
                    self._log.debug("STM not found", extra={"stm_key": stm_key})
                    return None
                error_code_name = self._error_code_name(error_code)
                record_stm_operation(
                    "get", duration_ms, success=False, error_code=error_code_name
                )
                self._handle_grpc_error(e, "get", stm_key, span)

    async def _consume_get_stream_with_retry(
        self, request, timeout: float
    ) -> StateEntity:
        """Open and fully consume a GetStream call, retrying transient failures.

        Each attempt rebuilds the entity from scratch, so retrying the whole
        read is safe (it is an idempotent read). A retryable error mid-stream
        therefore discards any partial state and restarts.
        """
        last_error: grpc.aio.AioRpcError | None = None
        metadata = self._build_metadata()

        for attempt in range(_MAX_RETRIES):
            try:
                return await self._consume_get_stream(request, metadata, timeout)
            except grpc.aio.AioRpcError as e:
                if e.code() not in _RETRYABLE_CODES:
                    raise

                last_error = e
                if attempt < _MAX_RETRIES - 1:
                    delay = _RETRY_DELAYS[attempt]
                    grpc_code = e.code().name
                    record_stm_retry("get", grpc_code)
                    self._log.warning(
                        "STM call failed, retrying",
                        extra={
                            "method": "get",
                            "attempt": attempt + 1,
                            "max_retries": _MAX_RETRIES,
                            "retry_delay": delay,
                            "grpc_code": grpc_code,
                        },
                    )
                    await asyncio.sleep(delay)

        assert last_error is not None
        raise last_error

    async def _consume_get_stream(
        self, request, metadata, timeout: float
    ) -> StateEntity:
        """Single attempt: iterate the stream and reassemble a StateEntity."""
        assert self._stub is not None
        call = self._stub.GetStream(request, metadata=metadata, timeout=timeout)

        header: stm_pb2.GetStreamHeader | None = None
        entries: list[StateEntry] = []
        async for resp in call:
            kind = resp.WhichOneof("payload")
            if kind == "header":
                header = resp.header
            elif kind == "entry":
                e = resp.entry
                entries.append(
                    StateEntry(
                        entry_id=e.entry_id,
                        sequence_number=e.sequence_number,
                        timestamp=_timestamp_to_datetime(e.timestamp),
                        payload=decompress(e.payload),
                    )
                )

        if header is None:
            raise STMError("GetStream completed without a header frame")
        return _header_to_state_entity(header, entries)

    async def delete(self, stm_key: str, *, timeout: float | None = None) -> datetime:
        """Mark an STM as deleted.

        Args:
            stm_key: Identifier of the STM to delete.
            timeout: Request timeout in seconds (per-retry). Defaults to
                client timeout.

        Returns:
            Timestamp when the STM was marked as deleted.

        Raises:
            STMConnectionError: If client is not connected.
            STMNotFoundError: If STM does not exist.
            STMError: On other failures (including timeout).
        """
        if not self._stub:
            raise STMConnectionError("Client not connected. Call connect() first.")

        request = stm_pb2.DeleteSTMRequest(stm_key=stm_key)
        effective_timeout = timeout if timeout is not None else self._timeout

        with tracer.start_as_current_span("stm.delete") as span:
            span.set_attribute("stm.key", stm_key)
            start_time = time.perf_counter()

            try:
                response = await self._call_with_retry(
                    "delete", self._stub.Delete, request, effective_timeout
                )
                duration_ms = (time.perf_counter() - start_time) * 1000
                record_stm_operation("delete", duration_ms, success=True)

                deleted_at = _timestamp_to_datetime(response.deleted_at)
                self._log.debug(
                    "STM deleted", extra={"stm_key": stm_key, "deleted_at": deleted_at}
                )
                return deleted_at

            except grpc.aio.AioRpcError as e:
                duration_ms = (time.perf_counter() - start_time) * 1000
                error_code = self._error_code_name(_extract_error_code(e))
                record_stm_operation(
                    "delete", duration_ms, success=False, error_code=error_code
                )
                self._handle_grpc_error(e, "delete", stm_key, span)
                raise  # pragma: no cover - _handle_grpc_error always raises

    async def extend_lifespan(
        self, stm_key: str, ttl: float, *, timeout: float | None = None
    ) -> datetime:
        """Extend an STM's expiry to now + ttl.

        Useful for long-running tasks (for example, paused on human input) that need
        to keep their STM alive beyond the original TTL.

        Args:
            stm_key: Identifier of the STM.
            ttl: New time-to-live in seconds from now. Must be > 0 and
                within server's MaxTTL.
            timeout: Request timeout in seconds (per-retry). Defaults to
                client timeout.

        Returns:
            The new expiry timestamp.

        Raises:
            STMConnectionError: If client is not connected.
            STMNotFoundError: If STM does not exist.
            STMTTLOutOfRangeError: If TTL is invalid or exceeds server limit.
            STMError: On other failures (including timeout).
        """
        if not self._stub:
            raise STMConnectionError("Client not connected. Call connect() first.")

        # Unlike create/add where ttl=0 means "unset" (proto3 zero-value),
        # extend_lifespan requires a positive value (see ADR-0036).
        if ttl <= 0:
            raise ValueError(f"ttl must be > 0 for extend_lifespan, got {ttl}")

        request = stm_pb2.ExtendLifespanRequest(
            stm_key=stm_key,
            ttl=_seconds_to_duration(ttl),
        )
        effective_timeout = timeout if timeout is not None else self._timeout

        with tracer.start_as_current_span("stm.extend_lifespan") as span:
            span.set_attribute("stm.key", stm_key)
            span.set_attribute("stm.ttl_seconds", ttl)
            start_time = time.perf_counter()

            try:
                response = await self._call_with_retry(
                    "extend_lifespan",
                    self._stub.ExtendLifespan,
                    request,
                    effective_timeout,
                )
                duration_ms = (time.perf_counter() - start_time) * 1000
                record_stm_operation("extend_lifespan", duration_ms, success=True)

                expires_at = _timestamp_to_datetime(response.expires_at)
                self._log.debug(
                    "STM lifespan extended",
                    extra={"stm_key": stm_key, "expires_at": expires_at},
                )
                return expires_at

            except grpc.aio.AioRpcError as e:
                duration_ms = (time.perf_counter() - start_time) * 1000
                error_code = self._error_code_name(_extract_error_code(e))
                record_stm_operation(
                    "extend_lifespan",
                    duration_ms,
                    success=False,
                    error_code=error_code,
                )
                self._handle_grpc_error(e, "extend_lifespan", stm_key, span)
                raise  # pragma: no cover - _handle_grpc_error always raises

    async def _call_with_retry(self, method_name: str, method, request, timeout: float):
        """Call a gRPC method with exponential backoff retry for transient errors.

        The timeout is applied per-retry attempt, not as a total timeout.
        """
        last_error: grpc.aio.AioRpcError | None = None
        metadata = self._build_metadata()

        for attempt in range(_MAX_RETRIES):
            try:
                return await method(request, metadata=metadata, timeout=timeout)
            except grpc.aio.AioRpcError as e:
                if e.code() not in _RETRYABLE_CODES:
                    raise

                last_error = e
                if attempt < _MAX_RETRIES - 1:
                    delay = _RETRY_DELAYS[attempt]
                    grpc_code = e.code().name
                    record_stm_retry(method_name, grpc_code)
                    self._log.warning(
                        "STM call failed, retrying",
                        extra={
                            "method": method_name,
                            "attempt": attempt + 1,
                            "max_retries": _MAX_RETRIES,
                            "retry_delay": delay,
                            "grpc_code": grpc_code,
                        },
                    )
                    await asyncio.sleep(delay)

        # Exhausted retries - last_error is guaranteed to be set here
        # since we only reach this point after catching at least one error
        assert last_error is not None
        raise last_error

    def _handle_grpc_error(
        self,
        error: grpc.aio.AioRpcError,
        operation: str,
        stm_key: str,
        span: trace.Span,
    ) -> None:
        """Translate gRPC errors to typed STM exceptions."""
        error_code = _extract_error_code(error)
        error_detail = _extract_error_detail(error)

        msg = f"STM {operation} failed for key '{stm_key}': {error.details()}"
        span.set_status(trace.StatusCode.ERROR, msg)

        self._log.error(
            "STM %s failed",
            operation,
            extra={
                "stm_key": stm_key,
                "grpc_code": error.code().name,
                "error_code": error_code,
            },
        )

        if error_code == stm_pb2.STM_ERROR_NOT_FOUND:
            raise STMNotFoundError(msg) from error
        elif error_code == stm_pb2.STM_ERROR_ALREADY_EXISTS:
            raise STMAlreadyExistsError(msg) from error
        elif error_code == stm_pb2.STM_ERROR_DELETED:
            raise STMDeletedError(msg) from error
        elif error_code == stm_pb2.STM_ERROR_PAYLOAD_TOO_LARGE:
            raise STMPayloadTooLargeError(
                msg,
                current_size=error_detail.current_size if error_detail else 0,
                max_size=error_detail.max_size if error_detail else 0,
            ) from error
        elif error_code == stm_pb2.STM_ERROR_STM_SIZE_EXCEEDED:
            raise STMSizeExceededError(
                msg,
                current_size=error_detail.current_size if error_detail else 0,
                max_size=error_detail.max_size if error_detail else 0,
            ) from error
        elif error_code == stm_pb2.STM_ERROR_MAX_ENTRIES_EXCEEDED:
            raise STMMaxEntriesError(
                msg,
                current_count=error_detail.current_count if error_detail else 0,
                max_count=error_detail.max_count if error_detail else 0,
            ) from error
        elif error_code == stm_pb2.STM_ERROR_TTL_OUT_OF_RANGE:
            raise STMTTLOutOfRangeError(msg) from error
        else:
            raise STMError(msg) from error

    @staticmethod
    def _error_code_name(error_code: int) -> str:
        """Convert STM error code to a human-readable name for metrics."""
        code_names: dict[int, str] = {
            stm_pb2.STM_ERROR_CODE_UNSPECIFIED: "unspecified",
            stm_pb2.STM_ERROR_NOT_FOUND: "not_found",
            stm_pb2.STM_ERROR_ALREADY_EXISTS: "already_exists",
            stm_pb2.STM_ERROR_DELETED: "deleted",
            stm_pb2.STM_ERROR_PAYLOAD_TOO_LARGE: "payload_too_large",
            stm_pb2.STM_ERROR_STM_SIZE_EXCEEDED: "size_exceeded",
            stm_pb2.STM_ERROR_MAX_ENTRIES_EXCEEDED: "max_entries_exceeded",
            stm_pb2.STM_ERROR_TTL_OUT_OF_RANGE: "ttl_out_of_range",
        }
        return code_names.get(error_code, "unknown")


def _extract_error_code(error: grpc.aio.AioRpcError) -> int:
    """Extract STMErrorCode from gRPC error details.

    The STM service uses standard gRPC rich error details (google.rpc.Status)
    with STMErrorDetail packed as an Any message.
    """
    for key, value in error.trailing_metadata() or []:
        if key == "grpc-status-details-bin":
            try:
                st = status_pb2.Status()
                if isinstance(value, bytes):
                    st.ParseFromString(value)
                else:
                    st.ParseFromString(value.encode())

                for any_detail in st.details:
                    if any_detail.Is(stm_pb2.STMErrorDetail.DESCRIPTOR):
                        error_detail = stm_pb2.STMErrorDetail()
                        any_detail.Unpack(error_detail)
                        return error_detail.code
            except Exception:
                pass
    return stm_pb2.STM_ERROR_CODE_UNSPECIFIED


def _extract_error_detail(error: grpc.aio.AioRpcError) -> stm_pb2.STMErrorDetail | None:
    """Extract full STMErrorDetail from gRPC error details.

    The STM service uses standard gRPC rich error details (google.rpc.Status)
    with STMErrorDetail packed as an Any message.
    """
    for key, value in error.trailing_metadata() or []:
        if key == "grpc-status-details-bin":
            try:
                st = status_pb2.Status()
                if isinstance(value, bytes):
                    st.ParseFromString(value)
                else:
                    st.ParseFromString(value.encode())

                for any_detail in st.details:
                    if any_detail.Is(stm_pb2.STMErrorDetail.DESCRIPTOR):
                        error_detail = stm_pb2.STMErrorDetail()
                        any_detail.Unpack(error_detail)
                        return error_detail
            except Exception:
                pass
    return None


def _timestamp_to_datetime(ts) -> datetime:
    """Convert protobuf Timestamp to Python datetime."""
    return datetime.fromtimestamp(ts.seconds + ts.nanos / 1e9, tz=UTC)


def _validate_ttl(ttl: float) -> None:
    """Raise ValueError if TTL is negative."""
    if ttl < 0:
        raise ValueError(f"ttl must be >= 0, got {ttl}")


def _optional_ttl_duration(ttl: float | None) -> timedelta | None:
    """Convert optional TTL to Duration, treating 0 as unset (proto3 semantics).

    In proto3, a Duration with seconds=0 nanos=0 is the zero value and
    indistinguishable from "field not set". The STM server treats this as
    "no TTL requested", so we skip it entirely when ttl is 0 or None.
    """
    if ttl is None or ttl == 0:
        return None
    return timedelta(seconds=ttl)


def _seconds_to_duration(seconds: float) -> timedelta:
    """Convert float seconds to timedelta for protobuf Duration fields.

    protobuf-python accepts timedelta directly for google.protobuf.Duration
    fields, converting to the wire format (seconds + nanos) automatically.
    """
    return timedelta(seconds=seconds)


def _header_to_state_entity(
    header: stm_pb2.GetStreamHeader, entries: list[StateEntry]
) -> StateEntity:
    """Build a StateEntity from a GetStream header plus already-parsed entries."""
    is_deleted = header.status == stm_pb2.STM_STATUS_DELETED
    status = STMStatus.DELETED if is_deleted else STMStatus.OPEN

    deleted_at = None
    if header.HasField("deleted_at"):
        deleted_at = _timestamp_to_datetime(header.deleted_at)

    expires_at = None
    if header.HasField("expires_at"):
        expires_at = _timestamp_to_datetime(header.expires_at)

    return StateEntity(
        stm_key=header.stm_key,
        status=status,
        created_at=_timestamp_to_datetime(header.created_at),
        last_updated_at=_timestamp_to_datetime(header.last_updated_at),
        deleted_at=deleted_at,
        entries=entries,
        expires_at=expires_at,
    )
