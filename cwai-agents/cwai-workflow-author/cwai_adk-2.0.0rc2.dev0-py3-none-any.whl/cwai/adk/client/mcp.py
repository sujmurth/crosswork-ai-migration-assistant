"""Model Context Protocol (MCP) client for JSON-RPC 2.0 over Streamable HTTP.

Provides transport and session handling for MCP communication. Domain
clients, such as ToolsClient, use McpClient for protocol operations and
add caching, type mapping, and domain-specific behavior.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from importlib.metadata import version as _pkg_version
from typing import TYPE_CHECKING, Any, Protocol

import httpx
from opentelemetry import trace

from cwai.adk.errors import ToolsConnectionError, ToolsError
from cwai.adk.observability._labels import _resolve_agent_type
from cwai.adk.observability.metrics import record_tools_error, record_tools_request
from cwai.adk.request_context import RequestContext

if TYPE_CHECKING:
    from cwai.adk.config import TLSConfig

# MCP protocol version we advertise during initialization.
# This targets the Tool Catalog's supported version (2025-06-18), not the
# latest spec (2025-11-25). Version negotiation handles mismatches — the
# server returns its preferred version and we store it for subsequent headers.
_PROTOCOL_VERSION = "2025-06-18"

# Safety-net timeout for MCP operations. See ADR-0023.
DEFAULT_TIMEOUT: float = 300.0
"""Default request timeout, in seconds."""


_default_logger = logging.getLogger("cwai.adk.client.mcp")


def _adk_version() -> str:
    """Resolve cwai-adk version lazily to avoid circular import via cwai.adk."""
    try:
        return _pkg_version("cwai-adk")
    except Exception:
        return "0.0.0"


tracer = trace.get_tracer("cwai.adk.client.mcp")
"""OpenTelemetry tracer used for MCP client spans."""


class McpClientProtocol(Protocol):
    """Protocol defining the MCP client interface.

    High-level MCP operations matching the ``mcp`` library's ClientSession
    API shape. This enables swapping implementations (raw httpx vs mcp
    library) without touching domain clients.
    """

    async def list_tools(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]: ...

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]: ...

    async def list_prompts(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]: ...

    async def get_prompt(
        self,
        name: str,
        arguments: dict[str, str] | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]: ...

    async def list_resources(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]: ...

    async def read_resource(
        self, uri: str, *, timeout: float | None = None
    ) -> dict[str, Any]: ...

    async def list_resource_templates(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]: ...

    def get_server_capabilities(self) -> dict[str, Any] | None: ...

    async def close(self) -> None: ...


class McpClient:
    """Uses JSON-RPC 2.0 over MCP Streamable HTTP. Handles session management,
    protocol negotiation, and automatic reinitialization when a session expires
    with HTTP 404.

    Args:
        base_url: MCP server URL, such as "https://tools:8443/mcp".
        request_context: Optional context for OpenTelemetry trace propagation and authentication headers.
        tls_config: Optional TLS configuration for certificate verification.
        http_client: Optional httpx.AsyncClient for testing (DI).
        timeout: Default timeout in seconds. Defaults to DEFAULT_TIMEOUT (300s).
        log: Optional logger for task-scoped logging.

    Examples:
        client = McpClient("https://tools:8443/mcp")
        tools = await client.list_tools()
        result = await client.call_tool("get_status", {"device": "router1"})
        await client.close()
    """

    def __init__(
        self,
        base_url: str,
        request_context: RequestContext | None = None,
        *,
        tls_config: TLSConfig | None = None,
        http_client: httpx.AsyncClient | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        log: logging.Logger | logging.LoggerAdapter | None = None,
    ) -> None:
        self._url = base_url.rstrip("/")
        self._request_context = request_context
        self._timeout = timeout
        self._log = log or _default_logger

        if http_client is not None:
            self._client = http_client
        elif tls_config is not None:
            self._client = httpx.AsyncClient(verify=tls_config.httpx_verify())
        else:
            self._client = httpx.AsyncClient()

        # MCP session state
        self._session_id: str | None = None
        self._protocol_version: str | None = None
        self._initialized: bool = False
        self._request_id: int = 0
        # Tracks the current in-flight request for cancellation on close().
        # Safe because ToolsClient is scoped to a single agent context
        # and not called concurrently from multiple tasks.
        self._inflight_request_id: int | None = None
        self._server_capabilities: dict[str, Any] | None = None
        self._closed: bool = False

    @property
    def session_id(self) -> str | None:
        """Current MCP session ID. Returns None if the client has not initialized the session."""
        return self._session_id

    @property
    def _agent_type(self) -> str | None:
        return _resolve_agent_type(self)

    def _check_closed(self) -> None:
        if self._closed:
            raise ToolsConnectionError("Client is closed")

    def _next_id(self) -> int:
        self._request_id += 1
        return self._request_id

    def _build_headers(self) -> dict[str, str]:
        """Build request headers with MCP session, OTEL context, and auth."""
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        if self._session_id:
            headers["Mcp-Session-Id"] = self._session_id
        if self._protocol_version:
            headers["MCP-Protocol-Version"] = self._protocol_version
        if self._request_context:
            headers.update(self._request_context.get_headers())
        return headers

    async def _send(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
        _is_retry: bool = False,
    ) -> dict[str, Any]:
        """Send a JSON-RPC request and return the result."""
        request_id = self._next_id()
        payload: dict[str, Any] = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
        }
        if params is not None:
            payload["params"] = params

        effective_timeout = timeout if timeout is not None else self._timeout
        is_initialize = method == "initialize"

        self._inflight_request_id = request_id
        try:
            resp = await self._client.post(
                self._url,
                json=payload,
                headers=self._build_headers(),
                timeout=effective_timeout,
            )
        except asyncio.CancelledError:
            if not is_initialize:
                await self._cancel_request(request_id)
            raise
        except httpx.RequestError as e:
            raise ToolsConnectionError(f"MCP request failed: {e}") from e
        finally:
            self._inflight_request_id = None

        # 404 means session expired -- re-initialize once and retry
        if resp.status_code == 404 and not _is_retry and not is_initialize:
            self._reset_session()
            await self._ensure_initialized(timeout=timeout)
            return await self._send(method, params, timeout=timeout, _is_retry=True)

        if resp.status_code >= 400:
            body = resp.text[:500] if resp.text else ""
            msg = f"MCP request failed: HTTP {resp.status_code}"
            if body:
                msg += f" - {body}"
            raise ToolsConnectionError(msg)

        if "mcp-session-id" in resp.headers:
            self._session_id = resp.headers["mcp-session-id"]

        content_type = resp.headers.get("content-type", "")
        if "text/event-stream" in content_type:
            data = _parse_sse_response(resp.text)
        else:
            data = resp.json()

        expected_id = request_id
        if data.get("id") != expected_id:
            raise ToolsConnectionError(
                f"Response ID mismatch: expected {expected_id}, got {data.get('id')}"
            )

        if "error" in data:
            err = data["error"]
            raise ToolsConnectionError(
                f"JSON-RPC error {err.get('code', -1)}: {err.get('message', 'Unknown')}"
            )
        return data["result"]

    async def _notify(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
    ) -> None:
        """Send a JSON-RPC notification (no id, no response expected)."""
        payload: dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
        }
        if params is not None:
            payload["params"] = params

        effective_timeout = timeout if timeout is not None else self._timeout

        try:
            resp = await self._client.post(
                self._url,
                json=payload,
                headers=self._build_headers(),
                timeout=effective_timeout,
            )
        except httpx.RequestError as e:
            raise ToolsConnectionError(f"MCP notification failed: {e}") from e

        if resp.status_code >= 400:
            body = resp.text[:500] if resp.text else ""
            msg = f"MCP notification failed: HTTP {resp.status_code}"
            if body:
                msg += f" - {body}"
            raise ToolsConnectionError(msg)

    async def _cancel_request(
        self, request_id: int, reason: str = "Client cancelled"
    ) -> None:
        """Send a best-effort cancellation notification for a request."""
        try:
            await self._notify(
                "notifications/cancelled",
                {"requestId": request_id, "reason": reason},
                timeout=5.0,
            )
            self._log.debug("Sent cancellation for request %d", request_id)
        except Exception:
            self._log.debug("Failed to send cancellation for request %d", request_id)

    def _reset_session(self) -> None:
        """Clear session state for re-initialization."""
        self._session_id = None
        self._protocol_version = None
        self._initialized = False

    async def _ensure_initialized(self, *, timeout: float | None = None) -> None:
        """Initialize the MCP session if not already connected."""
        if self._initialized:
            return

        with tracer.start_as_current_span("tools.initialize") as span:
            t0 = time.monotonic()
            try:
                result = await self._send(
                    "initialize",
                    {
                        "protocolVersion": _PROTOCOL_VERSION,
                        "capabilities": {},
                        "clientInfo": {
                            "name": "cwai-adk",
                            "version": _adk_version(),
                        },
                    },
                    timeout=timeout,
                )
                self._protocol_version = result.get(
                    "protocolVersion", _PROTOCOL_VERSION
                )
                self._server_capabilities = result.get("capabilities")
                self._initialized = True

                await self._notify("notifications/initialized", timeout=timeout)

                duration_ms = (time.monotonic() - t0) * 1000
                self._log.info("MCP session initialized")
                record_tools_request(
                    "initialize",
                    duration_ms,
                    success=True,
                    tool_kind="mcp",
                    agent_type=self._agent_type,
                )

            except ToolsError:
                duration_ms = (time.monotonic() - t0) * 1000
                span.set_status(trace.StatusCode.ERROR, "MCP initialization failed")
                self._log.error("MCP initialization failed")
                record_tools_request(
                    "initialize",
                    duration_ms,
                    success=False,
                    tool_kind="mcp",
                    agent_type=self._agent_type,
                )
                record_tools_error(
                    "initialize",
                    "connection_error",
                    tool_kind="mcp",
                    agent_type=self._agent_type,
                )
                raise

    # -- Public MCP methods --------------------------------------------------

    async def list_tools(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]:
        """List available MCP tools."""
        self._check_closed()
        await self._ensure_initialized(timeout=timeout)
        params: dict[str, Any] = {}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._send("tools/list", params or None, timeout=timeout)

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Call an MCP tool with optional arguments."""
        self._check_closed()
        await self._ensure_initialized(timeout=timeout)
        return await self._send(
            "tools/call", {"name": name, "arguments": arguments or {}}, timeout=timeout
        )

    async def list_prompts(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]:
        """List available MCP prompts."""
        self._check_closed()
        await self._ensure_initialized(timeout=timeout)
        params: dict[str, Any] = {}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._send("prompts/list", params or None, timeout=timeout)

    async def get_prompt(
        self,
        name: str,
        arguments: dict[str, str] | None = None,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Get an MCP prompt by name."""
        self._check_closed()
        await self._ensure_initialized(timeout=timeout)
        params: dict[str, Any] = {"name": name}
        if arguments is not None:
            params["arguments"] = arguments
        return await self._send("prompts/get", params, timeout=timeout)

    async def list_resources(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]:
        """List available MCP resources."""
        self._check_closed()
        await self._ensure_initialized(timeout=timeout)
        params: dict[str, Any] = {}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._send("resources/list", params or None, timeout=timeout)

    async def read_resource(
        self, uri: str, *, timeout: float | None = None
    ) -> dict[str, Any]:
        """Read an MCP resource by URI."""
        self._check_closed()
        await self._ensure_initialized(timeout=timeout)
        return await self._send("resources/read", {"uri": uri}, timeout=timeout)

    async def list_resource_templates(
        self, *, cursor: str | None = None, timeout: float | None = None
    ) -> dict[str, Any]:
        """List available MCP resource templates."""
        self._check_closed()
        await self._ensure_initialized(timeout=timeout)
        params: dict[str, Any] = {}
        if cursor is not None:
            params["cursor"] = cursor
        return await self._send(
            "resources/templates/list", params or None, timeout=timeout
        )

    def get_server_capabilities(self) -> dict[str, Any] | None:
        """Return server capabilities from the init handshake.

        Returns None if not yet initialized.
        """
        return self._server_capabilities

    async def close(self) -> None:
        """Terminate the MCP session and close the HTTP client."""
        self._closed = True
        if self._inflight_request_id is not None:
            await self._cancel_request(
                self._inflight_request_id, reason="Client shutting down"
            )
        if self._session_id:
            try:
                await self._client.delete(self._url, headers=self._build_headers())
            except httpx.HTTPError:
                pass
            self._reset_session()
        await self._client.aclose()


def _parse_sse_response(text: str) -> dict[str, Any]:
    """Extract the JSON-RPC message from an SSE response body.

    fastmcp's Streamable HTTP always returns text/event-stream even for
    simple request/response. We take the last non-empty data line because
    servers may send a priming event with empty data first (per spec).
    """
    result: dict[str, Any] | None = None
    for line in text.splitlines():
        if line.startswith("data:"):
            payload = line[5:].strip()
            if payload:
                result = json.loads(payload)
    if result is None:
        raise ToolsConnectionError(f"No data line in SSE response: {text!r}")
    return result
