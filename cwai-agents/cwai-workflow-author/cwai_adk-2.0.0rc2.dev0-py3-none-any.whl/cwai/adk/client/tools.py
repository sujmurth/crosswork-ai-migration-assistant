"""Tools domain client for tool discovery, invocation, and caching.

Wraps McpClient and adds pagination, Tool dataclass mapping,
caching, and domain-specific behavior.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Protocol

from opentelemetry import trace

from cwai.adk.client.mcp import McpClientProtocol
from cwai.adk.errors import ToolsCallError, ToolsError
from cwai.adk.observability._labels import _resolve_agent_type
from cwai.adk.observability.metrics import record_tools_error, record_tools_request
from cwai.adk.observability.trace_events import record_content_event
from cwai.adk.request_context import RequestContext
from cwai.adk.tools import Tool

_default_logger = logging.getLogger("cwai.adk.client.tools")
tracer = trace.get_tracer("cwai.adk.client.tools")
"""Tracer used for tools client spans."""


class ToolsClientProtocol(Protocol):
    """Protocol for Tools/MCP client implementations.

    Provides tool discovery and invocation via the MCP protocol.
    Tools are fetched from the platform's Tool Catalog and can be
    used with ToolExecutor or LangChain via to_langchain_tools().
    """

    async def list_tools(
        self, *, timeout: float | None = None, refresh: bool = False
    ) -> list[Tool]:
        """Discover available tools from the MCP server.

        Returns:
            List of Tool objects with bound executors.

        Raises:
            ToolsConnectionError: On transport failures (including timeout).
        """
        ...

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> str:
        """Invoke a tool by name.

        Args:
            name: Tool name as returned by list_tools().
            arguments: Tool arguments matching the tool's input schema.
            timeout: Optional request timeout in seconds.

        Returns:
            Tool result as a JSON string.

        Raises:
            ToolsCallError: If the tool returns an error.
            ToolsConnectionError: On transport failures (including timeout).
        """
        ...


class ToolsClient:
    """Client for tool discovery and invocation through MCP.

    Wraps an McpClient to provide pagination, caching, and Tool
    dataclass mapping. Each tool's ``execute`` callable is bound
    to ``call_tool()``.

    Args:
        mcp: MCP client for protocol operations.
        request_context: Optional request context that provides the agent type label.
        log: Optional logger for task-scoped logging.

    Examples:
        # Discover tools and use them with the LLM:
        tools = await ctx.tools.list_tools()
        executor = ToolExecutor(tools)
        response = await ctx.llm.complete(
            messages=[{"role": "user", "content": prompt}],
            tools=executor.schemas,
        )
        # Execute tool calls the LLM chose:
        tool_calls = response.message.get("tool_calls", [])
        results = await executor.execute(tool_calls)
    """

    def __init__(
        self,
        mcp: McpClientProtocol,
        *,
        request_context: RequestContext | None = None,
        log: logging.Logger | logging.LoggerAdapter | None = None,
    ) -> None:
        self._mcp = mcp
        self._request_context = request_context
        self._log = log or _default_logger
        self._cached_tools: list[Tool] | None = None

    @property
    def _agent_type(self) -> str | None:
        return _resolve_agent_type(self)

    async def list_tools(
        self, *, timeout: float | None = None, refresh: bool = False
    ) -> list[Tool]:
        """Discover available tools from the MCP server.

        Results are cached after the first call. Subsequent calls return
        the cached list without making a network request. Pass
        ``refresh=True`` to bypass the cache and re-fetch from the server.
        Each tool's ``execute`` callable is bound to ``call_tool()``.

        Args:
            timeout: Request timeout in seconds.
            refresh: When true, bypass the cache and fetch tools from the server.

        Returns:
            List of Tool objects wrapping MCP tools.

        Raises:
            ToolsConnectionError: On transport failures (including timeout).
        """
        if self._cached_tools is not None and not refresh:
            return self._cached_tools

        with tracer.start_as_current_span("tools.list_tools") as span:
            self._log.info("MCP list_tools started")

            t0 = time.monotonic()
            try:
                # Paginate: loop while server returns nextCursor
                all_raw_tools: list[dict[str, Any]] = []
                cursor: str | None = None
                while True:
                    result = await self._mcp.list_tools(cursor=cursor, timeout=timeout)
                    all_raw_tools.extend(result.get("tools", []))
                    cursor = result.get("nextCursor")
                    if not cursor:
                        break
            except ToolsError:
                duration_ms = (time.monotonic() - t0) * 1000
                span.set_status(trace.StatusCode.ERROR, "list_tools failed")
                self._log.error("MCP list_tools failed")
                record_tools_request(
                    "list_tools",
                    duration_ms,
                    success=False,
                    tool_kind="mcp",
                    agent_type=self._agent_type,
                )
                record_tools_error(
                    "list_tools",
                    "connection_error",
                    tool_kind="mcp",
                    agent_type=self._agent_type,
                )
                raise

            duration_ms = (time.monotonic() - t0) * 1000

            self._cached_tools = [
                Tool(
                    name=t["name"],
                    description=t.get("description") or "",
                    parameters=t.get("inputSchema", {}),
                    execute=self._make_tool_executor(t["name"]),
                    title=t.get("title"),
                    annotations=t.get("annotations"),
                    output_schema=t.get("outputSchema"),
                )
                for t in all_raw_tools
            ]

            span.set_attribute("tools.count", len(self._cached_tools))
            self._log.info(
                "MCP list_tools completed",
                extra={"tool_count": len(self._cached_tools)},
            )
            record_tools_request(
                "list_tools",
                duration_ms,
                success=True,
                tool_kind="mcp",
                agent_type=self._agent_type,
            )
            return self._cached_tools

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
        *,
        timeout: float | None = None,
    ) -> str:
        """Invoke a tool by name.

        Args:
            name: Tool name as returned by list_tools().
            arguments: Tool arguments matching the tool's input schema.
            timeout: Optional request timeout in seconds.

        Returns:
            Tool result as a JSON string.

        Raises:
            ToolsCallError: If the tool returns an error.
            ToolsConnectionError: On transport failures (including timeout).
        """
        with tracer.start_as_current_span("tools.call_tool") as span:
            span.set_attribute("tools.tool_name", name)
            # Record tool input as span event
            if arguments:
                input_json = json.dumps(arguments, ensure_ascii=False)
                record_content_event(span, "cwai.agent.tool.input", input_json)
            # Use title for logging if available from cached tools
            display = name
            if self._cached_tools:
                for tool in self._cached_tools:
                    if tool.name == name and tool.title:
                        display = f"{tool.title} ({name})"
                        break
            self._log.info("MCP call_tool started", extra={"tool_name": display})

            t0 = time.monotonic()
            try:
                result = await self._mcp.call_tool(name, arguments, timeout=timeout)
            except ToolsError:
                duration_ms = (time.monotonic() - t0) * 1000
                span.set_status(trace.StatusCode.ERROR, f"call_tool({name}) failed")
                self._log.error("MCP call_tool failed", extra={"tool_name": display})
                record_tools_request(
                    "call_tool",
                    duration_ms,
                    success=False,
                    tool_name=name,
                    tool_kind="mcp",
                    agent_type=self._agent_type,
                )
                record_tools_error(
                    "call_tool",
                    "connection_error",
                    tool_name=name,
                    tool_kind="mcp",
                    agent_type=self._agent_type,
                )
                raise

            duration_ms = (time.monotonic() - t0) * 1000

            # MCP tools/call returns {content: [...], isError?: bool,
            # structuredContent?: {...}}
            is_error = result.get("isError", False)
            structured = result.get("structuredContent")
            content_parts = result.get("content", [])

            # Prefer structuredContent (typed JSON) over unstructured text
            if structured is not None:
                result_str = json.dumps(structured)
            else:
                text_parts = [
                    p["text"] for p in content_parts if p.get("type") == "text"
                ]
                result_str = "\n".join(text_parts) if text_parts else json.dumps(result)

            if is_error:
                span.set_status(trace.StatusCode.ERROR, f"Tool {name} returned error")
                self._log.error(
                    "MCP tool returned error",
                    extra={"tool_name": display, "error": result_str[:500]},
                )
                record_tools_request(
                    "call_tool",
                    duration_ms,
                    success=False,
                    tool_name=name,
                    tool_kind="mcp",
                    agent_type=self._agent_type,
                )
                record_tools_error(
                    "call_tool",
                    "call_error",
                    tool_name=name,
                    tool_kind="mcp",
                    agent_type=self._agent_type,
                )
                raise ToolsCallError(result_str, tool_name=name)

            self._log.info("MCP call_tool completed", extra={"tool_name": display})
            record_tools_request(
                "call_tool",
                duration_ms,
                success=True,
                tool_name=name,
                tool_kind="mcp",
                agent_type=self._agent_type,
            )
            record_content_event(span, "cwai.agent.tool.result", result_str)
            return result_str

    def _make_tool_executor(self, tool_name: str) -> Any:
        """Create a bound executor for a tool.

        Returns an async callable that forwards kwargs to call_tool().
        Errors are caught and returned as JSON error objects.
        """

        async def _execute(**kwargs: Any) -> str:
            try:
                return await self.call_tool(tool_name, kwargs)
            except ToolsError as e:
                return json.dumps({"error": str(e)})

        return _execute
