"""RAG/Context service client for document search and management.

Provides access to the Kontext service REST API. RequestContext headers
are forwarded for trace propagation.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict
from datetime import date
from typing import TYPE_CHECKING, Any, Protocol

import httpx
from opentelemetry import trace

from cwai.adk.errors import (
    RAGConnectionError,
    RAGError,
    RAGNotFoundError,
    RAGPayloadTooLargeError,
    RAGValidationError,
)
from cwai.adk.observability.metrics import record_rag_error, record_rag_request
from cwai.adk.request_context import RequestContext
from cwai.adk.tools import Tool
from cwai.adk.types.rag import (
    RAGCollectionInfo,
    RAGDocument,
    RAGDocumentSection,
    RAGSearchResult,
    RAGUploadResult,
)

if TYPE_CHECKING:
    from cwai.adk.config import TLSConfig

# Safety-net timeout for RAG operations. Long enough to accommodate slow
# searches and uploads while preventing indefinite hangs. See ADR-0023.
DEFAULT_TIMEOUT: float = 300.0
"""Default request timeout, in seconds."""

MAX_ERROR_DETAIL_LOG_CHARS: int = 512
"""Maximum response error detail length included in structured logs."""

_default_logger = logging.getLogger("cwai.adk.client.rag")
tracer = trace.get_tracer("cwai.adk.client.rag")
"""OTEL tracer used for RAG client spans."""


def _parse_date(value: str | None) -> date | None:
    """Parse an ISO date string, returning None on missing or invalid input."""
    if value is None:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        return None


def _response_error_detail(resp: httpx.Response) -> str:
    """Extract a concise error detail from a RAG HTTP response."""
    try:
        body = resp.json()
    except ValueError:
        detail = resp.text
    else:
        if isinstance(body, dict):
            raw_detail = body.get("detail") or body.get("error") or body
        else:
            raw_detail = body
        if isinstance(raw_detail, str):
            detail = raw_detail
        else:
            detail = json.dumps(raw_detail, default=str)

    if len(detail) > MAX_ERROR_DETAIL_LOG_CHARS:
        return detail[: MAX_ERROR_DETAIL_LOG_CHARS - 3] + "..."
    return detail


class RAGClientProtocol(Protocol):
    """Protocol for RAG/Context service client implementations.

    The RAG service stores document sections as embedding vectors and
    provides semantic search with tag and date filtering.
    """

    async def search(
        self,
        collection: str,
        query: str,
        *,
        tags: list[str] | None = None,
        limit: int | None = None,
        date_valid: bool | None = None,
        timeout: float | None = None,
    ) -> list[RAGSearchResult]:
        """Search for similar documents in a collection.

        Args:
            collection: Collection to search in.
            query: Search query text that the service embeds.
            tags: Optional tags to filter by (AND logic).
            limit: Maximum number of results. If omitted, the service
                determines the default.
            date_valid: When true, exclude documents whose validity end
                date has passed.
            timeout: Request timeout, in seconds. Defaults to the client
                timeout.

        Returns:
            List of matching document sections with similarity scores.

        Raises:
            RAGConnectionError: On transport failures.
        """
        ...

    async def upload(
        self,
        collection: str,
        sections: list[RAGDocumentSection],
        *,
        timeout: float | None = None,
    ) -> RAGUploadResult:
        """Upload document sections to a collection.

        Args:
            collection: Collection to upload to.
            sections: Document sections to insert.
            timeout: Optional request timeout in seconds.

        Returns:
            Upload result with inserted count and section IDs.

        Raises:
            RAGValidationError: On invalid input (HTTP 422).
            RAGPayloadTooLargeError: If request body is too large (HTTP 413).
            RAGConnectionError: On transport failures.
        """
        ...

    async def get_document(
        self,
        collection: str,
        section_id: str,
        *,
        timeout: float | None = None,
    ) -> RAGDocument:
        """Get a document section by ID.

        Args:
            collection: Collection the document belongs to.
            section_id: UUID of the document section.
            timeout: Optional request timeout in seconds.

        Returns:
            The document section.

        Raises:
            RAGNotFoundError: If section does not exist (HTTP 404).
            RAGConnectionError: On transport failures.
        """
        ...

    async def delete_document(
        self,
        collection: str,
        section_id: str,
        *,
        timeout: float | None = None,
    ) -> None:
        """Delete a document section by ID.

        Args:
            collection: Collection the document belongs to.
            section_id: UUID of the document section.
            timeout: Optional request timeout in seconds.

        Raises:
            RAGNotFoundError: If section does not exist (HTTP 404).
            RAGConnectionError: On transport failures.
        """
        ...

    async def list_collections(
        self,
        *,
        timeout: float | None = None,
    ) -> list[RAGCollectionInfo]:
        """List all collections with document counts.

        Args:
            timeout: Optional request timeout in seconds.

        Returns:
            List of collections with their document counts.

        Raises:
            RAGConnectionError: On transport failures.
        """
        ...

    async def delete_collection(
        self,
        collection: str,
        *,
        timeout: float | None = None,
    ) -> int:
        """Delete a collection and all its documents.

        Args:
            collection: Collection to delete.
            timeout: Optional request timeout in seconds.

        Returns:
            Number of deleted document sections.

        Raises:
            RAGNotFoundError: If collection does not exist (HTTP 404).
            RAGConnectionError: On transport failures.
        """
        ...

    async def upload_markdown(
        self,
        collection: str,
        markdown: str,
        *,
        timeout: float | None = None,
    ) -> RAGUploadResult:
        """Upload a markdown document with YAML frontmatter.

        The markdown body must include YAML frontmatter with at least
        ``date_created``, ``date_valid_until``, and ``search_column``.
        Optional frontmatter fields: ``tags`` (list), ``content`` (dict).

        Args:
            collection: Collection to upload to.
            markdown: Markdown text with YAML frontmatter.
            timeout: Optional request timeout in seconds.

        Returns:
            Upload result with inserted count and section IDs.

        Raises:
            RAGValidationError: On invalid input (HTTP 422).
            RAGPayloadTooLargeError: If request body is too large (HTTP 413).
            RAGConnectionError: On transport failures.
        """
        ...

    @property
    def tools(self) -> list[Tool]:
        """LLM tools for RAG operations.

        Returns a list of Tool objects that can be passed to ToolExecutor
        for LLM-driven document search and retrieval.

        Returns:
            List containing rag_search, rag_list_collections, and rag_get_document tools.
        """
        ...

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        ...


class RAGClient:
    """Async client for the RAG/Context service REST API.

    Args:
        base_url: Kontext service base URL (such as "http://kontext:8000/api/v1/context").
        request_context: Optional request context for OTEL trace propagation and task identity headers.
        tls_config: Optional TLS configuration for certificate verification.
        http_client: Optional httpx.AsyncClient for testing (DI).
        timeout: Default request timeout, in seconds. A per-request timeout
            overrides this value. The default is DEFAULT_TIMEOUT (300s).
        log: Optional logger for task-scoped logging.
    """

    def __init__(
        self,
        base_url: str,
        request_context: RequestContext | None = None,
        *,
        tls_config: TLSConfig | None = None,
        http_client: httpx.AsyncClient | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        log: logging.Logger | logging.LoggerAdapter | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._request_context = request_context
        self._timeout = timeout
        self._log = log or _default_logger

        if http_client is not None:
            self._client = http_client
        elif tls_config is not None:
            self._client = httpx.AsyncClient(verify=tls_config.httpx_verify())
        else:
            self._client = httpx.AsyncClient()

    def _build_headers(self) -> dict[str, str]:
        """Build request headers with OTEL context and auth token."""
        headers: dict[str, str] = {}
        if self._request_context:
            headers.update(self._request_context.get_headers())
        return headers

    def _raise_for_status(
        self,
        resp: httpx.Response,
        operation: str,
        span: trace.Span,
        duration_ms: float,
        *,
        collection: str | None = None,
    ) -> None:
        """Map HTTP error status codes to typed exceptions."""
        if resp.status_code < 400:
            return

        detail = _response_error_detail(resp)

        err_msg = f"RAG {operation} failed: HTTP {resp.status_code}"
        if detail:
            err_msg += f" - {detail}"

        span.set_status(trace.StatusCode.ERROR, err_msg)
        log_extra: dict[str, object] = {
            "operation": operation,
            "status_code": resp.status_code,
        }
        if collection is not None:
            log_extra["collection"] = collection
        if detail:
            log_extra["detail"] = detail
        self._log.error(
            "RAG request failed",
            extra=log_extra,
        )
        record_rag_request(operation, duration_ms, success=False)

        if resp.status_code == 404:
            record_rag_error(operation, "not_found")
            raise RAGNotFoundError(err_msg)
        if resp.status_code == 413:
            record_rag_error(operation, "payload_too_large")
            raise RAGPayloadTooLargeError(err_msg)
        if resp.status_code == 422:
            record_rag_error(operation, "validation_error")
            raise RAGValidationError(err_msg, detail=str(detail))

        record_rag_error(operation, "connection_error")
        raise RAGConnectionError(err_msg)

    async def search(
        self,
        collection: str,
        query: str,
        *,
        tags: list[str] | None = None,
        limit: int | None = None,
        date_valid: bool | None = None,
        timeout: float | None = None,
    ) -> list[RAGSearchResult]:
        """Search for similar documents in a collection.

        Args:
            collection: Collection to search in.
            query: Search query text that the service embeds.
            tags: Optional tags to filter by (AND logic).
            limit: Maximum number of results. If omitted, the service
                determines the default.
            date_valid: When true, exclude documents whose validity end
                date has passed.
            timeout: Request timeout, in seconds. Defaults to the client
                timeout.

        Returns:
            List of matching document sections with similarity scores.

        Raises:
            RAGConnectionError: On transport failures.
        """
        effective_timeout = timeout if timeout is not None else self._timeout
        with tracer.start_as_current_span("rag.search") as span:
            span.set_attribute("rag.collection", collection)

            body: dict[str, Any] = {"query": query}
            if tags is not None:
                body["tags"] = tags
            if limit is not None:
                body["limit"] = limit
            if date_valid is not None:
                body["date_valid"] = date_valid

            self._log.info("RAG search started", extra={"collection": collection})

            t0 = time.monotonic()
            try:
                resp = await self._client.post(
                    f"{self._base_url}/search/{collection}",
                    json=body,
                    headers=self._build_headers(),
                    timeout=effective_timeout,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err_msg = f"RAG search failed: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("RAG search failed", extra={"error": str(e)})
                record_rag_request("search", duration_ms, success=False)
                record_rag_error("search", "connection_error")
                raise RAGConnectionError(err_msg) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("http.status_code", resp.status_code)
            self._raise_for_status(
                resp, "search", span, duration_ms, collection=collection
            )

            data = resp.json()
            results = [
                RAGSearchResult(
                    id=r["id"],
                    section_id=str(r["section_id"]),
                    search_column=r["search_column"],
                    score=float(r["score"]),
                    tags=r.get("tags"),
                    date_created=_parse_date(r.get("date_created")),
                    date_valid_until=_parse_date(r.get("date_valid_until")),
                    content=r.get("content"),
                )
                for r in data.get("results", [])
            ]

            self._log.info(
                "RAG search completed",
                extra={"collection": collection, "result_count": len(results)},
            )
            record_rag_request("search", duration_ms, success=True)
            return results

    async def upload(
        self,
        collection: str,
        sections: list[RAGDocumentSection],
        *,
        timeout: float | None = None,
    ) -> RAGUploadResult:
        """Upload document sections to a collection.

        Args:
            collection: Collection to upload to.
            sections: Document sections to insert.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            Upload result with inserted count and section IDs.

        Raises:
            RAGValidationError: On invalid input (HTTP 422).
            RAGPayloadTooLargeError: If request body is too large (HTTP 413).
            RAGConnectionError: On transport failures.
        """
        effective_timeout = timeout if timeout is not None else self._timeout
        with tracer.start_as_current_span("rag.upload") as span:
            span.set_attribute("rag.collection", collection)
            span.set_attribute("rag.section_count", len(sections))

            body = {
                "document_sections": [
                    {
                        "search_column": s.search_column,
                        "content": s.content,
                        "date_created": s.date_created.isoformat(),
                        "date_valid_until": s.date_valid_until.isoformat(),
                        **({"tags": s.tags} if s.tags is not None else {}),
                    }
                    for s in sections
                ]
            }

            self._log.info(
                "RAG upload started",
                extra={"collection": collection, "section_count": len(sections)},
            )

            t0 = time.monotonic()
            try:
                resp = await self._client.post(
                    f"{self._base_url}/documents/{collection}",
                    json=body,
                    headers=self._build_headers(),
                    timeout=effective_timeout,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err_msg = f"RAG upload failed: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("RAG upload failed", extra={"error": str(e)})
                record_rag_request("upload", duration_ms, success=False)
                record_rag_error("upload", "connection_error")
                raise RAGConnectionError(err_msg) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("http.status_code", resp.status_code)
            self._raise_for_status(
                resp, "upload", span, duration_ms, collection=collection
            )

            data = resp.json()
            result = RAGUploadResult(
                inserted=data["inserted"],
                section_ids=[str(sid) for sid in data.get("section_ids", [])],
            )

            self._log.info(
                "RAG upload completed",
                extra={"collection": collection, "inserted": result.inserted},
            )
            record_rag_request("upload", duration_ms, success=True)
            return result

    async def get_document(
        self,
        collection: str,
        section_id: str,
        *,
        timeout: float | None = None,
    ) -> RAGDocument:
        """Get a document section by ID.

        Args:
            collection: Collection the document belongs to.
            section_id: UUID of the document section.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            The document section.

        Raises:
            RAGNotFoundError: If section does not exist (HTTP 404).
            RAGConnectionError: On transport failures.
        """
        effective_timeout = timeout if timeout is not None else self._timeout
        with tracer.start_as_current_span("rag.get_document") as span:
            span.set_attribute("rag.collection", collection)
            span.set_attribute("rag.section_id", section_id)

            self._log.info(
                "RAG get_document started",
                extra={"collection": collection, "section_id": section_id},
            )

            t0 = time.monotonic()
            try:
                resp = await self._client.get(
                    f"{self._base_url}/documents/{collection}/{section_id}",
                    headers=self._build_headers(),
                    timeout=effective_timeout,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err_msg = f"RAG get_document failed: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("RAG get_document failed", extra={"error": str(e)})
                record_rag_request("get_document", duration_ms, success=False)
                record_rag_error("get_document", "connection_error")
                raise RAGConnectionError(err_msg) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("http.status_code", resp.status_code)
            self._raise_for_status(
                resp,
                "get_document",
                span,
                duration_ms,
                collection=collection,
            )

            data = resp.json()
            doc = RAGDocument(
                id=data["id"],
                section_id=str(data["section_id"]),
                search_column=data["search_column"],
                tags=data.get("tags"),
                date_created=_parse_date(data.get("date_created")),
                date_valid_until=_parse_date(data.get("date_valid_until")),
                content=data.get("content"),
            )

            self._log.info(
                "RAG get_document completed",
                extra={"collection": collection, "section_id": section_id},
            )
            record_rag_request("get_document", duration_ms, success=True)
            return doc

    async def delete_document(
        self,
        collection: str,
        section_id: str,
        *,
        timeout: float | None = None,
    ) -> None:
        """Delete a document section by ID.

        Args:
            collection: Collection the document belongs to.
            section_id: UUID of the document section.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Raises:
            RAGNotFoundError: If section does not exist (HTTP 404).
            RAGConnectionError: On transport failures.
        """
        effective_timeout = timeout if timeout is not None else self._timeout
        with tracer.start_as_current_span("rag.delete_document") as span:
            span.set_attribute("rag.collection", collection)
            span.set_attribute("rag.section_id", section_id)

            self._log.info(
                "RAG delete_document started",
                extra={"collection": collection, "section_id": section_id},
            )

            t0 = time.monotonic()
            try:
                resp = await self._client.delete(
                    f"{self._base_url}/documents/{collection}/{section_id}",
                    headers=self._build_headers(),
                    timeout=effective_timeout,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err_msg = f"RAG delete_document failed: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("RAG delete_document failed", extra={"error": str(e)})
                record_rag_request("delete_document", duration_ms, success=False)
                record_rag_error("delete_document", "connection_error")
                raise RAGConnectionError(err_msg) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("http.status_code", resp.status_code)
            self._raise_for_status(
                resp,
                "delete_document",
                span,
                duration_ms,
                collection=collection,
            )

            self._log.info(
                "RAG delete_document completed",
                extra={"collection": collection, "section_id": section_id},
            )
            record_rag_request("delete_document", duration_ms, success=True)

    async def list_collections(
        self,
        *,
        timeout: float | None = None,
    ) -> list[RAGCollectionInfo]:
        """List all collections with document counts.

        Args:
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            List of collections with their document counts.

        Raises:
            RAGConnectionError: On transport failures.
        """
        effective_timeout = timeout if timeout is not None else self._timeout
        with tracer.start_as_current_span("rag.list_collections") as span:
            self._log.info("RAG list_collections started")

            t0 = time.monotonic()
            try:
                resp = await self._client.get(
                    f"{self._base_url}/collections",
                    headers=self._build_headers(),
                    timeout=effective_timeout,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err_msg = f"RAG list_collections failed: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("RAG list_collections failed", extra={"error": str(e)})
                record_rag_request("list_collections", duration_ms, success=False)
                record_rag_error("list_collections", "connection_error")
                raise RAGConnectionError(err_msg) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("http.status_code", resp.status_code)
            self._raise_for_status(resp, "list_collections", span, duration_ms)

            data = resp.json()
            collections = [
                RAGCollectionInfo(
                    name=c["name"],
                    document_count=c["document_count"],
                )
                for c in data.get("collections", [])
            ]

            self._log.info(
                "RAG list_collections completed",
                extra={"collection_count": len(collections)},
            )
            record_rag_request("list_collections", duration_ms, success=True)
            return collections

    async def delete_collection(
        self,
        collection: str,
        *,
        timeout: float | None = None,
    ) -> int:
        """Delete a collection and all its documents.

        Args:
            collection: Collection to delete.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            Number of deleted document sections.

        Raises:
            RAGNotFoundError: If collection does not exist (HTTP 404).
            RAGConnectionError: On transport failures.
        """
        effective_timeout = timeout if timeout is not None else self._timeout
        with tracer.start_as_current_span("rag.delete_collection") as span:
            span.set_attribute("rag.collection", collection)

            self._log.info(
                "RAG delete_collection started",
                extra={"collection": collection},
            )

            t0 = time.monotonic()
            try:
                resp = await self._client.delete(
                    f"{self._base_url}/collections/{collection}",
                    headers=self._build_headers(),
                    timeout=effective_timeout,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err_msg = f"RAG delete_collection failed: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("RAG delete_collection failed", extra={"error": str(e)})
                record_rag_request("delete_collection", duration_ms, success=False)
                record_rag_error("delete_collection", "connection_error")
                raise RAGConnectionError(err_msg) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("http.status_code", resp.status_code)
            self._raise_for_status(
                resp,
                "delete_collection",
                span,
                duration_ms,
                collection=collection,
            )

            data = resp.json()
            deleted_count = data.get("deleted_count", 0)

            self._log.info(
                "RAG delete_collection completed",
                extra={"collection": collection, "deleted_count": deleted_count},
            )
            record_rag_request("delete_collection", duration_ms, success=True)
            return deleted_count

    async def upload_markdown(
        self,
        collection: str,
        markdown: str,
        *,
        timeout: float | None = None,
    ) -> RAGUploadResult:
        """Upload a markdown document with YAML frontmatter.

        The markdown body must include YAML frontmatter with at least
        ``date_created``, ``date_valid_until``, and ``search_column``.
        Optional frontmatter fields: ``tags`` (list), ``content`` (dict).

        Args:
            collection: Collection to upload to.
            markdown: Markdown text with YAML frontmatter.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            Upload result with inserted count and section IDs.

        Raises:
            RAGValidationError: On invalid input (HTTP 422).
            RAGPayloadTooLargeError: If request body is too large (HTTP 413).
            RAGConnectionError: On transport failures.
        """
        effective_timeout = timeout if timeout is not None else self._timeout
        with tracer.start_as_current_span("rag.upload_markdown") as span:
            span.set_attribute("rag.collection", collection)

            self._log.info(
                "RAG upload_markdown started",
                extra={"collection": collection},
            )

            headers = self._build_headers()
            headers["content-type"] = "text/markdown"

            t0 = time.monotonic()
            try:
                resp = await self._client.post(
                    f"{self._base_url}/documents/{collection}/markdown",
                    content=markdown.encode("utf-8"),
                    headers=headers,
                    timeout=effective_timeout,
                )
            except httpx.RequestError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                err_msg = f"RAG upload_markdown failed: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error("RAG upload_markdown failed", extra={"error": str(e)})
                record_rag_request("upload_markdown", duration_ms, success=False)
                record_rag_error("upload_markdown", "connection_error")
                raise RAGConnectionError(err_msg) from e

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("http.status_code", resp.status_code)
            self._raise_for_status(
                resp,
                "upload_markdown",
                span,
                duration_ms,
                collection=collection,
            )

            data = resp.json()
            result = RAGUploadResult(
                inserted=data["inserted"],
                section_ids=[str(sid) for sid in data.get("section_ids", [])],
            )

            self._log.info(
                "RAG upload_markdown completed",
                extra={"collection": collection, "inserted": result.inserted},
            )
            record_rag_request("upload_markdown", duration_ms, success=True)
            return result

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    @property
    def tools(self) -> list[Tool]:
        """LLM tools for RAG operations.

        Returns a list of Tool objects that can be passed to ToolExecutor
        for LLM-driven document search and retrieval.

        Returns:
            List containing rag_search, rag_list_collections, and rag_get_document tools.

        Examples:
            from cwai.adk import ToolExecutor

            executor = ToolExecutor(ctx.rag.tools)
            response = await ctx.llm.complete(
                messages=messages,
                tools=executor.schemas,
            )
        """
        return [
            Tool(
                name="rag_search",
                description=(
                    "Search for documents in a RAG collection using semantic "
                    "similarity. Returns matching document sections with "
                    "relevance scores. Use rag_list_collections first to "
                    "discover available collections."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "collection": {
                            "type": "string",
                            "description": "Name of the collection to search",
                        },
                        "query": {
                            "type": "string",
                            "description": "Search query text",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum number of results to return",
                        },
                    },
                    "required": ["collection", "query"],
                },
                execute=self._tool_search,
            ),
            Tool(
                name="rag_list_collections",
                description=(
                    "List all available RAG collections with their document "
                    "counts. Call this to discover what collections exist "
                    "before searching."
                ),
                parameters={"type": "object", "properties": {}},
                execute=self._tool_list_collections,
            ),
            Tool(
                name="rag_get_document",
                description=(
                    "Get a specific document section by its ID. Use this to "
                    "retrieve the full content of a document found via search."
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "collection": {
                            "type": "string",
                            "description": "Name of the collection",
                        },
                        "section_id": {
                            "type": "string",
                            "description": "UUID of the document section",
                        },
                    },
                    "required": ["collection", "section_id"],
                },
                execute=self._tool_get_document,
            ),
        ]

    async def _tool_search(
        self,
        collection: str,
        query: str,
        limit: int | None = None,
    ) -> str:
        """Execute rag_search tool, returning JSON result or error."""
        try:
            results = await self.search(collection, query, limit=limit)
            return json.dumps(
                [self._search_result_to_dict(r) for r in results],
                default=str,  # Handle date serialization
            )
        except RAGError as e:
            return json.dumps({"error": str(e)})

    async def _tool_list_collections(self) -> str:
        """Execute rag_list_collections tool, returning JSON result or error."""
        try:
            collections = await self.list_collections()
            return json.dumps([asdict(c) for c in collections])
        except RAGError as e:
            return json.dumps({"error": str(e)})

    async def _tool_get_document(
        self,
        collection: str,
        section_id: str,
    ) -> str:
        """Execute rag_get_document tool, returning JSON result or error."""
        try:
            doc = await self.get_document(collection, section_id)
            return json.dumps(self._document_to_dict(doc), default=str)
        except RAGError as e:
            return json.dumps({"error": str(e)})

    @staticmethod
    def _search_result_to_dict(r: RAGSearchResult) -> dict[str, Any]:
        """Convert RAGSearchResult to dict for JSON serialization."""
        return {
            "id": r.id,
            "section_id": r.section_id,
            "search_column": r.search_column,
            "score": r.score,
            "tags": r.tags,
            "date_created": r.date_created.isoformat() if r.date_created else None,
            "date_valid_until": (
                r.date_valid_until.isoformat() if r.date_valid_until else None
            ),
            "content": r.content,
        }

    @staticmethod
    def _document_to_dict(doc: RAGDocument) -> dict[str, Any]:
        """Convert RAGDocument to dict for JSON serialization."""
        return {
            "id": doc.id,
            "section_id": doc.section_id,
            "search_column": doc.search_column,
            "tags": doc.tags,
            "date_created": doc.date_created.isoformat() if doc.date_created else None,
            "date_valid_until": (
                doc.date_valid_until.isoformat() if doc.date_valid_until else None
            ),
            "content": doc.content,
        }
