"""DRA Gateway client for gRPC access to Data Retrieval Adapters.

The client manages the gRPC channel and adds metadata injection, tracing,
and metrics to DRA method calls.
"""

import logging
import re
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from functools import cached_property
from typing import TYPE_CHECKING, Any, Protocol

import grpc
import grpc.aio
from google.protobuf import json_format, struct_pb2
from opentelemetry import trace

from cwai.adk.config import default_grpc_channel_options
from cwai.adk.errors import DRAConnectionError, DRARequestError
from cwai.adk.observability.metrics import (
    record_dra_error,
    record_dra_request,
    record_dra_response,
)
from cwai.adk.proto.dra.v2 import dra_pb2, dra_pb2_grpc
from cwai.adk.proto.dra.v2 import draCommon_pb2 as common_pb2
from cwai.adk.request_context import RequestContext

if TYPE_CHECKING:
    from cwai.adk.client._generated.device_command_v2_wrapper import (
        DeviceCommandServiceWrapper,
    )
    from cwai.adk.client._generated.device_grouping_v2_wrapper import (
        DeviceGroupingServiceWrapper,
    )
    from cwai.adk.client._generated.device_statistics_v2_wrapper import (
        DeviceStatisticsRetrievalServiceWrapper,
    )
    from cwai.adk.client._generated.fault_v2_wrapper import FaultRetrievalServiceWrapper
    from cwai.adk.client._generated.lsp_data_v2_wrapper import (
        LSPDataRetrievalServiceWrapper,
    )

# Safety-net timeout for DRA operations. Long enough to accommodate slow
# external system queries while preventing indefinite hangs. See ADR-0023.
DEFAULT_TIMEOUT: float = 300.0
"""Default request timeout, in seconds."""


@dataclass
class DRAResponse:
    """Response from a generic DRA function call.

    Attributes:
        data: Response payload as a dictionary.
        dra_id: Identifier of the DRA that produced this response.
        task_id: Task ID echoed from the request context.
    """

    data: dict[str, Any]
    """Response payload as a dictionary."""
    dra_id: str
    """Identifier of the DRA that produced this response."""
    task_id: int
    """Task ID echoed from the request context."""


_default_logger = logging.getLogger("cwai.adk.client.dra")
tracer = trace.get_tracer("cwai.adk.client.dra")
"""OpenTelemetry tracer used for DRA client spans."""

# Operation name validation: lowercase letters, numbers, underscores; starts with letter
_OPERATION_NAME_PATTERN = re.compile(r"^[a-z][a-z0-9_]*$")
_OPERATION_NAME_MIN_LENGTH = 3
_OPERATION_NAME_MAX_LENGTH = 64


def _validate_operation_name(name: str) -> None:
    """Validate operation name for tracing and metrics.

    Operation names must:
    - Be 3-64 characters long
    - Start with a lowercase letter
    - Contain only lowercase letters, numbers, and underscores

    Args:
        name: Operation name to validate.

    Raises:
        ValueError: If name is invalid.
    """
    length = len(name)
    if length < _OPERATION_NAME_MIN_LENGTH:
        raise ValueError(
            f"Operation name must be at least {_OPERATION_NAME_MIN_LENGTH} characters, "
            f"got {length}: {name!r}"
        )
    if length > _OPERATION_NAME_MAX_LENGTH:
        raise ValueError(
            f"Operation name must be at most {_OPERATION_NAME_MAX_LENGTH} characters, "
            f"got {length}: {name!r}"
        )
    if not _OPERATION_NAME_PATTERN.match(name):
        raise ValueError(
            f"Operation name must start with a lowercase letter and contain only "
            f"lowercase letters, numbers, and underscores: {name!r}"
        )


class DRAClientProtocol(Protocol):
    """Protocol for DRA Gateway client implementations.

    The DRA Gateway provides unified access to Data Retrieval Adapters (DRAs).
    Use ``channel`` to create gRPC stubs, and ``call_stream()`` (preferred)
    or ``call_unary()`` to invoke methods with automatic metadata injection
    and observability.

    Most DRA methods use streaming due to the gateway's fan-out pattern.
    Use ``call_unary()`` only for single-response methods like
    ``GetDeviceRunningConfig``.
    """

    @property
    def channel(self) -> grpc.aio.Channel:
        """gRPC channel for creating custom stubs.

        Raises:
            DRAConnectionError: If client is not connected.
        """
        ...

    async def call_unary(
        self,
        name: str,
        method: Callable[..., Awaitable[Any]],
        request: Any,
        *,
        timeout: float = ...,
    ) -> Any:
        """Call a unary gRPC method with automatic metadata injection.

        Most DRA operations use streaming (call_stream) due to the fan-out
        pattern. Use call_unary only for single-response methods like
        GetDeviceRunningConfig.

        Args:
            name: Operation name for tracing spans and metrics.
            method: gRPC stub method to call.
            request: Protobuf request message.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            Protobuf response message.

        Raises:
            DRAConnectionError: If client is not connected.
            DRARequestError: On gRPC errors (including timeout).
        """
        ...

    async def call_stream(
        self,
        name: str,
        method: Callable[..., AsyncIterator[Any]],
        request: Any,
        *,
        timeout: float = ...,
    ) -> AsyncIterator[Any]:
        """Call a streaming gRPC method with automatic metadata injection.

        This is the preferred method for most DRA operations due to the
        fan-out pattern where multiple DRAs can respond to a single request.

        Args:
            name: Operation name for tracing spans and metrics.
            method: gRPC stub streaming method to call.
            request: Protobuf request message.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Yields:
            Protobuf response messages.

        Raises:
            DRAConnectionError: If client is not connected.
            DRARequestError: On gRPC errors (including timeout).
        """
        ...

    async def get_async_data(
        self,
        func_name: str,
        func_param: dict[str, Any] | list[Any] | str | int | float | bool | None = None,
        task_id: int = 0,
        user_id: int = 0,
        *,
        timeout: float = ...,
    ) -> AsyncIterator[DRAResponse]:
        """Call a DRA function by name (generic interface).

        Args:
            func_name: Name of the DRA function to call.
            func_param: Parameters to pass to the function.
            task_id: Task ID for request context.
            user_id: User ID for request context.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Yields:
            DRAResponse for each response from a DRA.

        Raises:
            DRAConnectionError: On connection failures.
            DRARequestError: On gRPC errors (including timeout).
        """
        ...

    async def close(self) -> None:
        """Close gRPC channel."""
        ...


class DRAClient:
    """Async client for DRA Gateway.

    Manages a gRPC channel to the DRA Gateway and provides infrastructure
    for calling DRA methods with automatic metadata injection, tracing,
    and metrics.

    The DRA Gateway uses a fan-out pattern: requests are broadcast to all
    DRAs that implement the requested service, and responses stream back
    as they arrive. For this reason, most operations should use
    ``call_stream()``. Use ``call_unary()`` only for single-response methods
    like ``GetDeviceRunningConfig``.

    For typed DRA operations, create stubs from the ``channel`` property
    and use ``call_stream()`` (preferred) or ``call_unary()`` to invoke methods.

    Args:
        gateway_url: DRA Gateway address (such as "localhost:50051").
        request_context: Optional context for OTEL trace propagation and
            app-level identity headers.
        timeout: Default timeout in seconds for requests. Per-request timeout
            can override this. Defaults to DEFAULT_TIMEOUT (300s).
        log: Optional logger for task-scoped logging.

    Examples:
        from cwai.adk.proto.dra.v2 import deviceGrouping_pb2_grpc as dg_grpc

        async with DRAClient("localhost:50051") as client:
            stub = dg_grpc.DeviceGroupingServiceStub(client.channel)
            async for response in client.call_stream(
                "get_device_groups", stub.GetDeviceGroups, request
            ):
                for group in response.groups:
                    print(group.groupName)
    """

    def __init__(
        self,
        gateway_url: str,
        request_context: RequestContext | None = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        log: logging.Logger | logging.LoggerAdapter | None = None,
    ) -> None:
        self._gateway_url = gateway_url
        self._request_context = request_context
        self._timeout = timeout
        self._log = log or _default_logger
        self._channel: grpc.aio.Channel | None = None
        self._data_retrieval_stub: dra_pb2_grpc.DataRetrievalServiceStub | None = None

    # --- Typed service wrappers ---
    # These provide a cleaner API for common DRA operations. Each wrapper
    # handles stub creation and request construction automatically.

    @cached_property
    def device_command(self) -> "DeviceCommandServiceWrapper":
        """Typed wrapper for DeviceCommandService.

        Provides methods for running show commands and retrieving device configs.

        Examples:
            await ctx.dra.connect()
            response = await ctx.dra.device_command.get_device_running_config(
                node_id="router-1"
            )
        """
        from cwai.adk.client._generated.device_command_v2_wrapper import (
            DeviceCommandServiceWrapper,
        )

        return DeviceCommandServiceWrapper(self)

    @cached_property
    def device_grouping(self) -> "DeviceGroupingServiceWrapper":
        """Typed wrapper for DeviceGroupingService.

        Provides methods for retrieving device groups and their members.

        Examples:
            await ctx.dra.connect()
            async for response in ctx.dra.device_grouping.get_device_groups():
                for group in response.groups:
                    print(group.groupName)
        """
        from cwai.adk.client._generated.device_grouping_v2_wrapper import (
            DeviceGroupingServiceWrapper,
        )

        return DeviceGroupingServiceWrapper(self)

    @cached_property
    def device_statistics(self) -> "DeviceStatisticsRetrievalServiceWrapper":
        """Typed wrapper for DeviceStatisticsRetrievalService.

        Provides methods for retrieving device statistics and metrics.

        Examples:
            await ctx.dra.connect()
            async for response in ctx.dra.device_statistics.get_device_statistics(
                node_id="router-1"
            ):
                print(response)
        """
        from cwai.adk.client._generated.device_statistics_v2_wrapper import (
            DeviceStatisticsRetrievalServiceWrapper,
        )

        return DeviceStatisticsRetrievalServiceWrapper(self)

    @cached_property
    def fault(self) -> "FaultRetrievalServiceWrapper":
        """Typed wrapper for FaultRetrievalService.

        Provides methods for retrieving alarms and events.

        Examples:
            await ctx.dra.connect()
            async for response in ctx.dra.fault.get_alarms_or_events():
                for alarm in response.alarms:
                    print(alarm)
        """
        from cwai.adk.client._generated.fault_v2_wrapper import (
            FaultRetrievalServiceWrapper,
        )

        return FaultRetrievalServiceWrapper(self)

    @cached_property
    def lsp_data(self) -> "LSPDataRetrievalServiceWrapper":
        """Wrapper for LSPDataRetrievalService.

        Provides methods for retrieving LSP topology, metrics, and paths.

        Examples:
            await ctx.dra.connect()
            async for response in ctx.dra.lsp_data.get_lsp_graph_data(
                head_router_id="1.1.1.1",
            ):
                print(response)
        """
        from cwai.adk.client._generated.lsp_data_v2_wrapper import (
            LSPDataRetrievalServiceWrapper,
        )

        return LSPDataRetrievalServiceWrapper(self)

    def _build_metadata(self) -> tuple[tuple[str, str], ...] | None:
        """Build gRPC metadata with trace context and identity."""
        if self._request_context is None:
            return None
        return self._request_context.get_grpc_metadata()

    @property
    def channel(self) -> grpc.aio.Channel:
        """gRPC channel for creating custom stubs.

        Use this to create your own gRPC stubs when working with custom
        DRA protobuf definitions. Combine with ``call_unary()`` or ``call_stream()``
        to ensure metadata is injected automatically.

        Raises:
            DRAConnectionError: If client is not connected.

        Examples:
            await ctx.dra.connect()
            my_stub = custom_pb2_grpc.MyServiceStub(ctx.dra.channel)
            response = await ctx.dra.call_unary("my_method", my_stub.MyMethod, request)
        """
        if self._channel is None:
            raise DRAConnectionError("Client not connected. Call connect() first.")
        return self._channel

    async def connect(self) -> None:
        """Open gRPC channel to gateway.

        Raises:
            DRAConnectionError: If connection fails.
        """
        with tracer.start_as_current_span("dra.connect") as span:
            span.set_attribute("dra.gateway_url", self._gateway_url)
            self._log.info(
                "Connecting to DRA Gateway", extra={"gateway_url": self._gateway_url}
            )
            try:
                self._channel = grpc.aio.insecure_channel(
                    self._gateway_url,
                    options=default_grpc_channel_options(),
                )
                self._data_retrieval_stub = dra_pb2_grpc.DataRetrievalServiceStub(
                    self._channel
                )
            except Exception as e:
                err_msg = f"Failed to create DRA Gateway channel: {e}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error(
                    "DRA Gateway connection failed", extra={"error": str(e)}
                )
                raise DRAConnectionError(err_msg) from e

    async def close(self) -> None:
        """Close gRPC channel."""
        if self._channel:
            self._log.debug("Closing DRA Gateway connection")
            await self._channel.close()
            self._channel = None
            self._data_retrieval_stub = None

    async def __aenter__(self) -> "DRAClient":
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        await self.close()

    async def call_unary(
        self,
        name: str,
        method: Callable[..., Awaitable[Any]],
        request: Any,
        *,
        timeout: float | None = None,
    ) -> Any:
        """Call a unary gRPC method with automatic metadata injection.

        Most DRA Gateway methods use streaming responses due to the fan-out
        pattern (multiple DRAs can respond to a single request). For those
        methods, use ``call_stream()`` instead.

        Use ``call_unary()`` only for methods that return a single response,
        such as ``GetDeviceRunningConfig`` which targets a specific device
        managed by a single DRA.

        Args:
            name: Operation name for tracing spans and metrics.
            method: gRPC stub method to call (such as ``stub.GetDeviceRunningConfig``).
            request: Protobuf request message.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Returns:
            Protobuf response message from the gRPC call.

        Raises:
            DRAConnectionError: If client is not connected.
            DRARequestError: On gRPC errors (including timeout).
            ValueError: If name is invalid.

        Examples:
            await ctx.dra.connect()
            cmd_stub = deviceCommand_pb2_grpc.DeviceCommandServiceStub(ctx.dra.channel)
            response = await ctx.dra.call_unary(
                "get_device_running_config",
                cmd_stub.GetDeviceRunningConfig,
                request,
                timeout=30.0,
            )
        """
        _validate_operation_name(name)
        if self._channel is None:
            raise DRAConnectionError("Client not connected. Call connect() first.")

        with tracer.start_as_current_span(f"dra.call.{name}") as span:
            span.set_attribute("dra.operation", name)

            self._log.info(f"DRA {name} started")

            t0 = time.monotonic()
            try:
                response = await method(
                    request,
                    metadata=self._build_metadata(),
                    timeout=timeout if timeout is not None else self._timeout,
                )
                duration_ms = (time.monotonic() - t0) * 1000
                record_dra_request(name, duration_ms, success=True)
                self._log.info(f"DRA {name} completed")
                return response

            except grpc.aio.AioRpcError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                record_dra_request(name, duration_ms, success=False)
                record_dra_error(name, "request_error")
                err_msg = f"DRA {name} failed: {e.details()}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error(
                    f"DRA {name} failed",
                    extra={"grpc_code": e.code().name, "details": e.details()},
                )
                raise DRARequestError(err_msg) from e

    async def call_stream(
        self,
        name: str,
        method: Callable[..., AsyncIterator[Any]],
        request: Any,
        *,
        timeout: float | None = None,
    ) -> AsyncIterator[Any]:
        """Call a streaming gRPC method with automatic metadata injection.

        This is the preferred method for most DRA operations. The DRA Gateway
        uses a fan-out pattern where requests are broadcast to all DRAs that
        implement the requested service, and responses are streamed back as
        they arrive. Each response includes a ``dra_id`` identifying its source.

        Use this with custom protobuf stubs to get tracing, metrics, and
        automatic metadata injection for streaming RPCs.

        Args:
            name: Operation name for tracing spans and metrics.
            method: gRPC stub streaming method to call.
            request: Protobuf request message.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Yields:
            Protobuf response messages from the stream.

        Raises:
            DRAConnectionError: If client is not connected.
            DRARequestError: On gRPC errors (including timeout).
            ValueError: If name is invalid.

        Examples:
            from cwai.adk.proto.dra.v2 import deviceGrouping_pb2_grpc as dg_grpc

            await ctx.dra.connect()
            stub = dg_grpc.DeviceGroupingServiceStub(ctx.dra.channel)
            async for response in ctx.dra.call_stream(
                "get_device_groups",
                stub.GetDeviceGroups,
                request,
                timeout=30.0,
            ):
                for group in response.groups:
                    print(group.groupName)
        """
        _validate_operation_name(name)
        if self._channel is None:
            raise DRAConnectionError("Client not connected. Call connect() first.")

        with tracer.start_as_current_span(f"dra.call_stream.{name}") as span:
            span.set_attribute("dra.operation", name)

            self._log.info(f"DRA {name} started")

            t0 = time.monotonic()
            try:
                response_count = 0
                async for response in method(
                    request,
                    metadata=self._build_metadata(),
                    timeout=timeout if timeout is not None else self._timeout,
                ):
                    response_count += 1
                    self._log.debug(f"DRA {name} response received")
                    yield response

                duration_ms = (time.monotonic() - t0) * 1000
                record_dra_request(name, duration_ms, success=True)
                self._log.info(
                    f"DRA {name} completed",
                    extra={"response_count": response_count},
                )

            except grpc.aio.AioRpcError as e:
                duration_ms = (time.monotonic() - t0) * 1000
                record_dra_request(name, duration_ms, success=False)
                record_dra_error(name, "request_error")
                err_msg = f"DRA {name} failed: {e.details()}"
                span.set_status(trace.StatusCode.ERROR, err_msg)
                self._log.error(
                    f"DRA {name} failed",
                    extra={"grpc_code": e.code().name, "details": e.details()},
                )
                raise DRARequestError(err_msg) from e

    async def get_async_data(
        self,
        func_name: str,
        func_param: dict[str, Any] | list[Any] | str | int | float | bool | None = None,
        task_id: int = 0,
        user_id: int = 0,
        *,
        timeout: float | None = None,
    ) -> AsyncIterator[DRAResponse]:
        """Call a DRA function by name (generic interface).

        This is a generic escape hatch for invoking DRA functions without
        needing protobuf stubs. Use this when you don't have access to the
        proto definitions for a DRA, or for quick prototyping.

        For typed DRA operations with full IDE support, use ``call_unary()`` or
        ``call_stream()`` with protobuf stubs created from the ``channel``.

        Args:
            func_name: Name of the DRA function to call.
            func_param: Parameters to pass to the function. Can be any
                JSON-serializable value (dict, list, string, number, bool, None).
            task_id: Task ID for request context.
            user_id: User ID for request context.
            timeout: Request timeout in seconds. Defaults to client timeout.

        Yields:
            DRAResponse for each response from a DRA. The ``data`` field contains the response payload as a dict, and ``dra_id`` identifies the source DRA.

        Raises:
            DRAConnectionError: If client is not connected.
            DRARequestError: On gRPC errors (including timeout).

        Examples:
            async for response in ctx.dra.get_async_data(
                func_name="getDeviceInfo",
                func_param={"device_id": "router-1"},
                timeout=30.0,
            ):
                print(f"From {response.dra_id}: {response.data}")
        """
        if not self._data_retrieval_stub:
            raise DRAConnectionError("Client not connected. Call connect() first.")

        # Convert Python value to protobuf Value
        func_param_value = None
        if func_param is not None:
            func_param_value = json_format.ParseDict(
                func_param,
                struct_pb2.Value(),  # type: ignore[attr-defined]
            )

        request = dra_pb2.GetAsyncDataRequest(
            context=common_pb2.RequestContext(
                taskID=task_id,
                userID=user_id,
            ),
            funcName=func_name,
            funcParam=func_param_value,
        )

        async for response in self.call_stream(
            "get_async_data",
            self._data_retrieval_stub.GetAsyncData,
            request,
            timeout=timeout,
        ):
            dra_id = response.context.draID if response.context else "unknown"
            resp_task_id = response.context.taskID if response.context else 0

            # Convert protobuf Struct to dict
            data = json_format.MessageToDict(response.response)

            record_dra_response("get_async_data", dra_id)
            yield DRAResponse(data=data, dra_id=dra_id, task_id=resp_task_id)
