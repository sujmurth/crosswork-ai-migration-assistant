# DRA Gateway Client

The DRA client (`ctx.dra`) provides access to Data Retrieval Adapters (DRAs)
through the centralized DRA Gateway service.

## Overview

The DRA Gateway is a unified proxy for multiple DRA instances. When you make
a request through `ctx.dra`, the gateway routes it to all DRAs that implement
the requested method and streams back their responses.

```
┌─────────────┐      gRPC       ┌─────────────────┐      gRPC      ┌───────────┐
│   Agent     │ ──────────────> │   DRA Gateway   │ ─────────────> │  DRA CNC  │
│  (ADK)      │                 │   (port 50051)  │                └───────────┘
│             │                 │                 │                ┌───────────┐
│ ctx.dra     │                 │  - Fan-out      │ ─────────────> │  DRA NSO  │
└─────────────┘                 │  - Streaming    │                └───────────┘
                                └─────────────────┘
```

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `CWAI_DRA_GATEWAY_URL` | `dra-gateway:50051` | DRA Gateway gRPC address |

## Typed Service Wrappers (Recommended)

The DRA client provides typed wrapper accessors for common DRA services. These
wrappers handle stub creation, request construction, and RequestContext
automatically, offering a cleaner API than working with raw stubs.

### Available Wrappers

| Accessor | Service | Methods |
|----------|---------|---------|
| `ctx.dra.device_command` | DeviceCommandService | `run_show_commands()`, `get_device_running_config()`, `get_configuration_changed_data()` |
| `ctx.dra.device_grouping` | DeviceGroupingService | `get_device_groups()`, `get_device_group_members()` |
| `ctx.dra.device_statistics` | DeviceStatisticsRetrievalService | `get_device_statistics()` |
| `ctx.dra.fault` | FaultRetrievalService | `get_events_data()`, `get_alarms_data()`, `get_event_types()` |

### Usage Examples

**Get device running config:**
```python
await ctx.dra.connect()
response = await ctx.dra.device_command.get_device_running_config(
    node_id="router-1",
    timeout=60.0,
)
if response.status.success:
    print(response.output)
```

**Stream device groups:**
```python
await ctx.dra.connect()
async for response in ctx.dra.device_grouping.get_device_groups(timeout=30.0):
    for group in response.groups:
        print(f"{group.groupID}: {group.groupName}")
```

**Get alarms:**
```python
await ctx.dra.connect()
async for response in ctx.dra.fault.get_alarms_data(
    device_ip="10.0.0.1",
    limit=100,
    timeout=30.0,
):
    for alarm in response.alarms:
        print(alarm)
```

### Comparison: Wrappers vs Raw Stubs

The wrappers eliminate boilerplate while preserving full type safety:

```python
# Before: Raw stub usage (verbose)
from cwai.adk.proto.dra.v2 import deviceCommand_pb2 as dc_pb2
from cwai.adk.proto.dra.v2 import deviceCommand_pb2_grpc as dc_grpc
from cwai.adk.proto.dra.v2 import draCommon_pb2 as common_pb2

await ctx.dra.connect()
stub = dc_grpc.DeviceCommandServiceStub(ctx.dra.channel)
request = dc_pb2.GetDeviceRunningConfigRequest(
    context=common_pb2.RequestContext(taskID=0, userID=0),
    nodeId="router-1",
)
response = await ctx.dra.call_unary(
    "get_device_running_config",
    stub.GetDeviceRunningConfig,
    request,
    timeout=60.0,
)

# After: Typed wrapper (clean)
await ctx.dra.connect()
response = await ctx.dra.device_command.get_device_running_config(
    node_id="router-1",
    timeout=60.0,
)
```

The wrappers are lazy-loaded and cached, so accessing `ctx.dra.device_command`
multiple times returns the same wrapper instance.

## Core API

The DRA client provides infrastructure for calling DRA methods. You create
gRPC stubs from the exposed channel and use `call_unary()` or `call_stream()`
to invoke methods with automatic metadata injection, tracing, and metrics.

**Most DRA methods use streaming** due to the gateway's fan-out pattern, where
requests are broadcast to all DRAs that implement the service. Use `call_stream()`
for these operations. Use `call_unary()` only for single-response methods like
`GetDeviceRunningConfig`.

### Channel

Access the gRPC channel to create stubs for any DRA service:

```python
from cwai.adk.proto.dra.v2 import deviceGrouping_pb2_grpc as dg_grpc

await ctx.dra.connect()
stub = dg_grpc.DeviceGroupingServiceStub(ctx.dra.channel)
```

### Streaming Calls (Preferred)

Use `call_stream()` for most DRA operations. The gateway fans out requests
to all DRAs implementing the service and streams back responses:

```python
async for response in ctx.dra.call_stream(
    "get_device_groups",    # name for tracing/metrics
    stub.GetDeviceGroups,   # gRPC method
    request,                # protobuf request
    timeout=30.0,
):
    # Each response comes from a different DRA
    dra_id = response.context.draID
    process(response)
```

### Unary Calls

Use `call_unary()` for single-response methods like `GetDeviceRunningConfig`,
which targets a specific device managed by a single DRA:

```python
response = await ctx.dra.call_unary(
    "get_device_running_config",
    stub.GetDeviceRunningConfig,
    request,
    timeout=30.0,
)
```

The `name` parameter is used for OpenTelemetry spans and metrics, enabling
observability for DRA calls.

## Operation Naming

The `name` parameter in `call_unary()` and `call_stream()` is used for tracing
spans and metrics. To ensure consistent, low-cardinality telemetry data,
operation names are validated against these rules:

| Rule | Requirement |
|------|-------------|
| Length | 3-64 characters |
| First character | Lowercase letter (`a-z`) |
| Allowed characters | Lowercase letters, numbers, underscores (`a-z`, `0-9`, `_`) |

Names should follow the `{verb}_{object}` pattern, describing the operation
being performed without including variable data like IDs.

### Valid Names

```python
"get_devices"           # verb + object
"get_device_groups"     # verb + compound object
"process_payment"       # verb + object
"fetch_running_config"  # verb + object
"list_interfaces_v2"    # version suffix is acceptable
```

### Invalid Names

| Name | Problem |
|------|---------|
| `"ab"` | Too short (minimum 3 characters) |
| `"Get_Devices"` | Uppercase letters not allowed |
| `"get-devices"` | Hyphens not allowed |
| `"get.devices"` | Dots not allowed |
| `"get devices"` | Spaces not allowed |
| `"123_devices"` | Must start with a letter |
| `"get_device_123"` | Avoid IDs — causes high cardinality |

High-cardinality names (containing IDs, timestamps, or other variable data)
make it difficult to aggregate metrics and analyze traces. Put variable
data in span attributes or log fields instead.

### Generic Method

For DRA functions when you don't have proto stubs, use `get_async_data()`:

```python
async for response in ctx.dra.get_async_data(
    func_name="getDeviceInfo",
    func_param={"device_id": "router-1"},
    timeout=30.0,
):
    print(f"From {response.dra_id}: {response.data}")
```

Returns `DRAResponse` objects with:
- `data` — Response payload as a dict
- `dra_id` — Which DRA produced this response
- `task_id` — Task ID echoed from request

## Recipes

Common DRA operations. For most use cases, prefer the **typed service wrappers**
described above. The recipes below demonstrate the lower-level stub API, which
is useful when you need more control or are working with custom proto definitions.

### Using Typed Wrappers (Recommended)

```python
# Device groups
await ctx.dra.connect()
async for response in ctx.dra.device_grouping.get_device_groups(timeout=30.0):
    for group in response.groups:
        print(f"{group.groupID}: {group.groupName}")

# Device group members
async for response in ctx.dra.device_grouping.get_device_group_members(
    group_id="dc-west", timeout=30.0
):
    for device in response.devices:
        print(f"{device.deviceID}: {device.deviceName}")

# Device config
response = await ctx.dra.device_command.get_device_running_config(
    node_id="router-1", timeout=60.0
)
print(response.output)
```

### Using Raw Stubs (Advanced)

For custom protos or when you need direct control, import the proto stubs:

```python
from cwai.adk.proto.dra.v2 import deviceGrouping_pb2 as dg_pb2
from cwai.adk.proto.dra.v2 import deviceGrouping_pb2_grpc as dg_grpc
from cwai.adk.proto.dra.v2 import deviceCommand_pb2 as dc_pb2
from cwai.adk.proto.dra.v2 import deviceCommand_pb2_grpc as dc_grpc
from cwai.adk.proto.dra.v2 import draCommon_pb2 as common_pb2
```

### Get Device Groups

Stream device groups from all DRAs:

```python
await ctx.dra.connect()
stub = dg_grpc.DeviceGroupingServiceStub(ctx.dra.channel)

request = dg_pb2.GetDeviceGroupsServiceRequest(
    context=common_pb2.RequestContext(taskID=0, userID=0)
)

async for response in ctx.dra.call_stream(
    "get_device_groups",
    stub.GetDeviceGroups,
    request,
    timeout=30.0,
):
    dra_id = response.context.draID
    for group in response.groups:
        print(f"[{dra_id}] {group.groupID}: {group.groupName}")
```

### Get Device Group Members

Stream devices belonging to a group:

```python
await ctx.dra.connect()
stub = dg_grpc.DeviceGroupingServiceStub(ctx.dra.channel)

request = dg_pb2.GetDeviceGroupMembersRequest(
    context=common_pb2.RequestContext(taskID=0, userID=0),
    groupID="dc-west",
)

async for response in ctx.dra.call_stream(
    "get_device_group_members",
    stub.GetDeviceGroupMembers,
    request,
    timeout=30.0,
):
    dra_id = response.context.draID
    for device in response.devices:
        print(f"[{dra_id}] {device.deviceID}: {device.deviceName}")
```

### Get Device Running Config

Retrieve running configuration for a device. This is one of the few unary
methods since configs come from a single authoritative DRA:

```python
await ctx.dra.connect()
stub = dc_grpc.DeviceCommandServiceStub(ctx.dra.channel)

request = dc_pb2.GetDeviceRunningConfigRequest(
    context=common_pb2.RequestContext(taskID=0, userID=0),
    nodeId="router-1",
)

response = await ctx.dra.call_unary(
    "get_device_running_config",
    stub.GetDeviceRunningConfig,
    request,
    timeout=60.0,
)

if response.status.success:
    print(response.output)
else:
    print(f"Failed: {response.status.error}")
```

## Streaming vs Unary

Most DRA methods are **streaming** because the gateway fans out requests to
multiple DRAs. Each `async for` iteration yields a response from one DRA.
Use `call_stream()` for these operations.

Some methods like `GetDeviceRunningConfig` are **unary** because device
configs come from a single authoritative source. Use `call_unary()` for
these — they return directly without iteration.

## Timeout

All methods accept an optional `timeout` parameter (in seconds):

```python
async for response in ctx.dra.call_stream(
    "get_device_groups", stub.GetDeviceGroups, request, timeout=30.0
):
    process(response)

# Longer timeout for config retrieval
config = await ctx.dra.call_unary(
    "get_device_running_config", stub.GetDeviceRunningConfig, request, timeout=60.0
)
```

If no timeout is specified, gRPC defaults apply. The DRA Gateway has a 300
second default timeout.

## Error Handling

All methods raise exceptions on failure:

```python
from cwai.adk.errors import DRAError, DRAConnectionError, DRARequestError

try:
    async for response in ctx.dra.call_stream(
        "get_device_groups", stub.GetDeviceGroups, request
    ):
        process(response)
except DRAConnectionError as e:
    # Gateway unreachable or client not connected
    ctx.log.error(f"DRA connection failed: {e}")
except DRARequestError as e:
    # gRPC error during request
    ctx.log.error(f"DRA request failed: {e}")
```

Error hierarchy:
- `DRAError` — Base class for all DRA errors
- `DRAConnectionError` — Transport/connection failures
- `DRARequestError` — gRPC errors during request execution

## Observability

The DRA client emits OpenTelemetry metrics for monitoring:

| Metric | Labels | Description |
|--------|--------|-------------|
| `cwai.agent.dra.request.count` | `operation`, `status` | Request counter |
| `cwai.agent.dra.request.duration` | `operation` | Latency histogram (ms) |
| `cwai.agent.dra.error.count` | `operation`, `error_type` | Error counter |
| `cwai.agent.dra.response.count` | `operation`, `dra_id` | Per-DRA response counter |

The `operation` label uses the `name` parameter from `call_unary()` / `call_stream()`.

## Testing

Use `MockDRAClient` for unit tests:

```python
from cwai.adk.testing import mock_context, MockDRAClient

async def test_my_agent():
    mock_dra = MockDRAClient()

    # Configure mock responses for call_unary()
    mock_dra.call_unary_responses["get_device_config"] = {"output": "hostname router-1"}

    # Configure mock responses for call_stream()
    mock_dra.call_stream_responses["get_device_groups"] = [
        {"groups": [{"groupID": "g1", "groupName": "Group 1"}]},
    ]

    ctx = mock_context(dra_client=mock_dra)

    # Test your agent
    result = await my_handler(ctx, msg)

    # Verify calls were made
    assert len(mock_dra.call_unary_invocations) == 1
    assert len(mock_dra.call_stream_invocations) == 1
```

### Mock Configuration

**Unary responses:**
```python
mock_dra.call_unary_responses["operation_name"] = response_object
```

**Streaming responses:**
```python
mock_dra.call_stream_responses["operation_name"] = [response1, response2, ...]
```

**Generic responses (get_async_data):**
```python
from cwai.adk.client.dra import DRAResponse

mock_dra.async_data_responses = [
    DRAResponse(data={"key": "value"}, dra_id="mock-dra", task_id=0),
]
```

**Error injection:**
```python
mock_dra.call_unary_error = "Simulated failure"   # For call_unary()
mock_dra.call_stream_error = "Stream failed"      # For call_stream()
mock_dra.get_async_data_error = "Function error"  # For get_async_data()
mock_dra.error = "Global failure"                 # For all methods
```
