"""Public constants for Crosswork AI ADK."""

# Platform sender ID used for routing-agent and user-originated messages.
ROUTING_AGENT_ID = 0
