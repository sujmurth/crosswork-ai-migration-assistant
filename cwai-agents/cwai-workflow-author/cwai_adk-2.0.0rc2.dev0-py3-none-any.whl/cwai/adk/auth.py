"""Authentication types and JWT parsing for internal platform tokens."""

from __future__ import annotations

import base64
import json
import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class GroupRoles:
    """Roles a user holds within a specific group."""

    group: str
    roles: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class Caller:
    """Identity of the user who initiated the agent task.

    Extracted from the authentication token provided by the platform.
    Available as ``ctx.caller`` inside agent handlers. All fields default
    to empty values when not present in the token.
    """

    username: str = ""
    user_id: str = ""
    client_ip: str = ""
    permissions: list[GroupRoles] = field(default_factory=list)


def parse_jwt(token: str | None) -> Caller | None:
    """Parse the internal platform JWT without signature verification.

    Returns None if the token is missing or malformed. Does not validate
    expiry or signature - the token is trusted within the cluster.
    """
    if not token:
        return None
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        # Decode the payload (second part), adding padding as needed
        payload_b64 = parts[1]
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
    except Exception:
        logger.warning("Failed to decode JWT payload", exc_info=True)
        return None

    try:
        attr = payload.get("attr", {})
        raw_username = attr.get("fs-username", [])
        raw_userid = attr.get("fs-userid", [])

        # Handle both list and plain string formats defensively
        username = (
            raw_username
            if isinstance(raw_username, str)
            else (raw_username[0] if raw_username else "")
        )
        user_id = (
            raw_userid
            if isinstance(raw_userid, str)
            else (raw_userid[0] if raw_userid else "")
        )

        permissions: list[GroupRoles] = []
        for entry in attr.get("fs-permissions", []):
            group = entry.get("group", "")
            roles = entry.get("roles", [])
            if group or roles:
                permissions.append(GroupRoles(group=group, roles=roles))

        return Caller(
            username=username,
            user_id=user_id,
            client_ip=attr.get("fs-clientip", ""),
            permissions=permissions,
        )
    except Exception:
        logger.warning("Failed to extract claims from JWT payload", exc_info=True)
        return None
