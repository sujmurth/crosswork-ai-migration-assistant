"""Configuration types for the ADK."""

from __future__ import annotations

import logging
import os
import ssl
from dataclasses import dataclass
from pathlib import Path

import grpc

logger = logging.getLogger("cwai.adk.config")
"""Logger for configuration-related messages."""

# Default cert paths matching platform K8s mount convention.
DEFAULT_CA_CERT_PATH = "/app/certs/ca/ca.crt"
"""Default path to the CA certificate file."""
DEFAULT_CLIENT_CERT_PATH = "/app/certs/client/tls.crt"
"""Default path to the client certificate file."""
DEFAULT_CLIENT_KEY_PATH = "/app/certs/client/tls.key"
"""Default path to the client private key file."""

# STM supports up to 100MB per entity. The gRPC default (4MB) is too
# small for responses containing many entries. 110MB gives headroom
# for protobuf framing. This ceiling is safe for all clients — gRPC
# only allocates memory for actual message sizes.
_MAX_GRPC_MESSAGE_BYTES = 110 * 1024 * 1024  # 110MB


def default_grpc_channel_options() -> list[tuple[str, int]]:
    """Return gRPC channel options that all ADK clients should use.

    Sets max send/receive message sizes high enough for the largest
    payloads the platform supports (STM entities up to 100MB).

    Includes gRPC keepalive settings so clients can detect dead connections quickly.
    Without keepalives, a silently broken TCP connection can cause
    the control loop to hang until the server-side runtime liveness timeout is reached.
    """
    return [
        ("grpc.max_receive_message_length", _MAX_GRPC_MESSAGE_BYTES),
        ("grpc.max_send_message_length", _MAX_GRPC_MESSAGE_BYTES),
        # Keepalive: detect dead connections before the 120s liveness
        # timeout fires on the server side.
        ("grpc.keepalive_time_ms", 30_000),
        ("grpc.keepalive_timeout_ms", 10_000),
        ("grpc.keepalive_permit_without_calls", 1),
        ("grpc.http2.max_pings_without_data", 0),
    ]


@dataclass(frozen=True)
class TLSConfig:
    """TLS configuration for HTTP and gRPC clients.

    Controls certificate verification for internal service communication
    (HTTPS) and mutual TLS for gRPC channels. Constructed once via
    ``from_env()`` and threaded through the framework.

    Args:
        ca_cert_path: Path to CA certificate file. Used by both HTTP
            (server verification) and gRPC (root certificates).
        verify: Whether to verify server certificates for HTTP clients.
            Set to False to skip verification (insecure, development only).
        client_cert_path: Path to client certificate for mTLS.
        client_key_path: Path to client private key for mTLS.
        ssl_target_name_override: Override for gRPC SSL host verification.
            Useful when connecting via IP but the certificate uses DNS names.

    Examples:
        # From platform environment variables (typical usage)
        tls = TLSConfig.from_env()

        # Manual construction
        tls = TLSConfig(
            ca_cert_path="/app/certs/ca/ca.crt",
            client_cert_path="/app/certs/client/tls.crt",
            client_key_path="/app/certs/client/tls.key",
        )

        # Skip HTTP verification (development only)
        tls = TLSConfig(verify=False)
    """

    ca_cert_path: str | None = None
    """Path to the CA certificate file."""
    verify: bool = True
    """Controls whether HTTP clients verify server certificates."""
    client_cert_path: str | None = None
    """Path to the client certificate file for mTLS."""
    client_key_path: str | None = None
    """Path to the client private key file for mTLS."""
    ssl_target_name_override: str | None = None
    """Host name to use for gRPC SSL verification instead of the host name or IP address used to connect."""

    @classmethod
    def from_env(cls, *, ca_cert_path: str | None = None) -> TLSConfig:
        """Create config from environment variables.

        Reads TLS settings from standard platform environment variables.
        An explicit ``ca_cert_path`` (for example, from the handshake) takes
        precedence over the environment variable.

        Environment variables:
            FORESIGHT_CA_CERT_PATH: CA cert path
                (default: /app/certs/ca/ca.crt).
            FORESIGHT_CLIENT_CERT_PATH: Client cert path
                (default: /app/certs/client/tls.crt).
            FORESIGHT_CLIENT_KEY_PATH: Client key path
                (default: /app/certs/client/tls.key).
            FORESIGHT_SSL_TARGET_NAME: SSL target name override.
            CWAI_TLS_SKIP_VERIFY: ``"true"`` to skip HTTP cert verification.

        Args:
            ca_cert_path: Explicit CA cert path override. When provided,
                this is used instead of the ``FORESIGHT_CA_CERT_PATH``
                environment variable.

        Returns:
            TLSConfig instance.
        """
        skip_verify = os.environ.get("CWAI_TLS_SKIP_VERIFY", "").lower() == "true"

        resolved_ca = ca_cert_path or os.environ.get(
            "FORESIGHT_CA_CERT_PATH", DEFAULT_CA_CERT_PATH
        )

        config = cls(
            ca_cert_path=resolved_ca,
            verify=not skip_verify,
            client_cert_path=os.environ.get(
                "FORESIGHT_CLIENT_CERT_PATH", DEFAULT_CLIENT_CERT_PATH
            ),
            client_key_path=os.environ.get(
                "FORESIGHT_CLIENT_KEY_PATH", DEFAULT_CLIENT_KEY_PATH
            ),
            ssl_target_name_override=os.environ.get("FORESIGHT_SSL_TARGET_NAME"),
        )

        logger.debug(
            "TLSConfig.from_env() resolved configuration",
            extra={
                "ca_cert_path": config.ca_cert_path,
                "client_cert_path": config.client_cert_path,
                "client_key_path": config.client_key_path,
                "ssl_target_name_override": config.ssl_target_name_override,
                "verify": config.verify,
            },
        )

        return config

    def httpx_verify(self) -> ssl.SSLContext | bool:
        """Return the value to pass to httpx client's ``verify`` parameter.

        Returns:
            False if verification is disabled, True to use system CA bundle, or an SSLContext configured with the custom CA certificate.
        """
        if not self.verify:
            return False
        if self.ca_cert_path:
            return ssl.create_default_context(cafile=self.ca_cert_path)
        return True

    def load_grpc_credentials(self) -> grpc.ChannelCredentials:
        """Load certificates and create gRPC channel credentials.

        Returns:
            gRPC SSL channel credentials configured with the CA certificate and client certificate/key pair.

        Raises:
            FileNotFoundError: If any certificate file is missing.
        """
        ca_cert = Path(self.ca_cert_path).read_bytes() if self.ca_cert_path else b""
        client_cert = (
            Path(self.client_cert_path).read_bytes() if self.client_cert_path else None
        )
        client_key = (
            Path(self.client_key_path).read_bytes() if self.client_key_path else None
        )

        logger.debug(
            "Loading gRPC credentials",
            extra={
                "ca_cert_path": self.ca_cert_path,
                "ca_cert_size": len(ca_cert) if ca_cert else 0,
                "client_cert_path": self.client_cert_path,
                "client_cert_size": len(client_cert) if client_cert else 0,
                "client_key_path": self.client_key_path,
                "client_key_size": len(client_key) if client_key else 0,
            },
        )

        # Log if CA cert exists on disk
        if self.ca_cert_path:
            ca_path = Path(self.ca_cert_path)
            logger.debug(
                "CA cert file info",
                extra={
                    "exists": ca_path.exists(),
                    "is_file": ca_path.is_file() if ca_path.exists() else False,
                },
            )

        return grpc.ssl_channel_credentials(
            root_certificates=ca_cert or None,
            private_key=client_key,
            certificate_chain=client_cert,
        )

    def grpc_channel_options(self) -> list[tuple[str, str | int]]:
        """Get gRPC channel options including message size limits.

        Always includes max send/receive message size options. Adds
        SSL target name override when configured.

        Returns:
            List of channel options suitable for ``grpc.aio.secure_channel`` or ``grpc.aio.insecure_channel``.
        """
        options: list[tuple[str, str | int]] = list(default_grpc_channel_options())
        if self.ssl_target_name_override:
            options.append(
                ("grpc.ssl_target_name_override", self.ssl_target_name_override)
            )
        return options
