"""State tracker protocol and factory.

Abstracts state persistence strategy so the runner doesn't need to
know whether snapshot or delta mode is active.
"""

import copy
import logging
from typing import Any, Protocol

import jsonpatch

from cwai.adk._framework.state_entries import (
    DeltaEntry,
    SnapshotEntry,
    deserialize_entry,
    serialize_delta,
    serialize_snapshot,
)
from cwai.adk._framework.state_serializer import deserialize_state, serialize_state
from cwai.adk.client import STMClientProtocol
from cwai.adk.observability.metrics import record_state_persist
from cwai.adk.types.stm import StateEntry

logger = logging.getLogger("cwai.adk.framework.state_tracker")

# Emit a warning when serialized state exceeds this size.
_LARGE_STATE_THRESHOLD = 100 * 1024  # 100KB

# Write a full snapshot every N persists to bound recovery time.
_SNAPSHOT_INTERVAL = 20


class StateTrackerProtocol(Protocol):
    """Interface for state persistence strategies."""

    @property
    def state(self) -> dict[str, Any]:
        """The current state dict. Mutable by the handler."""
        ...

    def prepare(self) -> None:
        """Capture a baseline for dirty checking before handler invocation."""
        ...

    async def persist_if_dirty(
        self,
        stm_client: STMClientProtocol,
        task_log: Any,
    ) -> None:
        """Persist state to STM if it has changed since last prepare()."""
        ...


class SnapshotStateTracker:
    """State tracker that persists full snapshots on each write.

    This is the original persistence strategy. Each persist writes the
    entire ctx.state dict as a JSON blob. Dirty checking compares
    serialized bytes.
    """

    def __init__(
        self, stm_key: str, initial_state: dict[str, Any], agent_type: str = ""
    ) -> None:
        self._stm_key = stm_key
        self._state = initial_state
        self._last_bytes: bytes | None = None
        self._agent_type = agent_type

    @property
    def state(self) -> dict[str, Any]:
        return self._state

    def prepare(self) -> None:
        # Snapshot mode uses byte comparison, no pre-handler work needed.
        pass

    async def persist_if_dirty(
        self,
        stm_client: STMClientProtocol,
        task_log: Any,
    ) -> None:
        current_bytes = serialize_state(self._state)

        if current_bytes == self._last_bytes:
            return  # No changes

        if len(current_bytes) > _LARGE_STATE_THRESHOLD and task_log:
            task_log.warning(
                "ctx.state serialized size exceeds threshold, consider moving "
                "large data to ctx.stm",
                extra={
                    "stm_key": self._stm_key,
                    "size": len(current_bytes),
                    "size_kb": len(current_bytes) // 1024,
                },
            )

        await stm_client.add(self._stm_key, current_bytes)
        self._last_bytes = current_bytes
        record_state_persist(self._agent_type, len(current_bytes), "snapshot")

        if task_log:
            task_log.debug(
                "State persisted to STM (snapshot)",
                extra={"stm_key": self._stm_key, "size": len(current_bytes)},
            )

    def set_baseline(self, state_bytes: bytes) -> None:
        """Set baseline after initial load or recovery."""
        self._last_bytes = state_bytes


class DeltaStateTracker:
    """State tracker that persists changes as RFC 6902 JSON Patch deltas.

    Before each handler invocation, prepare() deep-copies the state.
    After the handler returns, persist_if_dirty() diffs the copy
    against the current state using jsonpatch and writes only the
    resulting patch ops.

    Writes a full snapshot every _SNAPSHOT_INTERVAL persists and
    always on the first persist.
    """

    def __init__(
        self, stm_key: str, initial_state: dict[str, Any], agent_type: str = ""
    ) -> None:
        self._stm_key = stm_key
        self._state = initial_state
        self._baseline: dict[str, Any] | None = None
        self._persist_count = 0
        self._agent_type = agent_type

    @property
    def state(self) -> dict[str, Any]:
        return self._state

    def prepare(self) -> None:
        """Deep-copy the current state as the pre-handler baseline."""
        self._baseline = copy.deepcopy(self._state)

    def _should_write_snapshot(self) -> bool:
        """Return True if the next persist should be a full snapshot."""
        if self._persist_count == 0:
            return True
        return self._persist_count % _SNAPSHOT_INTERVAL == 0

    def _compute_delta_ops(self) -> list[dict[str, Any]] | None:
        """Compute JSON Patch ops from baseline, or None if unchanged."""
        if self._baseline is None:
            return [{"op": "replace", "path": "", "value": self._state}]
        patch = jsonpatch.make_patch(self._baseline, self._state)
        if not patch.patch:
            return None
        return patch.patch

    async def persist_if_dirty(
        self,
        stm_client: STMClientProtocol,
        task_log: Any,
    ) -> None:
        if self._baseline is None:
            # prepare() was never called — write a snapshot.
            entry_bytes = serialize_snapshot(self._state)
            await stm_client.add(self._stm_key, entry_bytes)
            self._persist_count += 1
            record_state_persist(self._agent_type, len(entry_bytes), "snapshot")
            return

        if self._should_write_snapshot():
            # Check if state actually changed before writing.
            ops = self._compute_delta_ops()
            if ops is None:
                return  # No changes
            entry_bytes = serialize_snapshot(self._state)
            entry_type = "snapshot"
        else:
            ops = self._compute_delta_ops()
            if ops is None:
                return  # No changes
            patch = jsonpatch.JsonPatch(ops)
            entry_bytes = serialize_delta(patch)
            entry_type = "delta"

        if len(entry_bytes) > _LARGE_STATE_THRESHOLD and task_log:
            task_log.warning(
                "ctx.state entry size exceeds threshold, consider moving large data "
                "to ctx.stm",
                extra={
                    "stm_key": self._stm_key,
                    "size": len(entry_bytes),
                    "size_kb": len(entry_bytes) // 1024,
                },
            )

        await stm_client.add(self._stm_key, entry_bytes)
        self._persist_count += 1
        record_state_persist(self._agent_type, len(entry_bytes), entry_type)

        # Re-capture baseline for next persist.
        self.prepare()

        if task_log:
            task_log.debug(
                "State persisted to STM",
                extra={
                    "stm_key": self._stm_key,
                    "size": len(entry_bytes),
                    "persist_count": self._persist_count,
                    "entry_type": entry_type,
                },
            )


def restore_snapshot_entries(entries: list[StateEntry]) -> dict[str, Any]:
    """Restore state from snapshot-mode STM entries.

    Load the latest entry payload as a full state dict.
    """
    if not entries:
        return {}
    return deserialize_state(entries[-1].payload)


def restore_delta_entries(entries: list[StateEntry]) -> dict[str, Any]:
    """Restore state from delta-mode STM entries.

    Find the latest snapshot entry, then replay all delta entries
    after it. If no snapshot is found, start from empty dict and
    replay all deltas.
    """
    if not entries:
        return {}

    # Find the latest snapshot to start from.
    snapshot_idx = -1
    parsed: list[SnapshotEntry | DeltaEntry] = []
    for i, entry in enumerate(entries):
        parsed_entry = deserialize_entry(entry.payload)
        parsed.append(parsed_entry)
        if isinstance(parsed_entry, SnapshotEntry):
            snapshot_idx = i

    if snapshot_idx >= 0:
        state = dict(parsed[snapshot_idx].data)  # type: ignore[union-attr]
        replay_from = snapshot_idx + 1
    else:
        state = {}
        replay_from = 0

    # Replay deltas after the snapshot.
    for i in range(replay_from, len(parsed)):
        entry = parsed[i]
        if isinstance(entry, DeltaEntry):
            state = entry.apply(state)
        elif isinstance(entry, SnapshotEntry):
            # Shouldn't happen after we found the latest, but be safe.
            state = dict(entry.data)

    return state


def create_state_tracker(
    mode: str,
    stm_key: str,
    initial_state: dict[str, Any],
    agent_type: str = "",
) -> SnapshotStateTracker | DeltaStateTracker:
    """Create a state tracker for the given persistence mode.

    Raises:
        ValueError: If mode is unknown.
    """
    if mode == "snapshot":
        return SnapshotStateTracker(stm_key, initial_state, agent_type)
    if mode == "delta":
        return DeltaStateTracker(stm_key, initial_state, agent_type)
    raise ValueError(f"Unknown state persistence mode: {mode!r}")
