"""Per-task state tracked by the framework."""

import asyncio
from dataclasses import dataclass
from typing import Any

from cwai.adk.context import Context


@dataclass
class TaskState:
    """State for a single running task."""

    agent_id: str
    async_task: asyncio.Task[Any]
    context: Context
