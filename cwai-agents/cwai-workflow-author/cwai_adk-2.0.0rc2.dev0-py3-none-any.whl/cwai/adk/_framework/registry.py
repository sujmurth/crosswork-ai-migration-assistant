"""Task registry: tracks active tasks and routes inbound messages."""

import asyncio
import logging

from cwai.adk._framework.task_state import TaskState
from cwai.adk.observability.metrics import record_task_active

logger = logging.getLogger("cwai.adk.framework.registry")


class TaskRegistry:
    """Tracks active tasks and routes messages to them."""

    def __init__(self) -> None:
        self._tasks: dict[str, TaskState] = {}

    def add(self, state: TaskState) -> None:
        self._tasks[state.agent_id] = state
        record_task_active(state.context.agent_type, delta=1)
        logger.debug(
            "Task added",
            extra={"agent_id": state.agent_id, "active_count": len(self._tasks)},
        )

    def remove(self, agent_id: str) -> None:
        state = self._tasks.pop(agent_id, None)
        if state is not None:
            record_task_active(state.context.agent_type, delta=-1)
        logger.debug(
            "Task removed",
            extra={"agent_id": agent_id, "active_count": len(self._tasks)},
        )

    def get(self, agent_id: str) -> TaskState | None:
        return self._tasks.get(agent_id)

    @property
    def active_count(self) -> int:
        return len(self._tasks)

    async def wait_all(self, timeout: float = 30) -> None:
        """Wait for all active tasks to complete, with timeout."""
        if not self._tasks:
            return
        tasks = [s.async_task for s in self._tasks.values()]
        await asyncio.wait(tasks, timeout=timeout)
