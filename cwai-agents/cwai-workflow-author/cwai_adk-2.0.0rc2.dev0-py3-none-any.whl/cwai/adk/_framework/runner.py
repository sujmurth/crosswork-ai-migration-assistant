"""Agent dispatch loop and per-task execution wrapper."""

import asyncio
import json
import logging
import os
import signal
import time
from typing import Any

import httpx
from opentelemetry import trace

from cwai.adk import features
from cwai.adk._framework.message_journal import (
    HANDLER_TYPE_ON_MESSAGE,
    JournaledMessage,
    RecoveryJournal,
    recovery_stm_key,
    restore_recovery_journal,
    serialize_message_received,
    serialize_state_checkpoint,
)
from cwai.adk._framework.registry import TaskRegistry
from cwai.adk._framework.state_serializer import serialize_state
from cwai.adk._framework.state_tracker import (
    DeltaStateTracker,
    SnapshotStateTracker,
    create_state_tracker,
    restore_delta_entries,
    restore_snapshot_entries,
)
from cwai.adk._framework.task_state import TaskState
from cwai.adk._framework.transport import (
    PlatformTransport,
    TaskDispatch,
    TaskRemoval,
)
from cwai.adk.auth import parse_jwt
from cwai.adk.client import STMClientProtocol
from cwai.adk.client.llm import LLMClient
from cwai.adk.config import TLSConfig
from cwai.adk.context import Context
from cwai.adk.errors import STMAlreadyExistsError, TransportClosed
from cwai.adk.observability.logging import get_task_logger
from cwai.adk.observability.metrics import (
    record_message_received,
    record_state_recovery,
    record_task_completed,
)
from cwai.adk.observability.trace_events import record_content_event
from cwai.adk.request_context import RequestContext
from cwai.adk.types import AssistantMessage, Message, MessageType, Result

logger = logging.getLogger("cwai.adk.framework.runner")
tracer = trace.get_tracer("cwai.adk.framework.runner")

_SHUTDOWN_TIMEOUT = 30  # seconds to wait for in-flight tasks on shutdown


class _OnDemandQueue:
    """Message queue that fetches on-demand from the transport.

    Satisfies the MessageQueue protocol. Each call to get() issues a
    single recv_message() RPC - the transport (and server) hold messages
    until the handler is ready.
    """

    def __init__(self, transport: "PlatformTransport", agent_id: str) -> None:
        self._transport = transport
        self._agent_id = agent_id

    async def get(self, *, sender_id: int | None = None) -> Message:
        # On task removal, the runner cancels this task's asyncio.Task.
        # CancelledError (BaseException) propagates through the gRPC await
        # without being caught by the transport's AioRpcError handler.
        return await self._transport.recv_message(self._agent_id, sender_id=sender_id)


async def run_agent(
    transport: PlatformTransport | None = None,
    *,
    shutdown_event: asyncio.Event | None = None,
    catalog: dict[str, Any] | None = None,
) -> None:
    """Run the main agent dispatch loop.

    Open a platform connection, dispatch tasks to handlers resolved
    from the catalog, and route inbound messages. Run until a shutdown
    signal is received or the injected shutdown_event is set.

    Handlers are resolved per-task by matching ``TaskDispatch.agent_type``
    against catalog entry names.
    """
    if not catalog:
        raise ValueError("catalog must contain at least one handler")
    if transport is None:
        raise ValueError("transport is required")

    registry = TaskRegistry()

    loop = asyncio.get_running_loop()
    shutdown = asyncio.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, shutdown.set)

    # If caller provides a shutdown event, propagate it to ours.
    if shutdown_event is not None:

        async def _watch_external() -> None:
            await shutdown_event.wait()
            shutdown.set()

        asyncio.create_task(_watch_external())

    await transport.connect()
    names = list(catalog.keys())
    logger.info("Agent ready", extra={"handlers": names})

    try:
        while not shutdown.is_set():
            # Race recv() against the shutdown event so we don't block
            # forever after a signal arrives.
            recv_task = asyncio.create_task(transport.recv())
            shutdown_task = asyncio.create_task(shutdown.wait())

            done, _ = await asyncio.wait(
                {recv_task, shutdown_task}, return_when=asyncio.FIRST_COMPLETED
            )

            # Clean up the loser
            if recv_task not in done:
                recv_task.cancel()
                break
            shutdown_task.cancel()

            try:
                msg = recv_task.result()
            except TransportClosed:
                logger.info("Transport closed, shutting down")
                break

            if isinstance(msg, TaskDispatch):
                _dispatch_task(msg, registry, transport, catalog=catalog)
            elif isinstance(msg, TaskRemoval):
                _handle_removal(msg, registry)
    finally:
        logger.info(
            "Shutting down",
            extra={"active_tasks": registry.active_count},
        )
        # Continue draining control messages (e.g. TaskRemoval) while
        # waiting for in-flight handlers to complete.
        if registry.active_count > 0:
            drain_task = asyncio.create_task(
                _drain_pending(transport, registry, catalog)
            )
            try:
                await registry.wait_all(timeout=_SHUTDOWN_TIMEOUT)
            finally:
                drain_task.cancel()
                try:
                    await drain_task
                except asyncio.CancelledError:
                    pass
        else:
            await registry.wait_all(timeout=_SHUTDOWN_TIMEOUT)
        await transport.close()


async def _drain_pending(
    transport: PlatformTransport,
    registry: TaskRegistry,
    catalog: dict[str, Any],
) -> None:
    """Continuously route queued transport messages to in-flight handlers.

    Runs as a background task alongside ``registry.wait_all`` so that
    messages the transport data-loop delivers *after* the main recv loop
    exits still reach the waiting handlers.  Cancelled once all tasks
    complete or the shutdown timeout expires.
    """
    while True:
        try:
            msg = await asyncio.wait_for(transport.recv(), timeout=0.5)
        except TimeoutError:
            continue
        except TransportClosed:
            break

        if isinstance(msg, TaskDispatch):
            _dispatch_task(msg, registry, transport, catalog=catalog)
        elif isinstance(msg, TaskRemoval):
            _handle_removal(msg, registry)


def _handle_removal(
    removal: TaskRemoval,
    registry: TaskRegistry,
) -> None:
    """Cancel and clean up an agent instance on REMOVE_AGENT."""
    agent_id = removal.agent_id
    state = registry.get(agent_id)
    if state is None:
        logger.warning(
            "REMOVE_AGENT for unknown task, ignoring",
            extra={"agent_id": agent_id},
        )
        return

    logger.info("Removing agent", extra={"agent_id": agent_id})
    state.async_task.cancel()
    registry.remove(agent_id)


def _dispatch_task(
    dispatch: TaskDispatch,
    registry: TaskRegistry,
    transport: PlatformTransport,
    *,
    catalog: dict[str, Any],
) -> None:
    """Build context, spawn handler as asyncio.Task, register in registry.

    Resolves the handler from the catalog by matching
    ``dispatch.agent_type`` against catalog entry names.
    """
    # Avoid circular import with agent module
    from cwai.adk.agent import AgentEntry, HandlerType

    # Resolve the main handler for this task from the catalog.
    entry: AgentEntry | None = catalog.get(dispatch.agent_type)
    if entry is None:
        # If only one handler is registered, use it regardless of name.
        # This supports testing scenarios where agent_type may not match.
        if len(catalog) == 1:
            entry = next(iter(catalog.values()))
        else:
            logger.error(
                "No handler found for agent type",
                extra={
                    "agent_type": dispatch.agent_type,
                    "available": list(catalog.keys()),
                },
            )
            return

    assert entry is not None  # narrowed above: early return if None
    is_run_handler = entry.handler_type == HandlerType.RUN

    logger.debug(
        "Dispatching task",
        extra={
            "agent_id": dispatch.agent_id,
            "agent_type": dispatch.agent_type,
            "handler_type": entry.handler_type.value,
        },
    )

    msg_queue = _OnDemandQueue(transport, dispatch.agent_id)

    request_ctx = RequestContext(
        agent_id=dispatch.agent_id,
        thread_id=dispatch.thread_id,
        agent_type=dispatch.agent_type,
        agent_instance_id=dispatch.agent_instance_id,
        auth_token=dispatch.auth_token,
    )
    if not dispatch.auth_token:
        logger.warning(
            "No auth token in task dispatch - DRA calls will lack RBAC context",
            extra={"agent_id": dispatch.agent_id},
        )

    # send_message backed by transport
    async def _send_message(
        agent: str,
        agent_id: int,
        *,
        user_message: str = "",
        system_message: str = "",
        type: MessageType = MessageType.REQUEST,
        reply_to: str = "",
    ) -> None:
        await transport.send_message(
            agent,
            agent_id,
            user_message=user_message,
            system_message=system_message,
            type=type,
            reply_to=reply_to,
            from_agent_id=int(dispatch.agent_id),
        )

    # spawn_agent backed by transport
    async def _spawn_agent(
        agent_type: str,
        *,
        user_message: str = "",
    ) -> int:
        return await transport.spawn_agent(
            agent_type,
            user_message=user_message,
            from_agent_id=int(dispatch.agent_id),
            thread_id=dispatch.thread_id,
        )

    # Create task-scoped logger.
    task_log = get_task_logger(
        task_id=dispatch.agent_id,
        corr_id=dispatch.thread_id,
        agent_type=dispatch.agent_type,
        agent_instance_id=dispatch.agent_instance_id,
    )

    # Build LLM client: use override if provided, otherwise build from proxy info.
    llm_client = dispatch._llm_override
    if llm_client is None and dispatch.llm_proxy_info:
        info = dispatch.llm_proxy_info
        # Use the cluster CA cert for TLS when available so the httpx
        # client trusts the internal llm-proxy certificate.
        http_client = httpx.AsyncClient(verify=dispatch.ca_cert_path or True)
        llm_client = LLMClient(
            base_url=info.base_url,
            virtual_key=info.virtual_key,
            request_context=request_ctx,
            http_client=http_client,
            log=task_log,
            models=info.models,
        )

    # STM client: use override if provided (for testing), otherwise create from URL.
    # Note: connect() is called in _run_task since _dispatch_task is synchronous.
    stm_client: STMClientProtocol | None = dispatch._stm_override
    if stm_client is None:
        stm_url = dispatch.stm_endpoint or os.environ.get("CWAI_STM_URL", "stm:50051")
        from cwai.adk.client.stm import STMClient

        stm_client = STMClient(stm_url, request_ctx, log=task_log)

    # TLS config for all internal clients (HTTP and gRPC).
    # Uses ca_cert_path from handshake when available, otherwise from env.
    tls_config = TLSConfig.from_env(ca_cert_path=dispatch.ca_cert_path)

    # State persistence tracking — created by _run_task after STM init
    # Use a mutable container so the save_state closure captures updates.
    tracker_ref: list[SnapshotStateTracker | DeltaStateTracker | None] = [None]

    # save_state callback for explicit checkpoints
    async def _save_state(ctx: Context) -> None:
        if stm_client is None or tracker_ref[0] is None:
            return
        await tracker_ref[0].persist_if_dirty(stm_client, task_log)

    # call_subagent closure: look up sub-agent in catalog and run it
    # with a child context. Only on_run handlers can be called as
    # sub-agents (on_message handlers return None to mean "waiting",
    # which is incompatible with synchronous local invocation).
    agent_catalog = catalog

    async def _call_subagent(
        agent_name: str,
        *,
        query: dict[str, Any] | None = None,
    ) -> Result:
        sub_entry: AgentEntry | None = agent_catalog.get(agent_name)
        if sub_entry is None:
            raise ValueError(f"Agent '{agent_name}' not found in catalog")
        if sub_entry.handler_type != HandlerType.RUN:
            raise ValueError(
                f"Agent '{agent_name}' is an on_message handler and "
                f"cannot be called as a sub-agent"
            )

        child_agent_id = f"{dispatch.agent_id}::{agent_name}"
        child_queue: asyncio.Queue[Message] = asyncio.Queue()
        child_queue.put_nowait(
            Message(
                type=MessageType.REQUEST,
                sender="agent",
                user_message=json.dumps(query or {}),
                query=query or {},
            )
        )

        # No-op send_message for sub-agents (they don't talk to the platform)
        async def _noop_send(
            a: str,
            a_id: int,
            *,
            user_message: str = "",
            system_message: str = "",
            type: MessageType = MessageType.REQUEST,
            reply_to: str = "",
        ) -> None:
            pass

        child_log = get_task_logger(
            task_id=child_agent_id,
            corr_id=dispatch.thread_id,
            agent_type=dispatch.agent_type,
            agent_instance_id=dispatch.agent_instance_id,
        )

        # Sub-agents log a warning if they try to send partial results.
        # They run synchronously in-process and don't have a platform
        # connection to send intermediate updates.
        async def _subagent_send_partial(
            message: AssistantMessage | None,
            data: dict[str, Any] | None,
        ) -> None:
            child_log.warning(
                "send_partial_result called from sub-agent; ignored. "
                "Sub-agents run synchronously and cannot send partial results "
                "to the platform."
            )

        child_ctx = Context(
            agent_id=child_agent_id,
            thread_id=dispatch.thread_id,
            agent_type=dispatch.agent_type,
            agent_instance_id=dispatch.agent_instance_id,
            settings={},
            _send_message_fn=_noop_send,
            _spawn_agent_fn=_spawn_agent,
            _remove_agent_fn=transport.remove_instance,
            _save_state_fn=lambda: asyncio.sleep(0),
            _call_subagent_fn=_call_subagent,
            _send_partial=_subagent_send_partial,
            _request_context=request_ctx,
            _tls_config=tls_config,
            _llm=llm_client,
            _http=dispatch._http_override,
            _stm=stm_client,
            _log=child_log,
            _message_queue=child_queue,
        )

        result = await sub_entry.handler(child_ctx, child_queue.get_nowait())
        if result is None:
            return Result()
        return result

    # send_partial callback for partial results
    async def _send_partial(
        message: AssistantMessage | None,
        data: dict[str, Any] | None,
    ) -> None:
        result = Result(message=message, data=data)
        await transport.send_result(
            dispatch.agent_id,
            result,
            final=False,
        )

    ctx = Context(
        agent_id=dispatch.agent_id,
        thread_id=dispatch.thread_id,
        agent_type=dispatch.agent_type,
        agent_instance_id=dispatch.agent_instance_id,
        settings=dispatch.settings,
        _send_message_fn=_send_message,
        _spawn_agent_fn=_spawn_agent,
        _remove_agent_fn=transport.remove_instance,
        _save_state_fn=lambda: _save_state(ctx),
        _call_subagent_fn=_call_subagent,
        _send_partial=_send_partial,
        _request_context=request_ctx,
        _tls_config=tls_config,
        _llm=llm_client,
        _http=dispatch._http_override,
        _stm=stm_client,
        _log=task_log,
        # on_run handlers get direct access to the message queue
        _message_queue=msg_queue if is_run_handler else None,
    )

    state = TaskState(
        agent_id=dispatch.agent_id,
        async_task=asyncio.create_task(
            _run_task(
                dispatch.agent_id,
                ctx,
                msg_queue,
                registry,
                transport,
                stm_client,
                tracker_ref,
                entry=entry,
            )
        ),
        context=ctx,
    )
    registry.add(state)


async def _run_task(
    agent_id: str,
    ctx: Context,
    queue: _OnDemandQueue,
    registry: TaskRegistry,
    transport: PlatformTransport,
    stm_client: STMClientProtocol | None,
    tracker_ref: list[SnapshotStateTracker | DeltaStateTracker | None],
    *,
    entry: Any,
) -> None:
    """Run handler execution for a single task.

    For on_message handlers: loops pulling messages from the queue and
    calling the handler until it returns a non-None Result.

    For on_run handlers: pulls the initial message, calls the handler
    once. The handler pulls additional messages via ctx.wait_for_message().
    """
    # Avoid circular import with agent module
    from cwai.adk.agent import HandlerType

    stm_key = f"{ctx.agent_type}:{ctx.agent_id}:state"
    recovery_key = recovery_stm_key(ctx.agent_type, ctx.agent_id)
    persistence_mode = features.get_state_persistence()
    is_run_handler = entry.handler_type == HandlerType.RUN
    is_message_handler = entry.handler_type == HandlerType.MESSAGE
    recovery_journal: RecoveryJournal | None = None
    recovered_initial_msg: Message | None = None
    replayed_on_message: JournaledMessage | None = None

    try:
        if stm_client is not None:
            # Connect before first-message selection so recovered tasks can inspect
            # the recovery journal before blocking on platform receive.
            if hasattr(stm_client, "connect"):
                await stm_client.connect()
            recovery_journal = await _init_recovery_journal(stm_client, recovery_key)
            if is_run_handler:
                recovered_initial_msg = recovery_journal.initial_message
            elif is_message_handler:
                replayed_on_message = recovery_journal.first_uncheckpointed_message(
                    handler_type=HANDLER_TYPE_ON_MESSAGE
                )
    except Exception as e:
        logger.error(
            "Task failed before initial message",
            extra={"agent_id": agent_id, "error": str(e)},
            exc_info=True,
        )
        try:
            await transport.send_fail(agent_id, str(e))
        except Exception:
            logger.error(
                "Failed to send failure notification",
                extra={"agent_id": agent_id},
                exc_info=True,
            )
        try:
            await transport.remove_instance(ctx.agent_type, agent_id)
        except Exception:
            logger.error(
                "Failed to remove instance after pre-start failure",
                extra={"agent_id": agent_id},
                exc_info=True,
            )
        await _cleanup_context_clients(ctx, stm_client)
        registry.remove(agent_id)
        return

    # Wait for first message to extract parent trace context, unless the
    # message was restored from the recovery journal.
    if recovered_initial_msg is not None:
        first_msg = recovered_initial_msg
    elif replayed_on_message is not None:
        first_msg = replayed_on_message.message
    else:
        try:
            first_msg = await queue.get()
        except TransportClosed:
            logger.debug("Transport closed before initial message")
            await transport.send_result(agent_id, Result(message=None), final=True)
            registry.remove(agent_id)
            await _cleanup_context_clients(ctx, stm_client)
            return

    if recovered_initial_msg is not None or replayed_on_message is not None:
        transport.remember_message_sender(agent_id, first_msg)
        # If the replayed message isn't a REQUEST, also restore sender from
        # the earliest REQUEST in the journal (e.g. initial user request that
        # was already checkpointed) so send_result knows the reply target.
        if (
            replayed_on_message is not None
            and first_msg.type != MessageType.REQUEST
            and recovery_journal is not None
        ):
            for seq in sorted(recovery_journal.messages_by_seq):
                journaled = recovery_journal.messages_by_seq[seq]
                if journaled.message.type == MessageType.REQUEST:
                    transport.remember_message_sender(agent_id, journaled.message)
                    break

    parent_ctx = getattr(first_msg, "_otel_parent_ctx", None)

    with tracer.start_as_current_span("task.execute", context=parent_ctx) as span:
        span.set_attribute("task.id", agent_id)
        span.set_attribute("agent.type", ctx.agent_type)
        # Add caller identity for trace filtering and RBAC debugging
        caller_user_name = ""
        if ctx._request_context and ctx._request_context.auth_token:
            caller = parse_jwt(ctx._request_context.auth_token)
            if caller:
                span.set_attribute("user.name", caller.username or "")
                span.set_attribute("user.id", caller.user_id or "")
                span.set_attribute("user.client_ip", caller.client_ip or "")
                caller_user_name = caller.username or ""
                permissions_json = (
                    json.dumps(
                        [
                            {"group": gr.group, "roles": gr.roles}
                            for gr in caller.permissions
                        ]
                    )
                    if caller.permissions
                    else "[]"
                )
                span.set_attribute("user.permissions", permissions_json)
                logger.info(
                    "Task caller identity",
                    extra={
                        "username": caller.username,
                        "user_id": caller.user_id,
                        "client_ip": caller.client_ip,
                        "permissions": permissions_json,
                    },
                )
        t0 = time.monotonic()
        try:
            on_message_first_seq: int | None = None

            if (
                stm_client is not None
                and is_run_handler
                and recovered_initial_msg is None
            ):
                await stm_client.add(
                    recovery_key,
                    serialize_message_received(first_msg, message_seq=0),
                )

            if stm_client is not None and is_message_handler:
                if replayed_on_message is not None:
                    on_message_first_seq = replayed_on_message.message_seq
                    logger.info(
                        "Recovered on_message invocation from journal",
                        extra={
                            "stm_key": recovery_key,
                            "message_seq": on_message_first_seq,
                        },
                    )
                else:
                    on_message_first_seq = (
                        recovery_journal.next_message_seq
                        if recovery_journal is not None
                        else 0
                    )
                    await stm_client.add(
                        recovery_key,
                        serialize_message_received(
                            first_msg,
                            message_seq=on_message_first_seq,
                            handler_type=HANDLER_TYPE_ON_MESSAGE,
                        ),
                    )

            # Initialize STM, restore state, and create tracker
            if stm_client is not None:
                tracker = await _init_stm(
                    ctx,
                    stm_client,
                    stm_key,
                    persistence_mode,
                    ctx.agent_type,
                )
                tracker_ref[0] = tracker
                # Point ctx.state at the tracker's state dict so handler
                # mutations are visible to the tracker.
                ctx.state = tracker.state
            else:
                tracker = None

            if entry.handler_type == HandlerType.RUN:
                result = await _run_on_run(entry.handler, ctx, first_msg, tracker)
            else:
                result = await _run_on_message(
                    entry.handler,
                    ctx,
                    first_msg,
                    queue,
                    stm_client,
                    tracker,
                    recovery_key=recovery_key,
                    recovery_journal=recovery_journal,
                    first_msg_seq=on_message_first_seq,
                )

            if not isinstance(result, Result):
                raise TypeError(
                    f"Handler must return Result, got {type(result).__name__}"
                )

            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("task.duration_ms", duration_ms)
            span.set_status(trace.StatusCode.OK)
            logger.debug(
                "Task complete",
                extra={
                    "agent_id": agent_id,
                    "duration_ms": round(duration_ms, 1),
                },
            )

            # Record task success metrics
            record_task_completed(
                ctx.agent_type, duration_ms, success=True, user_name=caller_user_name
            )

            # Auto-persist state after handler returns (if dirty)
            if stm_client is not None and tracker is not None:
                await tracker.persist_if_dirty(stm_client, ctx._log)

            with tracer.start_as_current_span("agent.send_result") as result_span:
                result_span.set_attribute("result.status", result.status.value)
                result_span.set_attribute(
                    "result.has_message", result.message is not None
                )
                result_span.set_attribute("result.has_data", result.data is not None)
                if result.message is not None and result.message.content:
                    record_content_event(
                        result_span,
                        "cwai.agent.result.message",
                        result.message.content,
                    )
                if result.data is not None:
                    try:
                        record_content_event(
                            result_span,
                            "cwai.agent.result.data",
                            json.dumps(result.data),
                        )
                    except Exception:
                        pass
                try:
                    await transport.send_result(agent_id, result, final=True)
                except Exception as e:
                    result_span.set_status(trace.StatusCode.ERROR, str(e))
                    result_span.record_exception(e)
                    raise

            # Tell platform to remove this instance now that we're done
            try:
                await transport.remove_instance(ctx.agent_type, agent_id)
            except Exception:
                logger.error(
                    "Failed to remove instance after result",
                    extra={"agent_id": agent_id},
                    exc_info=True,
                )

            # Delete STM on successful completion
            if stm_client is not None:
                await _cleanup_stm(stm_client, stm_key)
                await _cleanup_stm(stm_client, recovery_key)

        except Exception as e:
            duration_ms = (time.monotonic() - t0) * 1000
            span.set_attribute("task.duration_ms", duration_ms)
            span.set_status(trace.StatusCode.ERROR, str(e))
            span.record_exception(e)
            logger.error(
                "Task failed",
                extra={
                    "agent_id": agent_id,
                    "duration_ms": round(duration_ms, 1),
                    "error": str(e),
                },
            )

            # Record task failure metrics
            record_task_completed(
                ctx.agent_type, duration_ms, success=False, user_name=caller_user_name
            )

            await transport.send_fail(agent_id, str(e))
            # Remove instance even on failure - agent is done
            try:
                await transport.remove_instance(ctx.agent_type, agent_id)
            except Exception:
                logger.error(
                    "Failed to remove instance after failure",
                    extra={"agent_id": agent_id},
                    exc_info=True,
                )
            # Don't delete STM on failure — allows crash recovery
        finally:
            # Stop any children spawned by this agent (best-effort).
            # Bound to 5s so we don't hang during pod shutdown.
            try:
                await asyncio.wait_for(ctx._stop_all_children(), timeout=5.0)
            except (asyncio.CancelledError, Exception):
                logger.debug("_stop_all_children did not complete", exc_info=True)
            # Close any created clients
            await _cleanup_context_clients(ctx, stm_client)
            registry.remove(agent_id)


async def _run_on_message(
    handler: Any,
    ctx: Context,
    first_msg: Message,
    msg_queue: _OnDemandQueue,
    stm_client: STMClientProtocol | None,
    tracker: SnapshotStateTracker | DeltaStateTracker | None,
    *,
    recovery_key: str,
    recovery_journal: RecoveryJournal | None,
    first_msg_seq: int | None,
) -> Result:
    """Call handler for each message until a Result is returned."""
    msg: Message | None = first_msg
    msg_seq = first_msg_seq
    next_message_seq = recovery_journal.next_message_seq if recovery_journal else 0
    if msg_seq is not None:
        next_message_seq = max(next_message_seq, msg_seq + 1)

    while True:
        if msg is None:
            try:
                msg = await msg_queue.get()
                msg_seq = None
            except TransportClosed:
                logger.debug("Transport closed, stopping on_message loop")
                return Result(message=None)
            except RuntimeError:
                logger.warning(
                    "Unexpected RuntimeError in on_message loop", exc_info=True
                )
                return Result(message=None)

        if stm_client is not None and msg_seq is None:
            msg_seq = next_message_seq
            try:
                await stm_client.add(
                    recovery_key,
                    serialize_message_received(
                        msg,
                        message_seq=msg_seq,
                        handler_type=HANDLER_TYPE_ON_MESSAGE,
                    ),
                )
            except Exception:
                logger.error(
                    "Recovery journal write failed, failing task",
                    extra={"stm_key": recovery_key, "message_seq": msg_seq},
                    exc_info=True,
                )
                raise
            next_message_seq = msg_seq + 1

        log_message_received(msg)

        # Record message received metric
        record_message_received(ctx.agent_type)

        if tracker is not None:
            tracker.prepare()

        result = await handler(ctx, msg)

        # Auto-persist state after each handler call (if dirty)
        if stm_client is not None and tracker is not None:
            await tracker.persist_if_dirty(stm_client, ctx._log)

        if result is not None:
            return result

        if stm_client is not None and msg_seq is not None:
            await stm_client.add(
                recovery_key,
                serialize_state_checkpoint(checkpointed_message_seq=msg_seq),
            )

        msg = None
        msg_seq = None


async def _run_on_run(
    run_handler: Any,
    ctx: Context,
    first_msg: Message,
    tracker: SnapshotStateTracker | DeltaStateTracker | None,
) -> Result:
    """Pass the initial message to the handler and call it once."""
    log_message_received(first_msg)

    # Record message received metric
    record_message_received(ctx.agent_type)

    if tracker is not None:
        tracker.prepare()

    return await run_handler(ctx, first_msg)


def log_message_received(msg: Message) -> None:
    logger.info(
        "Message received",
        extra={
            "message_type": msg.type.value,
            "sender": msg.sender,
            "sender_id": msg.sender_id,
            "user_message": msg.user_message,
            "system_message": msg.system_message,
            "query": msg.query,
            "message_id": msg.id,
            "reply_to": msg.reply_to,
            "thread_id": msg.thread_id,
        },
    )


async def _init_recovery_journal(
    stm_client: STMClientProtocol,
    recovery_key: str,
) -> RecoveryJournal:
    """Create or restore the framework-managed message recovery journal."""
    try:
        await stm_client.create(recovery_key)
        logger.debug("Recovery journal STM created", extra={"stm_key": recovery_key})
        return RecoveryJournal(messages_by_seq={})
    except STMAlreadyExistsError:
        entity = await stm_client.get(recovery_key)
        journal = restore_recovery_journal(entity)
        if journal.initial_message is not None:
            logger.info(
                "Recovered initial message from journal",
                extra={"stm_key": recovery_key},
            )
        return journal


async def _init_stm(
    ctx: Context,
    stm_client: STMClientProtocol,
    stm_key: str,
    persistence_mode: str,
    agent_type: str,
) -> SnapshotStateTracker | DeltaStateTracker:
    """Initialize STM for a task, restoring state if recovering from crash.

    Returns a configured state tracker with restored state (if any).
    """
    initial_state: dict[str, Any] = {}

    try:
        await stm_client.create(stm_key)
        logger.debug("STM created for task", extra={"stm_key": stm_key})

    except STMAlreadyExistsError:
        # Crash recovery — restore state from STM
        logger.info("STM exists, recovering state", extra={"stm_key": stm_key})
        record_state_recovery(agent_type)
        entity = await stm_client.get(stm_key)
        if entity and entity.entries:
            if persistence_mode == "delta":
                initial_state = restore_delta_entries(entity.entries)
            else:
                initial_state = restore_snapshot_entries(entity.entries)
            logger.info(
                "State recovered from STM",
                extra={
                    "stm_key": stm_key,
                    "entry_count": len(entity.entries),
                    "state_keys": list(initial_state.keys()),
                    "persistence_mode": persistence_mode,
                },
            )

    tracker = create_state_tracker(persistence_mode, stm_key, initial_state, agent_type)

    # For snapshot mode, set the baseline so dirty checking works on
    # the first persist (avoids writing unchanged state).
    if isinstance(tracker, SnapshotStateTracker):
        tracker.set_baseline(serialize_state(initial_state))

    return tracker


async def _cleanup_stm(stm_client: STMClientProtocol, stm_key: str) -> None:
    """Delete STM after successful task completion."""
    try:
        await stm_client.delete(stm_key)
        logger.debug("STM deleted after task completion", extra={"stm_key": stm_key})
    except Exception as e:
        # Log but don't fail — STM service retention will clean up eventually
        logger.warning(
            "Failed to delete STM after task completion",
            extra={"stm_key": stm_key, "error": str(e)},
        )


async def _cleanup_context_clients(
    ctx: Context,
    stm_client: STMClientProtocol | None,
) -> None:
    """Close clients on the context.

    Closes the STM client (created per-task), LLM client (created per-task),
    and any lazily-created cached_property clients (http, kg, agents). Safe
    to call even if clients weren't used.
    """
    # STM client is created per-task in _dispatch_task. Close it to
    # release the gRPC channel.
    if stm_client is not None:
        try:
            await stm_client.close()
        except Exception as e:
            logger.debug("Error closing STM client", extra={"error": str(e)})

    # LLM client is created per-task in _dispatch_task, not lazy.
    # Close it to release the underlying httpx client.
    if ctx._llm is not None:
        try:
            await ctx._llm.close()
        except Exception as e:
            logger.debug("Error closing LLM client", extra={"error": str(e)})

    # Check if http was accessed via cached_property
    if "http" in ctx.__dict__:
        try:
            await ctx.http.aclose()
        except Exception as e:
            logger.debug("Error closing HTTP client", extra={"error": str(e)})

    # Check if kg was accessed via cached_property
    if "kg" in ctx.__dict__:
        try:
            await ctx.kg.close()
        except Exception as e:
            logger.debug("Error closing KG client", extra={"error": str(e)})

    # Check if agents was accessed via cached_property
    if "agents" in ctx.__dict__:
        try:
            await ctx.agents.close()
        except Exception as e:
            logger.debug("Error closing agents client", extra={"error": str(e)})

    # Check if dra was accessed via cached_property
    if "dra" in ctx.__dict__:
        try:
            await ctx.dra.close()
        except Exception as e:
            logger.debug("Error closing DRA client", extra={"error": str(e)})

    # Close MCP client if it was created (owns transport for tools, etc.)
    if ctx._mcp is not None:
        try:
            await ctx._mcp.close()
        except Exception as e:
            logger.debug("Error closing MCP client", extra={"error": str(e)})
