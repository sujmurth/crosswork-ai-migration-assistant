"""State serialization for STM persistence.

Serializes ctx.state dict to bytes for STM storage using JSON.
Uses sort_keys=True for deterministic output, enabling dirty-checking
by comparing serialized bytes.

Common type conversions (developer responsibility):
- datetime -> ISO 8601 string: dt.isoformat() / datetime.fromisoformat(s)
- bytes -> base64 string: base64.b64encode(b).decode() / base64.b64decode(s)
- UUID -> string: str(uuid) / UUID(s)
"""

import json
from typing import Any

from cwai.adk.errors import STMSerializationError


def serialize_state(state: dict[str, Any]) -> bytes:
    """Serialize state dict to bytes via json.dumps(sort_keys=True).

    Raises:
        STMSerializationError: If state contains non-JSON-serializable data.
    """
    try:
        return json.dumps(state, sort_keys=True).encode("utf-8")
    except (TypeError, ValueError) as e:
        raise STMSerializationError(
            f"ctx.state contains non-JSON-serializable data: {e}"
        ) from e


def deserialize_state(data: bytes) -> dict[str, Any]:
    """Deserialize bytes from STM via json.loads.

    Raises:
        STMSerializationError: If data is not valid JSON.
    """
    try:
        result = json.loads(data.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        raise STMSerializationError(f"Failed to deserialize state from STM: {e}") from e

    if not isinstance(result, dict):
        raise STMSerializationError(
            f"Expected dict from STM, got {type(result).__name__}"
        )

    return result
