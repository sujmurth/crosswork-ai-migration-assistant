"""Platform transport protocol and inbound message types.

Abstracts the connection between the agent framework and the platform.
MockPlatform and gRPC transports implement PlatformTransport.
"""

from dataclasses import dataclass, field
from typing import Any, Protocol

from cwai.adk.types import Message, MessageType, Result


@dataclass(frozen=True)
class LLMProxyInfo:
    """LLM proxy connection details from platform handshake."""

    base_url: str
    virtual_key: str
    models: list[str] = field(default_factory=list)


@dataclass
class TaskDispatch:
    """Dispatch envelope for a new agent instance from the platform."""

    agent_id: str
    thread_id: str
    agent_type: str
    agent_instance_id: str
    settings: dict[str, Any] = field(default_factory=dict)
    auth_token: str | None = None
    llm_proxy_info: LLMProxyInfo | None = None
    ca_cert_path: str | None = None
    stm_endpoint: str | None = None
    # For testing: inject mock clients instead of building from config
    _llm_override: Any = field(default=None, repr=False)
    _http_override: Any = field(default=None, repr=False)
    _stm_override: Any = field(default=None, repr=False)


@dataclass
class InboundMessage:
    """Envelope for a message routed to an existing agent instance."""

    agent_id: str
    message: Message


@dataclass
class TaskRemoval:
    """Signal to cancel and clean up an agent instance."""

    agent_id: str


PlatformMessage = TaskDispatch | InboundMessage | TaskRemoval


class MessageQueue(Protocol):
    """Protocol for the per-agent message queue used by Context."""

    async def get(self, *, sender_id: int | None = None) -> Message: ...


class PlatformTransport(Protocol):
    """Abstraction over the platform connection.

    The framework calls these methods; implementations handle the wire
    protocol (in-memory queue for MockPlatform, gRPC for production).
    """

    async def connect(self) -> None: ...

    async def recv(self) -> PlatformMessage:
        """Block until the next control message from the platform.

        Returns TaskDispatch, TaskRemoval, or InboundMessage.
        Note: with on-demand fetching, InboundMessage is only used for
        the initial message bundled with TaskDispatch. Subsequent messages
        are fetched via recv_message().
        """
        ...

    async def recv_message(
        self,
        agent_id: str,
        *,
        sender_id: int | None = None,
    ) -> Message:
        """Block until the next data message for a specific agent instance.

        Called by the handler's message queue when it needs the next
        message. This is the on-demand fetch point - the transport only
        fetches from the server when the handler is ready. When provided,
        ``sender_id`` restricts delivery to messages from that sender ID.
        """
        ...

    async def send_result(
        self,
        agent_id: str,
        result: Result,
        *,
        final: bool = False,
        to_agent: str = "",
        to_agent_id: int = 0,
    ) -> None: ...

    async def send_message(
        self,
        agent: str,
        agent_id: int,
        *,
        user_message: str = "",
        system_message: str = "",
        type: MessageType = MessageType.REQUEST,
        reply_to: str = "",
        from_agent_id: int = 0,
    ) -> None: ...

    async def spawn_agent(
        self,
        agent_type: str,
        *,
        user_message: str = "",
        from_agent_id: int = 0,
        thread_id: str = "",
    ) -> int:
        """Create a new agent instance. Returns the instance agent_id."""
        ...

    async def remove_instance(self, agent_name: str, agent_id: str) -> None:
        """Tell the platform to remove an agent instance."""
        ...

    async def send_fail(self, agent_id: str, error: str) -> None: ...

    def remember_message_sender(self, agent_id: str, msg: Message) -> None:
        """Record reply routing metadata from a replayed request message.

        Called when a journal-recovered message is used as first_msg so
        the transport knows where to route the final result. The default
        is a no-op for transports that don't track per-instance routing.
        """

    async def close(self) -> None: ...
