"""STM payload compression and decompression.

Transparent compression layer for STM payloads. Controlled by the
CWAI_STM_COMPRESSION feature flag.

Each compressed payload is prefixed with a 1-byte header indicating
the algorithm used. The read path auto-detects the format, so
decompression works regardless of the feature flag setting.

Header bytes:
    0x00 — uncompressed (payload follows as-is)
    0x01 — zlib compressed

Backward compatibility: payloads written before compression was added
have no header byte. They start with JSON content (0x7B for '{' or
0x5B for '['). The read path detects these and returns them as-is.
"""

import zlib

from cwai.adk import features

# Payloads smaller than this are stored uncompressed. The overhead of
# compression (header byte, zlib framing) outweighs savings for tiny
# payloads. Benchmark showed poor ratios below ~256 bytes.
_COMPRESSION_THRESHOLD = 256

_HEADER_UNCOMPRESSED = b"\x00"
_HEADER_ZLIB = b"\x01"

# Bytes that indicate a legacy (pre-compression) payload — raw JSON.
_LEGACY_FIRST_BYTES = {0x7B, 0x5B}  # '{' and '['


def compress(payload: bytes) -> bytes:
    """Compress a payload if compression is enabled and worthwhile.

    Returns the payload with a 1-byte header prepended. If compression
    is disabled or the payload is below the threshold, the payload is
    returned with an "uncompressed" header.
    """
    mode = features.get_stm_compression()

    if mode == features.STM_COMPRESSION_NONE or len(payload) < _COMPRESSION_THRESHOLD:
        return _HEADER_UNCOMPRESSED + payload

    if mode == features.STM_COMPRESSION_ZLIB:
        compressed = zlib.compress(payload, 1)
        # Only use compressed version if it's actually smaller.
        if len(compressed) < len(payload):
            return _HEADER_ZLIB + compressed

    return _HEADER_UNCOMPRESSED + payload


def decompress(data: bytes) -> bytes:
    """Decompress a payload, auto-detecting the format.

    Handles three cases:
    - Header 0x00: strip header, return raw payload.
    - Header 0x01: strip header, zlib decompress.
    - Legacy (no header): raw JSON starting with '{' or '[', return as-is.
    """
    if not data:
        return data

    header = data[0]

    if header in _LEGACY_FIRST_BYTES:
        return data

    if header == 0x00:
        return data[1:]

    if header == 0x01:
        return zlib.decompress(data[1:])

    # Unknown header — return as-is for forward compatibility.
    return data
