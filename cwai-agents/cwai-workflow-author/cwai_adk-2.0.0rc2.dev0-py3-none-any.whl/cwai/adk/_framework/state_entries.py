"""Entry format for snapshot and delta state entries in STM.

Each STM entry payload is a JSON object with a type marker (_t) and
format version (_v). Two entry types:

- Snapshot ("s"): contains the full state dict.
- Delta ("d"): contains RFC 6902 JSON Patch operations.

The format version (_v) allows future evolution without breaking
existing entries.
"""

import json
from dataclasses import dataclass
from typing import Any

import jsonpatch

from cwai.adk.errors import STMSerializationError

# Format version — increment if the entry schema changes.
_FORMAT_VERSION = 1

_TYPE_SNAPSHOT = "s"
_TYPE_DELTA = "d"


@dataclass(frozen=True)
class SnapshotEntry:
    """A full state snapshot."""

    data: dict[str, Any]


@dataclass(frozen=True)
class DeltaEntry:
    """A set of RFC 6902 JSON Patch operations."""

    ops: list[dict[str, Any]]

    def apply(self, state: dict[str, Any]) -> dict[str, Any]:
        """Apply this delta to a state dict, returning the new state."""
        patch = jsonpatch.JsonPatch(self.ops)
        return patch.apply(state)


def serialize_snapshot(state: dict[str, Any]) -> bytes:
    """Serialize a full state snapshot to STM entry bytes.

    Raises:
        STMSerializationError: If state contains non-JSON-serializable data.
    """
    try:
        payload = json.dumps(
            {"_t": _TYPE_SNAPSHOT, "_v": _FORMAT_VERSION, "data": state},
            sort_keys=False,
        ).encode("utf-8")
    except (TypeError, ValueError) as e:
        raise STMSerializationError(
            f"ctx.state contains non-JSON-serializable data: {e}"
        ) from e
    return payload


def serialize_delta(patch: jsonpatch.JsonPatch) -> bytes:
    """Serialize a JSON Patch delta to STM entry bytes.

    Raises:
        STMSerializationError: If the patch contains non-serializable data.
    """
    try:
        payload = json.dumps(
            {"_t": _TYPE_DELTA, "_v": _FORMAT_VERSION, "ops": patch.patch},
            sort_keys=False,
        ).encode("utf-8")
    except (TypeError, ValueError) as e:
        raise STMSerializationError(
            f"Delta patch contains non-serializable data: {e}"
        ) from e
    return payload


def deserialize_entry(data: bytes) -> SnapshotEntry | DeltaEntry:
    """Deserialize an STM entry payload into a typed entry.

    Raises:
        STMSerializationError: If the data is malformed, missing type
            marker, or has an unknown type.
    """
    try:
        obj = json.loads(data.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        raise STMSerializationError(f"Failed to deserialize STM entry: {e}") from e

    if not isinstance(obj, dict):
        raise STMSerializationError(
            f"Expected dict in STM entry, got {type(obj).__name__}"
        )

    entry_type = obj.get("_t")
    if entry_type is None:
        raise STMSerializationError("STM entry missing type marker (_t)")

    if entry_type == _TYPE_SNAPSHOT:
        state_data = obj.get("data")
        if not isinstance(state_data, dict):
            raise STMSerializationError(
                "Snapshot entry missing or invalid 'data' field"
            )
        return SnapshotEntry(data=state_data)

    if entry_type == _TYPE_DELTA:
        ops = obj.get("ops")
        if not isinstance(ops, list):
            raise STMSerializationError("Delta entry missing or invalid 'ops' field")
        return DeltaEntry(ops=ops)

    raise STMSerializationError(f"Unknown STM entry type: {entry_type!r}")
