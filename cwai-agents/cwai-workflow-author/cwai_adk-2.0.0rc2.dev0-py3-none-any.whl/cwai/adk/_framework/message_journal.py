"""Framework-managed message recovery journal helpers."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from cwai.adk.types import Message, MessageType
from cwai.adk.types.stm import StateEntity

_FORMAT_VERSION = 1
_TYPE_MESSAGE_JOURNAL_EVENT = "adk_message_journal_event"
_EVENT_MESSAGE_RECEIVED = "message_received"
_EVENT_STATE_CHECKPOINT = "state_checkpoint"
HANDLER_TYPE_ON_RUN = "on_run"
HANDLER_TYPE_ON_MESSAGE = "on_message"
_HANDLER_TYPES = {HANDLER_TYPE_ON_RUN, HANDLER_TYPE_ON_MESSAGE}


@dataclass(frozen=True)
class JournaledMessage:
    """A valid message event recovered from the framework journal."""

    message_seq: int
    message: Message
    handler_type: str | None = None


@dataclass(frozen=True)
class RecoveryJournal:
    """Folded view of framework recovery journal events."""

    messages_by_seq: dict[int, JournaledMessage]
    checkpointed_message_seq: int | None = None

    @property
    def initial_message(self) -> Message | None:
        """Return sequence 0 as the initial on_run message when present."""
        journaled = self.messages_by_seq.get(0)
        if journaled is None:
            return None
        return journaled.message

    @property
    def next_message_seq(self) -> int:
        """Return the next sequence number for a newly journaled message."""
        if not self.messages_by_seq:
            return 0
        return max(self.messages_by_seq) + 1

    def first_uncheckpointed_message(
        self,
        *,
        handler_type: str | None = None,
    ) -> JournaledMessage | None:
        """Return the earliest journaled message after the latest checkpoint."""
        checkpointed_seq = self.checkpointed_message_seq
        min_seq = -1 if checkpointed_seq is None else checkpointed_seq
        for message_seq in sorted(self.messages_by_seq):
            if message_seq <= min_seq:
                continue
            journaled = self.messages_by_seq[message_seq]
            if handler_type is not None and journaled.handler_type != handler_type:
                continue
            return journaled
        return None


_EMPTY_JOURNAL = RecoveryJournal(messages_by_seq={})


def recovery_stm_key(agent_type: str, agent_id: str) -> str:
    """Return the framework-managed recovery journal STM key."""
    return f"{agent_type}:{agent_id}:recovery"


def serialize_message(message: Message) -> dict[str, Any]:
    """Serialize handler-visible message fields to a JSON-safe dict."""
    return {
        "type": message.type.value,
        "sender": message.sender,
        "sender_id": message.sender_id,
        "user_message": message.user_message,
        "system_message": message.system_message,
        "query": message.query,
        "id": message.id,
        "reply_to": message.reply_to,
        "thread_id": message.thread_id,
    }


def deserialize_message(data: dict[str, Any]) -> Message:
    """Deserialize a journaled message into an ADK Message."""
    query = data.get("query", {})
    if query is None:
        query = {}
    if not isinstance(query, dict):
        raise TypeError("Journaled message query must be a dict")

    return Message(
        type=MessageType(data["type"]),
        sender=str(data.get("sender", "")),
        sender_id=int(data.get("sender_id", 0)),
        user_message=str(data.get("user_message", "")),
        system_message=str(data.get("system_message", "")),
        query=query,
        id=str(data.get("id", "")),
        reply_to=str(data.get("reply_to", "")),
        thread_id=str(data.get("thread_id", "")),
    )


def serialize_message_received(
    message: Message,
    *,
    message_seq: int,
    handler_type: str | None = None,
) -> bytes:
    """Serialize a journal event for a platform message received by ADK."""
    if type(message_seq) is not int or message_seq < 0:
        raise ValueError("message_seq must be an integer >= 0")
    if handler_type is not None and handler_type not in _HANDLER_TYPES:
        raise ValueError("handler_type must be 'on_run', 'on_message', or None")

    event: dict[str, Any] = {
        "_t": _TYPE_MESSAGE_JOURNAL_EVENT,
        "_v": _FORMAT_VERSION,
        "event": _EVENT_MESSAGE_RECEIVED,
        "message_seq": message_seq,
        "message": serialize_message(message),
    }
    if handler_type is not None:
        event["handler_type"] = handler_type

    return json.dumps(event, sort_keys=False).encode("utf-8")


def serialize_state_checkpoint(*, checkpointed_message_seq: int) -> bytes:
    """Serialize a journal event marking a message sequence as handled."""
    if type(checkpointed_message_seq) is not int or checkpointed_message_seq < 0:
        raise ValueError("checkpointed_message_seq must be an integer >= 0")

    return json.dumps(
        {
            "_t": _TYPE_MESSAGE_JOURNAL_EVENT,
            "_v": _FORMAT_VERSION,
            "event": _EVENT_STATE_CHECKPOINT,
            "checkpointed_message_seq": checkpointed_message_seq,
        },
        sort_keys=False,
    ).encode("utf-8")


def restore_recovery_journal(entity: StateEntity | None) -> RecoveryJournal:
    """Fold valid recovery journal events from an STM entity."""
    if entity is None:
        return _EMPTY_JOURNAL

    messages_by_seq: dict[int, JournaledMessage] = {}
    checkpointed_message_seq: int | None = None

    for entry in entity.entries:
        event = _event_payload(entry.payload)
        if event is None:
            continue

        journaled = _message_received_event(event)
        if journaled is not None:
            messages_by_seq[journaled.message_seq] = journaled
            continue

        checkpoint = _state_checkpoint_event(event)
        if checkpoint is not None:
            checkpointed_message_seq = checkpoint

    return RecoveryJournal(
        messages_by_seq=messages_by_seq,
        checkpointed_message_seq=checkpointed_message_seq,
    )


def restore_initial_message(entity: StateEntity | None) -> Message | None:
    """Return the latest valid sequence 0 message from a recovery STM entity."""
    return restore_recovery_journal(entity).initial_message


def _event_payload(payload: bytes) -> dict[str, Any] | None:
    try:
        event = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None

    if not isinstance(event, dict):
        return None
    if event.get("_t") != _TYPE_MESSAGE_JOURNAL_EVENT:
        return None
    if event.get("_v") != _FORMAT_VERSION:
        return None
    return event


def _message_received_event(event: dict[str, Any]) -> JournaledMessage | None:
    if event.get("event") != _EVENT_MESSAGE_RECEIVED:
        return None

    message_seq = event.get("message_seq")
    if type(message_seq) is not int or message_seq < 0:
        return None

    handler_type = event.get("handler_type")
    if handler_type is not None and handler_type not in _HANDLER_TYPES:
        return None

    message = event.get("message")
    if not isinstance(message, dict):
        return None

    try:
        return JournaledMessage(
            message_seq=message_seq,
            message=deserialize_message(message),
            handler_type=handler_type,
        )
    except (KeyError, TypeError, ValueError):
        return None


def _state_checkpoint_event(event: dict[str, Any]) -> int | None:
    if event.get("event") != _EVENT_STATE_CHECKPOINT:
        return None

    checkpointed_message_seq = event.get("checkpointed_message_seq")
    if type(checkpointed_message_seq) is not int or checkpointed_message_seq < 0:
        return None
    return checkpointed_message_seq
