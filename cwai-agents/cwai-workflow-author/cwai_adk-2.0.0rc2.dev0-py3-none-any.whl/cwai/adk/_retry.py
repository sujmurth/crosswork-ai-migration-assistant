"""HTTP retry utilities with exponential backoff.

Provides reusable retry logic for HTTP clients. Handles transient errors
like 502/503/504, rate limiting (429 with Retry-After), and connection
errors with exponential backoff and jitter.
"""

import asyncio
import logging
import random
from collections.abc import Awaitable, Callable
from email.utils import parsedate_to_datetime

import httpx

# Default retry configuration
DEFAULT_RETRIES: int = 5
DEFAULT_RETRY_BASE: float = 1.0  # Delays: 1s, 2s, 4s, 8s, 16s (doubling)
DEFAULT_MAX_DELAY: float = 60.0  # Cap delay at 60 seconds

# HTTP status codes that indicate transient failures worth retrying
RETRYABLE_HTTP_STATUS: frozenset[int] = frozenset({502, 503, 504, 429})

_default_logger = logging.getLogger("cwai.adk._retry")


def compute_retry_delay(
    attempt: int,
    base: float = DEFAULT_RETRY_BASE,
    retry_after: float | None = None,
    max_delay: float = DEFAULT_MAX_DELAY,
) -> float:
    """Compute delay before next retry attempt.

    Uses exponential backoff with jitter. If `retry_after` is provided
    (from a 429 response), it takes precedence over the computed delay.

    Args:
        attempt: Zero-based attempt number (0 = first retry after initial failure).
        base: Base delay in seconds. Actual delay is base * 2^attempt.
        retry_after: Optional delay from Retry-After header (seconds).
        max_delay: Maximum delay cap in seconds.

    Returns:
        Delay in seconds before the next attempt.
    """
    if retry_after is not None:
        # Use Retry-After value, but still apply max cap
        return min(retry_after, max_delay)

    # Exponential backoff: base * 2^attempt
    exponential_delay = base * (2**attempt)

    # Apply jitter: 50-100% of the computed delay
    jitter = 0.5 + random.random() * 0.5
    delay = exponential_delay * jitter

    return min(delay, max_delay)


def parse_retry_after(
    response: httpx.Response,
    max_delay: float = DEFAULT_MAX_DELAY,
) -> float | None:
    """Parse Retry-After header from HTTP response.

    Supports both formats:
    - Integer seconds: "Retry-After: 120"
    - HTTP-date: "Retry-After: Wed, 21 Oct 2025 07:28:00 GMT"

    Args:
        response: HTTP response that may contain Retry-After header.
        max_delay: Maximum value to return (caps excessive values).

    Returns:
        Delay in seconds, or None if header is missing/unparseable.
    """
    retry_after = response.headers.get("retry-after")
    if retry_after is None:
        return None

    # Try parsing as integer seconds first
    try:
        seconds = int(retry_after)
        return min(max(0, seconds), max_delay)
    except ValueError:
        pass

    # Try parsing as HTTP-date
    try:
        retry_date = parsedate_to_datetime(retry_after)
        # Calculate seconds from now
        import datetime

        now = datetime.datetime.now(datetime.UTC)
        delta = (retry_date - now).total_seconds()
        return min(max(0, delta), max_delay)
    except (ValueError, TypeError):
        pass

    return None


def is_retryable_http_error(
    exc: Exception | None = None,
    response: httpx.Response | None = None,
) -> bool:
    """Check if an error or response indicates a retryable failure.

    Args:
        exc: Exception that occurred during request (if any).
        response: HTTP response received (if any).

    Returns:
        True if the error is transient and worth retrying.
    """
    # These errors indicate the request did not receive a usable response and
    # are safe to retry with the same idempotency assumptions as the caller.
    if isinstance(
        exc, httpx.ConnectError | httpx.ConnectTimeout | httpx.RemoteProtocolError
    ):
        return True

    # Check response status code
    if response is not None and response.status_code in RETRYABLE_HTTP_STATUS:
        return True

    return False


def get_retry_reason(
    exc: Exception | None = None,
    response: httpx.Response | None = None,
) -> str:
    """Get a short reason string for logging/metrics.

    Args:
        exc: Exception that occurred during request (if any).
        response: HTTP response received (if any).

    Returns:
        Short reason string like "503", "429", "connect_error".
    """
    if isinstance(exc, httpx.ConnectError):
        return "connect_error"
    if isinstance(exc, httpx.ConnectTimeout):
        return "connect_timeout"
    if isinstance(exc, httpx.RemoteProtocolError):
        return "remote_protocol_error"
    if response is not None:
        return str(response.status_code)
    if exc is not None:
        return type(exc).__name__.lower()
    return "unknown"


async def http_call_with_retry(
    request_fn: Callable[[], Awaitable[httpx.Response]],
    *,
    retries: int = DEFAULT_RETRIES,
    retry_base: float = DEFAULT_RETRY_BASE,
    max_delay: float = DEFAULT_MAX_DELAY,
    log: logging.Logger | logging.LoggerAdapter | None = None,
    on_retry: Callable[[int, float, str], None] | None = None,
) -> httpx.Response:
    """Execute HTTP request with exponential backoff retry.

    Retries on transient errors (502, 503, 504, 429, connection errors,
    and remote protocol disconnects).
    For 429 responses, respects the Retry-After header if present.

    Args:
        request_fn: Async callable that performs the HTTP request and
            returns an httpx.Response. Will be called multiple times
            on retry.
        retries: Maximum number of retry attempts (0 = no retries).
        retry_base: Base delay for exponential backoff in seconds.
        max_delay: Maximum delay cap in seconds.
        log: Logger for retry warnings. Uses module logger if None.
        on_retry: Optional callback invoked on each retry with
            (attempt, delay, reason). Useful for metrics.

    Returns:
        Successful HTTP response.

    Raises:
        httpx.ConnectError: Connection failed after all retries.
        httpx.ConnectTimeout: Connection timed out after all retries.
        httpx.RemoteProtocolError: Remote protocol failure after all retries.
        httpx.HTTPStatusError: Non-retryable HTTP error.

    Note:
        The response is returned even for retryable status codes if
        retries are exhausted. Caller should check response.status_code.
    """
    logger = log or _default_logger
    last_response: httpx.Response | None = None
    last_exception: Exception | None = None

    max_attempts = 1 + retries  # Initial attempt + retries

    for attempt in range(max_attempts):
        try:
            response = await request_fn()
            last_response = response

            # Success - return immediately
            if not is_retryable_http_error(response=response):
                return response

            # Retryable status code - check if we have retries left
            if attempt >= max_attempts - 1:
                # No more retries, return the response as-is
                return response

            # Calculate delay and retry
            retry_after = parse_retry_after(response, max_delay)
            delay = compute_retry_delay(attempt, retry_base, retry_after, max_delay)
            reason = get_retry_reason(response=response)

            if on_retry:
                on_retry(attempt + 1, delay, reason)

            logger.warning(
                "HTTP request failed with retryable status, retrying",
                extra={
                    "status_code": response.status_code,
                    "attempt": attempt + 1,
                    "max_attempts": max_attempts,
                    "retry_delay": round(delay, 2),
                },
            )

            await asyncio.sleep(delay)

        except (
            httpx.ConnectError,
            httpx.ConnectTimeout,
            httpx.RemoteProtocolError,
        ) as e:
            last_exception = e

            # Check if we have retries left
            if attempt >= max_attempts - 1:
                raise

            # Calculate delay and retry
            delay = compute_retry_delay(attempt, retry_base, None, max_delay)
            reason = get_retry_reason(exc=e)

            if on_retry:
                on_retry(attempt + 1, delay, reason)

            logger.warning(
                "HTTP request failed with transient transport error, retrying",
                extra={
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "attempt": attempt + 1,
                    "max_attempts": max_attempts,
                    "retry_delay": round(delay, 2),
                },
            )

            await asyncio.sleep(delay)

    # Should not reach here, but handle gracefully
    if last_response is not None:
        return last_response
    if last_exception is not None:
        raise last_exception
    raise RuntimeError("http_call_with_retry: unexpected state")
