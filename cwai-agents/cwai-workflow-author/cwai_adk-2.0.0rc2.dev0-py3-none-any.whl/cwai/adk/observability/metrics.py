"""OpenTelemetry metrics setup."""

from opentelemetry import metrics
from opentelemetry.metrics import Counter, Histogram, Meter, UpDownCounter

# Module-level meter instance, set by configure_metrics()
_meter: Meter | None = None

# Framework metric instruments
_task_counter: Counter | None = None
_task_duration: Histogram | None = None
_tasks_active: UpDownCounter | None = None
_messages_received_counter: Counter | None = None
_state_persist_counter: Counter | None = None
_state_persist_size: Histogram | None = None
_state_recovery_counter: Counter | None = None

# LLM client metric instruments
_llm_request_counter: Counter | None = None
_llm_request_duration: Histogram | None = None
_llm_tokens_prompt: Counter | None = None
_llm_tokens_completion: Counter | None = None
_llm_tokens_prompt_hist: Histogram | None = None
_llm_tokens_completion_hist: Histogram | None = None
_llm_fallback_counter: Counter | None = None
_llm_error_counter: Counter | None = None
_llm_retry_counter: Counter | None = None

# STM client metric instruments
_stm_operation_counter: Counter | None = None
_stm_operation_duration: Histogram | None = None
_stm_retry_counter: Counter | None = None
_stm_payload_size: Histogram | None = None
_stm_entries_retrieved: Histogram | None = None

# HTTP client metric instruments
_http_request_counter: Counter | None = None
_http_request_duration: Histogram | None = None
_http_error_counter: Counter | None = None

# gRPC transport metric instruments
_grpc_call_counter: Counter | None = None
_grpc_call_duration: Histogram | None = None

# KG client metric instruments
_kg_request_counter: Counter | None = None
_kg_request_duration: Histogram | None = None
_kg_error_counter: Counter | None = None

# DRA client metric instruments
_dra_request_counter: Counter | None = None
_dra_request_duration: Histogram | None = None
_dra_error_counter: Counter | None = None
_dra_response_counter: Counter | None = None

# RAG client metric instruments
_rag_request_counter: Counter | None = None
_rag_request_duration: Histogram | None = None
_rag_error_counter: Counter | None = None

# Tools/MCP client metric instruments
_tools_request_counter: Counter | None = None
_tools_request_duration: Histogram | None = None
_tools_error_counter: Counter | None = None

# Sub-agent call-site metric instruments
_subagent_call_counter: Counter | None = None
_subagent_call_duration: Histogram | None = None

# LangGraph per-node LLM token instruments
_langgraph_llm_tokens_prompt: Histogram | None = None
_langgraph_llm_tokens_completion: Histogram | None = None


def configure_metrics(
    service_name: str,
    service_version: str,
    otlp_endpoint: str | None = None,
) -> Meter:
    """Configure OpenTelemetry metrics with OTLP exporter.

    If no endpoint is provided, returns a no-op meter that discards all
    recorded metrics.

    The OTLP exporter reads configuration from standard environment variables:
    - OTEL_EXPORTER_OTLP_ENDPOINT: Collector endpoint (e.g., "localhost:4317")
    - OTEL_EXPORTER_OTLP_CERTIFICATE: Path to CA certificate for TLS

    Args:
        service_name: Name of the agent service.
        service_version: Version of the agent.
        otlp_endpoint: If provided (non-empty), enables OTEL export. The actual
            endpoint is read from OTEL_EXPORTER_OTLP_ENDPOINT env var.

    Returns:
        Configured Meter instance.
    """
    global _meter, _task_counter, _task_duration, _messages_received_counter

    if not otlp_endpoint or not otlp_endpoint.strip():
        # No endpoint configured — use no-op meter
        _meter = metrics.get_meter(service_name, service_version)
        _init_instruments(_meter)
        return _meter

    # Only import heavy SDK dependencies when actually exporting
    from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (
        OTLPMetricExporter,
    )
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
    from opentelemetry.sdk.resources import Resource

    resource = Resource.create(
        {
            "service.name": service_name,
            "service.version": service_version,
        }
    )

    # Use gRPC exporter - it reads from OTEL_EXPORTER_OTLP_* env vars
    exporter = OTLPMetricExporter()
    reader = PeriodicExportingMetricReader(exporter, export_interval_millis=10000)

    provider = MeterProvider(resource=resource, metric_readers=[reader])
    metrics.set_meter_provider(provider)

    _meter = metrics.get_meter(service_name, service_version)
    _init_instruments(_meter)
    return _meter


def _init_instruments(meter: Meter) -> None:
    """Initialize metric instruments on the given meter."""
    # Framework metrics
    global _task_counter, _task_duration, _tasks_active, _messages_received_counter
    global _state_persist_counter, _state_persist_size, _state_recovery_counter
    # LLM client metrics
    global _llm_request_counter, _llm_request_duration
    global _llm_tokens_prompt, _llm_tokens_completion
    global _llm_tokens_prompt_hist, _llm_tokens_completion_hist
    global _llm_fallback_counter, _llm_error_counter, _llm_retry_counter
    # STM client metrics
    global _stm_operation_counter, _stm_operation_duration
    global _stm_retry_counter, _stm_payload_size, _stm_entries_retrieved
    # HTTP client metrics
    global _http_request_counter, _http_request_duration, _http_error_counter
    # gRPC transport metrics
    global _grpc_call_counter, _grpc_call_duration
    # KG client metrics
    global _kg_request_counter, _kg_request_duration, _kg_error_counter
    # DRA client metrics
    global _dra_request_counter, _dra_request_duration
    global _dra_error_counter, _dra_response_counter
    # RAG client metrics
    global _rag_request_counter, _rag_request_duration, _rag_error_counter
    # Tools/MCP client metrics
    global _tools_request_counter, _tools_request_duration, _tools_error_counter
    # Sub-agent call-site metrics
    global _subagent_call_counter, _subagent_call_duration
    # LangGraph per-node LLM token metrics
    global _langgraph_llm_tokens_prompt, _langgraph_llm_tokens_completion

    # Framework metrics
    _task_counter = meter.create_counter(
        name="cwai.agent.task.count",
        description="Number of tasks processed",
        unit="1",
    )

    _task_duration = meter.create_histogram(
        name="cwai.agent.task.duration",
        description="Task execution duration",
        unit="ms",
    )

    _tasks_active = meter.create_up_down_counter(
        name="cwai.agent.tasks.active",
        description="Number of currently active tasks",
        unit="1",
    )

    _messages_received_counter = meter.create_counter(
        name="cwai.agent.message.count",
        description="Number of messages received by handlers",
        unit="1",
    )

    _state_persist_counter = meter.create_counter(
        name="cwai.agent.state.persist.count",
        description="Number of state persistence operations",
        unit="1",
    )

    _state_persist_size = meter.create_histogram(
        name="cwai.agent.state.persist.size",
        description="Size of persisted state entries",
        unit="By",
    )

    _state_recovery_counter = meter.create_counter(
        name="cwai.agent.state.recovery.count",
        description="Number of task state recovery events",
        unit="1",
    )

    # LLM client metrics
    _llm_request_counter = meter.create_counter(
        name="cwai.agent.llm.request.count",
        description="Number of LLM requests",
        unit="1",
    )

    _llm_request_duration = meter.create_histogram(
        name="cwai.agent.llm.request.duration",
        description="LLM request duration",
        unit="ms",
    )

    _llm_tokens_prompt = meter.create_counter(
        name="cwai.agent.llm.tokens.prompt",
        description="LLM prompt tokens consumed",
        unit="1",
    )

    _llm_tokens_completion = meter.create_counter(
        name="cwai.agent.llm.tokens.completion",
        description="LLM completion tokens generated",
        unit="1",
    )

    _llm_tokens_prompt_hist = meter.create_histogram(
        name="cwai.agent.llm.tokens.prompt.per_request",
        description="LLM prompt tokens per request (distribution)",
        unit="1",
    )

    _llm_tokens_completion_hist = meter.create_histogram(
        name="cwai.agent.llm.tokens.completion.per_request",
        description="LLM completion tokens per request (distribution)",
        unit="1",
    )

    _llm_fallback_counter = meter.create_counter(
        name="cwai.agent.llm.fallback.count",
        description="LLM model fallback events",
        unit="1",
    )

    _llm_error_counter = meter.create_counter(
        name="cwai.agent.llm.error.count",
        description="LLM request errors",
        unit="1",
    )

    _llm_retry_counter = meter.create_counter(
        name="cwai.agent.llm.retry.count",
        description="LLM request retries",
        unit="1",
    )

    # STM client metrics
    _stm_operation_counter = meter.create_counter(
        name="cwai.agent.stm.operation.count",
        description="Number of STM operations",
        unit="1",
    )

    _stm_operation_duration = meter.create_histogram(
        name="cwai.agent.stm.operation.duration",
        description="STM operation duration",
        unit="ms",
    )

    _stm_retry_counter = meter.create_counter(
        name="cwai.agent.stm.retry.count",
        description="Number of STM operation retries",
        unit="1",
    )

    _stm_payload_size = meter.create_histogram(
        name="cwai.agent.stm.payload.size",
        description="Size of STM payloads",
        unit="By",
    )

    _stm_entries_retrieved = meter.create_histogram(
        name="cwai.agent.stm.entries.count",
        description="Number of entries retrieved from STM",
        unit="1",
    )

    # HTTP client metrics
    _http_request_counter = meter.create_counter(
        name="cwai.agent.http.request.count",
        description="Number of HTTP requests",
        unit="1",
    )

    _http_request_duration = meter.create_histogram(
        name="cwai.agent.http.request.duration",
        description="HTTP request duration",
        unit="ms",
    )

    _http_error_counter = meter.create_counter(
        name="cwai.agent.http.error.count",
        description="Number of HTTP client errors (connection failures, timeouts)",
        unit="1",
    )

    # gRPC transport metrics
    _grpc_call_counter = meter.create_counter(
        name="cwai.agent.grpc.call.count",
        description="Number of gRPC calls to the platform",
        unit="1",
    )

    _grpc_call_duration = meter.create_histogram(
        name="cwai.agent.grpc.call.duration",
        description="gRPC call duration",
        unit="ms",
    )

    # KG client metrics
    _kg_request_counter = meter.create_counter(
        name="cwai.agent.kg.request.count",
        description="Number of KG requests",
        unit="1",
    )

    _kg_request_duration = meter.create_histogram(
        name="cwai.agent.kg.request.duration",
        description="KG request duration",
        unit="ms",
    )

    _kg_error_counter = meter.create_counter(
        name="cwai.agent.kg.error.count",
        description="Number of KG errors",
        unit="1",
    )

    # DRA client metrics
    _dra_request_counter = meter.create_counter(
        name="cwai.agent.dra.request.count",
        description="Number of DRA requests",
        unit="1",
    )

    _dra_request_duration = meter.create_histogram(
        name="cwai.agent.dra.request.duration",
        description="DRA request duration",
        unit="ms",
    )

    _dra_error_counter = meter.create_counter(
        name="cwai.agent.dra.error.count",
        description="Number of DRA errors",
        unit="1",
    )

    _dra_response_counter = meter.create_counter(
        name="cwai.agent.dra.response.count",
        description="Number of DRA responses received (per DRA)",
        unit="1",
    )

    # RAG client metrics
    _rag_request_counter = meter.create_counter(
        name="cwai.agent.rag.request.count",
        description="Number of RAG requests",
        unit="1",
    )

    _rag_request_duration = meter.create_histogram(
        name="cwai.agent.rag.request.duration",
        description="RAG request duration",
        unit="ms",
    )

    _rag_error_counter = meter.create_counter(
        name="cwai.agent.rag.error.count",
        description="Number of RAG errors",
        unit="1",
    )

    # Tools/MCP client metrics
    _tools_request_counter = meter.create_counter(
        name="cwai.agent.tools.request.count",
        description="Number of Tools/MCP requests",
        unit="1",
    )

    _tools_request_duration = meter.create_histogram(
        name="cwai.agent.tools.request.duration",
        description="Tools/MCP request duration",
        unit="ms",
    )

    _tools_error_counter = meter.create_counter(
        name="cwai.agent.tools.error.count",
        description="Number of Tools/MCP errors",
        unit="1",
    )

    # Sub-agent call-site metrics
    _subagent_call_counter = meter.create_counter(
        name="cwai.agent.subagent.call.count",
        description="Number of sub-agent / spawn / call_agent invocations",
        unit="1",
    )

    _subagent_call_duration = meter.create_histogram(
        name="cwai.agent.subagent.call.duration",
        description="Sub-agent invocation duration",
        unit="ms",
    )

    # LangGraph per-node LLM token metrics
    _langgraph_llm_tokens_prompt = meter.create_histogram(
        name="cwai.agent.langgraph.llm.tokens.prompt",
        description="LangGraph LLM prompt tokens per node invocation",
        unit="1",
    )

    _langgraph_llm_tokens_completion = meter.create_histogram(
        name="cwai.agent.langgraph.llm.tokens.completion",
        description="LangGraph LLM completion tokens per node invocation",
        unit="1",
    )


def get_meter() -> Meter:
    """Get the configured meter for recording metrics.

    Returns the meter configured by `configure_metrics()`, or a no-op meter
    if `configure_metrics()` has not been called.

    Returns:
        Meter instance.
    """
    if _meter is None:
        return metrics.get_meter("cwai.agent")
    return _meter


def record_task_completed(
    agent_type: str,
    duration_ms: float,
    success: bool,
    *,
    user_name: str = "",
) -> None:
    """Record task completion metrics.

    Args:
        agent_type: The handler/agent type name.
        duration_ms: Task execution duration in milliseconds.
        success: Whether the task completed successfully.
        user_name: Name of the user who initiated the request (from JWT).
    """
    if _task_counter is not None:
        status = "success" if success else "error"
        attrs: dict[str, str] = {"agent.type": agent_type, "task.status": status}
        attrs["user.name"] = user_name if user_name else "unknown"
        _task_counter.add(1, attrs)

    if _task_duration is not None:
        _task_duration.record(duration_ms, {"agent.type": agent_type})


def record_message_received(agent_type: str) -> None:
    """Record that a message was received by a handler.

    Args:
        agent_type: The handler/agent type name.
    """
    if _messages_received_counter is not None:
        _messages_received_counter.add(1, {"agent.type": agent_type})


def _default_label(value: str | None, default: str) -> str:
    """Return a stable metric label value for unset optional context."""
    return value if value else default


def record_llm_request(
    model: str,
    duration_ms: float,
    success: bool,
    *,
    stream: bool = False,
    agent_type: str | None = None,
    user_name: str | None = None,
) -> None:
    """Record an LLM request completion.

    Args:
        model: The model name used for the request.
        duration_ms: Request duration in milliseconds.
        success: Whether the request succeeded.
        stream: Whether this was a streaming request.
        agent_type: Calling agent type for per-agent aggregation.
        user_name: Requesting user for per-user aggregation.
    """
    status = "success" if success else "error"
    stream_str = "true" if stream else "false"
    model_name = _default_label(model, "default")
    agent_label = _default_label(agent_type, "unknown")
    user_label = _default_label(user_name, "unknown")

    if _llm_request_counter is not None:
        attrs: dict[str, str] = {
            "agent.type": agent_label,
            "model": model_name,
            "status": status,
            "stream": stream_str,
            "user.name": user_label,
        }
        _llm_request_counter.add(1, attrs)

    if success and _llm_request_duration is not None:
        dur_attrs: dict[str, str] = {
            "agent.type": agent_label,
            "model": model_name,
            "stream": stream_str,
        }
        _llm_request_duration.record(duration_ms, dur_attrs)


def record_llm_tokens(
    model: str,
    prompt_tokens: int,
    completion_tokens: int,
    *,
    agent_type: str | None = None,
    user_name: str | None = None,
) -> None:
    """Record LLM token usage.

    Args:
        model: The model name.
        prompt_tokens: Number of prompt tokens consumed.
        completion_tokens: Number of completion tokens generated.
        agent_type: Calling agent type for per-agent aggregation.
        user_name: Username of the caller (from JWT). Used for
            per-user token attribution on histograms.
    """
    model_name = _default_label(model, "default")
    agent_label = _default_label(agent_type, "unknown")
    user_label = _default_label(user_name, "unknown")

    attrs: dict[str, str] = {"model": model_name, "agent.type": agent_label}

    if _llm_tokens_prompt is not None and prompt_tokens > 0:
        _llm_tokens_prompt.add(prompt_tokens, attrs)

    if _llm_tokens_completion is not None and completion_tokens > 0:
        _llm_tokens_completion.add(completion_tokens, attrs)

    hist_attrs: dict[str, str] = {
        "model": model_name,
        "agent.type": agent_label,
        "user.name": user_label,
    }

    if _llm_tokens_prompt_hist is not None and prompt_tokens > 0:
        _llm_tokens_prompt_hist.record(prompt_tokens, hist_attrs)

    if _llm_tokens_completion_hist is not None and completion_tokens > 0:
        _llm_tokens_completion_hist.record(completion_tokens, hist_attrs)


def record_llm_fallback(
    from_model: str, to_model: str, *, agent_type: str | None = None
) -> None:
    """Record an LLM model fallback event.

    Args:
        from_model: The model that failed.
        to_model: The model being tried next.
        agent_type: Calling agent type for per-agent aggregation.
    """
    if _llm_fallback_counter is not None:
        attrs: dict[str, str] = {
            "agent.type": _default_label(agent_type, "unknown"),
            "from_model": _default_label(from_model, "default"),
            "to_model": _default_label(to_model, "default"),
        }
        _llm_fallback_counter.add(1, attrs)


def record_llm_error(
    model: str, error_type: str, *, agent_type: str | None = None
) -> None:
    """Record an LLM request error.

    Args:
        model: The model name.
        error_type: Type of error (e.g., "http_error", "parse_error").
        agent_type: Calling agent type for per-agent aggregation.
    """
    if _llm_error_counter is not None:
        attrs: dict[str, str] = {
            "agent.type": _default_label(agent_type, "unknown"),
            "model": _default_label(model, "default"),
            "error_type": _default_label(error_type, "unknown"),
        }
        _llm_error_counter.add(1, attrs)


def record_llm_retry(
    model: str, reason: str, attempt: int, *, agent_type: str | None = None
) -> None:
    """Record an LLM request retry.

    Args:
        model: The model name.
        reason: Reason for retry (e.g., "503", "429", "connect_error").
        attempt: Retry attempt number (1, 2, 3, ...).
        agent_type: Calling agent type for per-agent aggregation.
    """
    if _llm_retry_counter is not None:
        attrs: dict[str, str] = {
            "agent.type": _default_label(agent_type, "unknown"),
            "model": _default_label(model, "default"),
            "reason": _default_label(reason, "unknown"),
            "attempt": str(attempt),
        }
        _llm_retry_counter.add(1, attrs)


def record_task_active(agent_type: str, delta: int) -> None:
    """Record a change in active task count.

    Args:
        agent_type: The handler/agent type name.
        delta: +1 when task starts, -1 when task ends.
    """
    if _tasks_active is not None:
        _tasks_active.add(delta, {"agent.type": agent_type})


def record_state_persist(
    agent_type: str,
    size_bytes: int,
    entry_type: str,
) -> None:
    """Record a state persistence operation.

    Args:
        agent_type: The handler/agent type name.
        size_bytes: Size of the persisted entry in bytes.
        entry_type: Type of entry ("snapshot" or "delta").
    """
    if _state_persist_counter is not None:
        _state_persist_counter.add(
            1, {"agent.type": agent_type, "entry.type": entry_type}
        )

    if _state_persist_size is not None:
        _state_persist_size.record(
            size_bytes, {"agent.type": agent_type, "entry.type": entry_type}
        )


def record_state_recovery(agent_type: str) -> None:
    """Record a task state recovery event.

    Called when a task recovers state from a previous run (crash recovery).

    Args:
        agent_type: The handler/agent type name.
    """
    if _state_recovery_counter is not None:
        _state_recovery_counter.add(1, {"agent.type": agent_type})


def record_stm_operation(
    operation: str,
    duration_ms: float,
    success: bool,
    *,
    error_code: str | None = None,
) -> None:
    """Record an STM operation completion.

    Args:
        operation: The operation name (create, add, get, delete).
        duration_ms: Operation duration in milliseconds.
        success: Whether the operation succeeded.
        error_code: Error code if the operation failed (e.g., "not_found").
    """
    status = "success" if success else "error"
    attrs: dict[str, str] = {"operation": operation, "status": status}
    if error_code:
        attrs["error_code"] = error_code

    if _stm_operation_counter is not None:
        _stm_operation_counter.add(1, attrs)

    if success and _stm_operation_duration is not None:
        _stm_operation_duration.record(duration_ms, {"operation": operation})


def record_stm_retry(operation: str, grpc_code: str) -> None:
    """Record an STM operation retry.

    Args:
        operation: The operation name (create, add, get, delete).
        grpc_code: The gRPC status code that triggered the retry.
    """
    if _stm_retry_counter is not None:
        _stm_retry_counter.add(1, {"operation": operation, "grpc_code": grpc_code})


def record_stm_payload_size(size_bytes: int) -> None:
    """Record the size of an STM payload.

    Called when adding entries to STM.

    Args:
        size_bytes: Size of the payload in bytes.
    """
    if _stm_payload_size is not None:
        _stm_payload_size.record(size_bytes)


def record_stm_entries_retrieved(count: int) -> None:
    """Record the number of entries retrieved from STM.

    Called when getting entries from STM.

    Args:
        count: Number of entries retrieved.
    """
    if _stm_entries_retrieved is not None:
        _stm_entries_retrieved.record(count)


def record_http_request(
    method: str,
    host: str,
    status_code: int,
    duration_ms: float,
) -> None:
    """Record an HTTP request completion.

    Args:
        method: HTTP method (GET, POST, etc.).
        host: Target host.
        status_code: HTTP response status code.
        duration_ms: Request duration in milliseconds.
    """
    if _http_request_counter is not None:
        _http_request_counter.add(
            1, {"method": method, "host": host, "status_code": str(status_code)}
        )

    if _http_request_duration is not None:
        _http_request_duration.record(duration_ms, {"method": method, "host": host})


def record_http_error(method: str, host: str, error_type: str) -> None:
    """Record an HTTP client error (connection failure, timeout, etc.).

    Args:
        method: HTTP method (GET, POST, etc.).
        host: Target host.
        error_type: Type of error (e.g., "connect_error", "timeout", "read_error").
    """
    if _http_error_counter is not None:
        _http_error_counter.add(
            1, {"method": method, "host": host, "error_type": error_type}
        )


def record_grpc_call(
    method: str,
    duration_ms: float,
    success: bool,
    *,
    grpc_code: str | None = None,
) -> None:
    """Record a gRPC call to the platform.

    Args:
        method: The RPC method name (e.g., "Handshake", "Result").
        duration_ms: Call duration in milliseconds.
        success: Whether the call succeeded.
        grpc_code: gRPC status code (e.g., "OK", "UNAVAILABLE"). Defaults to
            "OK" for success and "UNKNOWN" for errors.
    """
    if grpc_code is None:
        grpc_code = "OK" if success else "UNKNOWN"

    if _grpc_call_counter is not None:
        _grpc_call_counter.add(1, {"method": method, "grpc_code": grpc_code})

    if success and _grpc_call_duration is not None:
        _grpc_call_duration.record(duration_ms, {"method": method})


def record_kg_request(
    operation: str,
    duration_ms: float,
    success: bool,
) -> None:
    """Record a KG request completion.

    Args:
        operation: The operation name ("query" or "get_schema").
        duration_ms: Request duration in milliseconds.
        success: Whether the request succeeded.
    """
    status = "success" if success else "error"

    if _kg_request_counter is not None:
        _kg_request_counter.add(1, {"operation": operation, "status": status})

    if success and _kg_request_duration is not None:
        _kg_request_duration.record(duration_ms, {"operation": operation})


def record_kg_error(operation: str, error_type: str) -> None:
    """Record a KG error.

    Args:
        operation: The operation name ("query" or "get_schema").
        error_type: Type of error ("connection_error" or "query_error").
    """
    if _kg_error_counter is not None:
        _kg_error_counter.add(1, {"operation": operation, "error_type": error_type})


def record_dra_request(
    operation: str,
    duration_ms: float,
    success: bool,
) -> None:
    """Record a DRA request completion.

    Args:
        operation: The operation name (e.g., "get_device_groups").
        duration_ms: Request duration in milliseconds.
        success: Whether the request succeeded.
    """
    status = "success" if success else "error"

    if _dra_request_counter is not None:
        _dra_request_counter.add(1, {"operation": operation, "status": status})

    if success and _dra_request_duration is not None:
        _dra_request_duration.record(duration_ms, {"operation": operation})


def record_dra_error(operation: str, error_type: str) -> None:
    """Record a DRA error.

    Args:
        operation: The operation name (e.g., "get_device_groups").
        error_type: Type of error ("connection_error" or "request_error").
    """
    if _dra_error_counter is not None:
        _dra_error_counter.add(1, {"operation": operation, "error_type": error_type})


def record_dra_response(operation: str, dra_id: str) -> None:
    """Record a DRA response received.

    Tracks responses per DRA for fan-out debugging.

    Args:
        operation: The operation name (e.g., "get_device_groups").
        dra_id: Identifier of the DRA that produced the response.
    """
    if _dra_response_counter is not None:
        _dra_response_counter.add(1, {"operation": operation, "dra_id": dra_id})


def record_rag_request(
    operation: str,
    duration_ms: float,
    success: bool,
) -> None:
    """Record a RAG request completion.

    Args:
        operation: The operation name (e.g. "search", "upload").
        duration_ms: Request duration in milliseconds.
        success: Whether the request succeeded.
    """
    status = "success" if success else "error"

    if _rag_request_counter is not None:
        _rag_request_counter.add(1, {"operation": operation, "status": status})

    if success and _rag_request_duration is not None:
        _rag_request_duration.record(duration_ms, {"operation": operation})


def record_rag_error(operation: str, error_type: str) -> None:
    """Record a RAG error.

    Args:
        operation: The operation name (e.g. "search", "upload").
        error_type: Type of error (e.g. "connection_error", "not_found").
    """
    if _rag_error_counter is not None:
        _rag_error_counter.add(1, {"operation": operation, "error_type": error_type})


def record_tools_request(
    operation: str,
    duration_ms: float,
    success: bool,
    *,
    tool_name: str | None = None,
    tool_kind: str | None = None,
    agent_type: str | None = None,
) -> None:
    """Record a Tools/MCP request completion.

    Args:
        operation: The operation name (e.g. "list_tools", "call_tool").
        duration_ms: Request duration in milliseconds.
        success: Whether the request succeeded.
        tool_name: Optional tool name for call_tool operations.
        tool_kind: Optional execution path identifier ("mcp", "native",
            "langgraph"). When set, applied as the `tool.kind` label.
        agent_type: Calling agent type for per-agent aggregation.
    """
    status = "success" if success else "error"
    attrs: dict[str, str] = {"operation": operation, "status": status}
    if tool_name is not None:
        attrs["tool_name"] = tool_name
    if tool_kind is not None:
        attrs["tool.kind"] = tool_kind
    if agent_type is not None:
        attrs["agent.type"] = agent_type

    if _tools_request_counter is not None:
        _tools_request_counter.add(1, attrs)

    if success and _tools_request_duration is not None:
        dur_attrs: dict[str, str] = {"operation": operation}
        if tool_name is not None:
            dur_attrs["tool_name"] = tool_name
        if tool_kind is not None:
            dur_attrs["tool.kind"] = tool_kind
        if agent_type is not None:
            dur_attrs["agent.type"] = agent_type
        _tools_request_duration.record(duration_ms, dur_attrs)


def record_tools_error(
    operation: str,
    error_type: str,
    *,
    tool_name: str | None = None,
    tool_kind: str | None = None,
    agent_type: str | None = None,
) -> None:
    """Record a Tools/MCP error.

    Args:
        operation: The operation name (e.g. "list_tools", "call_tool").
        error_type: Type of error (e.g. "connection_error", "call_error").
        tool_name: Optional tool name for call_tool operations.
        tool_kind: Optional execution path identifier ("mcp", "native",
            "langgraph"). When set, applied as the `tool.kind` label.
        agent_type: Calling agent type for per-agent aggregation.
    """
    if _tools_error_counter is not None:
        attrs: dict[str, str] = {"operation": operation, "error_type": error_type}
        if tool_name is not None:
            attrs["tool_name"] = tool_name
        if tool_kind is not None:
            attrs["tool.kind"] = tool_kind
        if agent_type is not None:
            attrs["agent.type"] = agent_type
        _tools_error_counter.add(1, attrs)


def record_subagent_call(
    mode: str,
    target_agent_type: str,
    duration_ms: float,
    success: bool,
    *,
    agent_type: str | None = None,
) -> None:
    """Record a sub-agent / spawn / call_agent invocation.

    Args:
        mode: Invocation mode ("local", "spawn", or "call").
        target_agent_type: Name of the agent being invoked.
        duration_ms: Call duration in milliseconds.
        success: Whether the call succeeded.
        agent_type: Calling (parent) agent type for per-agent aggregation.
    """
    status = "success" if success else "error"
    attrs: dict[str, str] = {
        "mode": mode,
        "target.agent_type": target_agent_type,
        "status": status,
    }
    if agent_type is not None:
        attrs["agent.type"] = agent_type

    if _subagent_call_counter is not None:
        _subagent_call_counter.add(1, attrs)

    if success and _subagent_call_duration is not None:
        dur_attrs: dict[str, str] = {
            "mode": mode,
            "target.agent_type": target_agent_type,
        }
        if agent_type is not None:
            dur_attrs["agent.type"] = agent_type
        _subagent_call_duration.record(duration_ms, dur_attrs)


def record_langgraph_llm_tokens(
    *,
    node: str,
    prompt_tokens: int,
    completion_tokens: int,
    agent_type: str | None = None,
) -> None:
    """Record per-node LLM token usage for a LangGraph LLM call.

    Records each LLM call's token usage attributed to the LangGraph node
    that issued it. Lets dashboards identify which graph nodes drive
    token cost.

    Args:
        node: The LangGraph node name (parent chain). Should be a small,
            bounded set of static node names — dynamic node names will
            inflate label cardinality.
        prompt_tokens: Number of prompt tokens consumed by the call.
        completion_tokens: Number of completion tokens generated.
        agent_type: Calling agent type for per-agent aggregation.
    """
    attrs: dict[str, str] = {"langgraph.node": node}
    if agent_type is not None:
        attrs["agent.type"] = agent_type

    if _langgraph_llm_tokens_prompt is not None and prompt_tokens > 0:
        _langgraph_llm_tokens_prompt.record(prompt_tokens, attrs)

    if _langgraph_llm_tokens_completion is not None and completion_tokens > 0:
        _langgraph_llm_tokens_completion.record(completion_tokens, attrs)
