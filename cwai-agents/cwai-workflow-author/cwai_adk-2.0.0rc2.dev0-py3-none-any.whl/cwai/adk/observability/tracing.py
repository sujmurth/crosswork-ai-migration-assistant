"""OpenTelemetry tracing setup."""

import functools
import inspect
from collections.abc import Callable
from typing import Any

from opentelemetry import propagate, trace
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator


def configure_tracing(
    service_name: str = "cwai-agent",
    service_version: str = "0.1.0",
    otlp_endpoint: str | None = None,
) -> trace.Tracer:
    """Configure OpenTelemetry tracing.

    If no OTLP endpoint is provided, returns a NoOpTracer.

    The OTLP exporter reads configuration from standard environment variables:
    - OTEL_EXPORTER_OTLP_ENDPOINT: Collector endpoint (such as "localhost:4317")
    - OTEL_EXPORTER_OTLP_CERTIFICATE: Path to CA certificate for TLS

    Args:
        service_name: Name of the agent service.
        service_version: Version of the agent.
        otlp_endpoint: If provided (non-empty), enables OTEL export. The actual
            endpoint is read from OTEL_EXPORTER_OTLP_ENDPOINT env var.

    Returns:
        Configured tracer instance.

    Examples:
        tracer = configure_tracing(
            service_name="my-agent",
            otlp_endpoint="localhost:4317",
        )
    """
    endpoint = otlp_endpoint or ""

    # Always set up W3C trace context propagation
    propagate.set_global_textmap(TraceContextTextMapPropagator())

    if not endpoint.strip():
        return trace.NoOpTracer()

    # Only import heavy SDK dependencies when actually exporting
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    resource = Resource.create(
        {
            "service.name": service_name,
            "service.version": service_version,
        }
    )

    provider = TracerProvider(resource=resource)

    # Use gRPC exporter - it reads from OTEL_EXPORTER_OTLP_* env vars
    exporter = OTLPSpanExporter()
    provider.add_span_processor(BatchSpanProcessor(exporter))

    trace.set_tracer_provider(provider)

    return trace.get_tracer(service_name, service_version)


# ---------------------------------------------------------------------------
# Task tracer
# ---------------------------------------------------------------------------

# Default tracer name — matches the tracer exposed as ``agent.tracer``
# and ``ctx.tracer``.
_HANDLER_TRACER_NAME = "cwai.adk.agent.handler"


def get_task_tracer() -> trace.Tracer:
    """Get the tracer for task handlers.

    Returns the same tracer used by ``agent.tracer`` and ``ctx.tracer``.
    Spans created with this tracer appear as children of the framework's
    ``task.execute`` span when called within a handler.

    Returns:
        Tracer instance for creating spans.

    Examples:
        tracer = get_task_tracer()
        with tracer.start_as_current_span("echo.transform") as span:
            span.set_attribute("input.length", len(text))
            result = await transform(text)
    """
    return trace.get_tracer(_HANDLER_TRACER_NAME)


# ---------------------------------------------------------------------------
# traced_span decorator
# ---------------------------------------------------------------------------


def traced_span(
    span_name: str,
    *,
    include_args: list[str] | None = None,
    include_return: bool = False,
    tracer: trace.Tracer | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Wrap a function in an OpenTelemetry span.

    Work with both sync and async functions. The span is created as a
    child of whatever span is currently active (typically the framework's
    ``task.execute`` span).

    On successful completion, the span status is set to OK. If the function
    raises an exception, the status is set to ERROR and the exception is
    recorded. If the function explicitly sets a status (for example, ERROR for a
    soft failure), that status is preserved.

    To access the span inside the decorated function for adding custom
    attributes or setting status, use ``trace.get_current_span()``::

        from opentelemetry import trace

        @traced_span("my.operation")
        def my_func():
            span = trace.get_current_span()
            span.set_attribute("custom.key", "value")
            if something_went_wrong:
                span.set_status(trace.StatusCode.ERROR, "soft error")
            return result

    Args:
        span_name: Name for the created span.
        include_args: Argument names whose ``str()`` values are recorded
            as ``arg.<name>`` span attributes.
        include_return: If True, record ``str(result)`` as the
            ``return_value`` span attribute.
        tracer: Tracer to use. Defaults to the handler tracer
            (same instance as ``agent.tracer``).

    Examples:
        @traced_span("fetch_config", include_args=["device"])
        async def fetch_config(device: str, ctx: Context) -> dict:
            ...
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        # Resolve parameter names once at decoration time
        sig = inspect.signature(func)
        param_names = list(sig.parameters.keys())

        def _set_span_attrs(
            span: trace.Span,
            args: tuple[Any, ...],
            kwargs: dict[str, Any],
            result: Any | None = None,
        ) -> None:
            span.set_attribute("function.name", getattr(func, "__name__", repr(func)))
            span.set_attribute("function.module", getattr(func, "__module__", ""))

            if include_args:
                # Positional args mapped by parameter name
                for i, val in enumerate(args):
                    if i < len(param_names) and param_names[i] in include_args:
                        span.set_attribute(f"arg.{param_names[i]}", str(val))
                # Keyword args
                for name in include_args:
                    if name in kwargs:
                        span.set_attribute(f"arg.{name}", str(kwargs[name]))

            if include_return and result is not None:
                span.set_attribute("return_value", str(result))

        def _maybe_set_ok_status(span: trace.Span) -> None:
            """Set OK status if not already set. Handles NonRecordingSpan."""
            status = getattr(span, "status", None)
            if status is not None and status.status_code == trace.StatusCode.UNSET:
                span.set_status(trace.Status(trace.StatusCode.OK))

        if inspect.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                t = tracer or trace.get_tracer(_HANDLER_TRACER_NAME)
                with t.start_as_current_span(span_name) as span:
                    _set_span_attrs(span, args, kwargs)
                    try:
                        result = await func(*args, **kwargs)
                    except Exception as exc:
                        span.record_exception(exc)
                        span.set_status(
                            trace.Status(trace.StatusCode.ERROR, str(exc)),
                        )
                        raise
                    if include_return:
                        _set_span_attrs(span, args, kwargs, result)
                    _maybe_set_ok_status(span)
                    return result

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            t = tracer or trace.get_tracer(_HANDLER_TRACER_NAME)
            with t.start_as_current_span(span_name) as span:
                _set_span_attrs(span, args, kwargs)
                try:
                    result = func(*args, **kwargs)
                except Exception as exc:
                    span.record_exception(exc)
                    span.set_status(
                        trace.Status(trace.StatusCode.ERROR, str(exc)),
                    )
                    raise
                if include_return:
                    _set_span_attrs(span, args, kwargs, result)
                _maybe_set_ok_status(span)
                return result

        return sync_wrapper

    return decorator
