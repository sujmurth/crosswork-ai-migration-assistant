"""Helpers for recording content as span events with truncation."""

from __future__ import annotations

from opentelemetry import trace

from cwai.adk.features import get_trace_content_max_length


def record_content_event(
    span: trace.Span,
    event_name: str,
    content: object,
) -> None:
    """Record a content span event, truncating if needed.

    Does nothing if trace content logging is disabled (max_length <= 0).

    Args:
        span: The span to add the event to.
        event_name: Fully qualified event name (e.g. "cwai.agent.llm.prompt").
        content: The content to record. Coerced to str if not already.
    """
    max_len = get_trace_content_max_length()
    if max_len <= 0:
        return

    # Callers may pass non-str objects; coerce to avoid TypeError on len().
    content = str(content)

    truncated = len(content) > max_len
    if truncated:
        content = content[:max_len]

    span.add_event(
        event_name,
        attributes={
            f"{event_name}.content": content,
            f"{event_name}.truncated": truncated,
        },
    )
