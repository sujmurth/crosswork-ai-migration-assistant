"""Internal helpers for resolving common metric/span label values."""

from typing import Any


def _resolve_agent_type(obj: Any) -> str | None:
    """Resolve the ``agent.type`` label from an object.

    Accepts either an object that holds a ``_request_context`` attribute
    (e.g. ADK clients/tools) or a ``RequestContext`` directly. Returns
    ``None`` when no agent type is available.
    """
    rc = getattr(obj, "_request_context", obj)
    if rc is None:
        return None
    return getattr(rc, "agent_type", None)
