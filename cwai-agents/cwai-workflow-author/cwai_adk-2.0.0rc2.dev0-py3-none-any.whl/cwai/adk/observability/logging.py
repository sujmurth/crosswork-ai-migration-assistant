"""Structured JSON logging with OpenTelemetry trace context."""

import datetime
import json
import logging
import os
from collections.abc import MutableMapping
from pathlib import Path
from typing import Any

from opentelemetry import context, trace
from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.sdk.resources import Resource

# Environment variable for log level configuration.
# Valid values: DEBUG, INFO, WARNING, ERROR, CRITICAL (case-insensitive).
_LOG_LEVEL_ENV = "CWAI_LOG_LEVEL"

# Standard LogRecord attributes to exclude when collecting extra fields.
# This lets us iterate vars(record) and keep only caller-supplied context.
_LOGRECORD_ATTRS = frozenset(
    vars(
        logging.LogRecord(
            name="",
            level=0,
            pathname="",
            lineno=0,
            msg="",
            args=(),
            exc_info=None,
        )
    )
)


class TaskLogger(logging.LoggerAdapter):
    """Logger adapter that injects task metadata into every log entry.

    Use ``get_task_logger()`` to create instances.
    """

    extra: dict[str, Any]

    def process(
        self, msg: str, kwargs: MutableMapping[str, Any]
    ) -> tuple[str, MutableMapping[str, Any]]:
        """Merge task metadata with caller-supplied extra fields."""
        caller_extra = kwargs.get("extra", {})
        kwargs["extra"] = {**self.extra, **caller_extra}
        return msg, kwargs


def get_task_logger(
    task_id: str,
    corr_id: str,
    agent_type: str,
    agent_instance_id: str,
) -> TaskLogger:
    """Create a logger that automatically includes task metadata.

    Every log call made through the returned logger will include
    ``agent_id``, ``thread_id``, ``agent_type``, and ``agent_instance_id``
    in the JSON output.

    Args:
        task_id: Agent identifier (named task_id for backward compat).
        corr_id: Thread identifier (named corr_id for backward compat).
        agent_type: Type/name of the agent.
        agent_instance_id: Unique instance identifier.

    Returns:
        A logger adapter that injects task metadata.
    """
    base_logger = logging.getLogger("cwai.adk.agent.handler")
    extra = {
        "agent_id": task_id,
        "thread_id": corr_id,
        "agent_type": agent_type,
        "agent_instance_id": agent_instance_id,
    }
    return TaskLogger(base_logger, extra)


class JSONFormatter(logging.Formatter):
    """JSON log formatter that includes otel trace context.

    Output format:
    timestamp, severity, message, app, task_id, correlation_id, trace_id, span_id
    """

    def __init__(self, app_name: str = "cwai-agent"):
        self.app_name = app_name
        super().__init__()

    def format(self, record: logging.LogRecord) -> str:
        """Format a log record as JSON with OTEL trace context."""
        trace_id = None
        span_id = None

        try:
            span_context = trace.get_current_span(
                context.get_current()
            ).get_span_context()
            if span_context.is_valid:
                trace_id = format(span_context.trace_id, "032x")
                span_id = format(span_context.span_id, "016x")
        except Exception:
            pass

        entry: dict[str, Any] = {
            "timestamp": datetime.datetime.now(datetime.UTC).isoformat(),
            "severity": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
            "app": self.app_name,
            "trace_id": trace_id,
            "span_id": span_id,
        }

        # Include structured fields passed via extra={}.
        # Standard LogRecord attrs are excluded so only caller-supplied
        # context (task_id, duration_ms, etc.) ends up in the JSON.
        for key, value in vars(record).items():
            if key not in _LOGRECORD_ATTRS and key not in entry:
                entry[key] = value

        if record.exc_info:
            entry["exception"] = self.formatException(record.exc_info)

        return json.dumps(entry, default=str)


def _resolve_log_level(level: int | None) -> int:
    """Resolve log level from parameter or environment variable.

    Priority: explicit parameter > CWAI_LOG_LEVEL env var > INFO default.
    """
    if level is not None:
        return level

    env_level = os.environ.get(_LOG_LEVEL_ENV, "").upper()
    if env_level:
        resolved = getattr(logging, env_level, None)
        if resolved is not None:
            return resolved
    return logging.INFO


class OTELLoggingHandler(logging.Handler):
    """Wrapper around OTEL LoggingHandler that tracks the provider for shutdown.

    This allows proper cleanup of the LoggerProvider and its BatchLogRecordProcessor
    when the handler is removed or the logger is reconfigured.

    The exporter reads configuration from standard OTEL environment variables:
    - OTEL_EXPORTER_OTLP_ENDPOINT: Collector endpoint (e.g., "localhost:4317")
    - OTEL_EXPORTER_OTLP_PROTOCOL: Protocol ("grpc" or "http/protobuf")
    - OTEL_EXPORTER_OTLP_CERTIFICATE: Path to CA certificate for TLS
    """

    def __init__(
        self,
        app_name: str,
        service_version: str,
        level: int,
    ):
        super().__init__(level=level)

        resource = Resource.create(
            {
                "service.name": app_name,
                "service.version": service_version,
            }
        )

        self._provider = LoggerProvider(resource=resource)

        # Use gRPC exporter - it reads from OTEL_EXPORTER_OTLP_* env vars
        from opentelemetry.exporter.otlp.proto.grpc._log_exporter import (
            OTLPLogExporter,
        )

        exporter = OTLPLogExporter()
        self._provider.add_log_record_processor(BatchLogRecordProcessor(exporter))

        self._inner_handler = LoggingHandler(
            level=level, logger_provider=self._provider
        )

    def emit(self, record: logging.LogRecord) -> None:
        """Delegate to the inner OTEL handler."""
        self._inner_handler.emit(record)

    def flush(self) -> None:
        """Flush the inner handler."""
        self._inner_handler.flush()

    def close(self) -> None:
        """Shutdown the provider and close the inner handler."""
        try:
            self._provider.force_flush()
            self._provider.shutdown()
        except Exception:
            pass
        self._inner_handler.close()
        super().close()


def configure_logging(
    app_name: str = "cwai-agent",
    level: int | None = None,
    otlp_endpoint: str | None = None,
    service_version: str = "0.1.0",
) -> logging.Logger:
    """Configure structured JSON logging for an agent.

    Logs to stdout and to a file under ``logs/``. The file is named
    ``<app_name>.log``. Task-specific metadata (task_id, corr_id, etc.)
    is included in each JSON log entry via ``ctx.log``, making logs
    filterable by task.

    When ``otlp_endpoint`` is provided (or OTEL_EXPORTER_OTLP_ENDPOINT is set),
    logs are also exported to an OpenTelemetry collector via OTLP gRPC.
    This is additive to the existing stdout and file handlers.

    The OTLP exporter reads configuration from standard environment variables:
    - OTEL_EXPORTER_OTLP_ENDPOINT: Collector endpoint (e.g., "localhost:4317")
    - OTEL_EXPORTER_OTLP_CERTIFICATE: Path to CA certificate for TLS

    Log level can be set via the ``CWAI_LOG_LEVEL`` environment variable
    (DEBUG, INFO, WARNING, ERROR, CRITICAL). The explicit ``level``
    parameter takes precedence if provided.

    Args:
        app_name: Name of the agent (included in every log entry).
        level: Log level. If None, reads from CWAI_LOG_LEVEL or defaults to INFO.
        otlp_endpoint: If provided (non-empty), enables OTEL export. The actual
            endpoint is read from OTEL_EXPORTER_OTLP_ENDPOINT env var.
        service_version: Version of the agent service (used in OTEL resource
            attributes).

    Returns:
        Configured root logger for the cwai.adk namespace.
    """
    resolved_level = _resolve_log_level(level)

    logger = logging.getLogger("cwai.adk")
    logger.handlers.clear()
    logger.setLevel(resolved_level)

    formatter = JSONFormatter(app_name=app_name)

    stdout_handler = logging.StreamHandler()
    stdout_handler.setFormatter(formatter)
    logger.addHandler(stdout_handler)

    # Write to logs/ directory.
    try:
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)
        log_file = log_dir / f"{app_name}.log"
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except OSError:
        # Non-fatal — log to stdout only if file logging fails.
        logger.warning("Could not create log file, logging to stdout only")

    # Add OTEL handler if endpoint is provided.
    # The exporter reads actual config from OTEL_EXPORTER_OTLP_* env vars.
    if otlp_endpoint and otlp_endpoint.strip():
        otel_handler = OTELLoggingHandler(
            app_name=app_name,
            service_version=service_version,
            level=resolved_level,
        )
        logger.addHandler(otel_handler)

    logger.propagate = False
    return logger
